import { TextureType, ShapeState } from './types';

export interface MaterialDef {
  id: TextureType;
  name: string;
  category: 'paper' | 'fabric' | 'luxury' | 'stone' | 'print';
  icon: string;
  description: string;
  defaultOpacity: number;
  bestColors: string[];
}

export const MATERIAL_LIST: MaterialDef[] = [
  {
    id: 'washi_kozo',
    name: 'Washi Kozo Jepang',
    category: 'paper',
    icon: '🎋',
    description: 'Serat tumbuhan murbei kozo organik memanjang dengan tekstur pulp kertas tradisional.',
    defaultOpacity: 65,
    bestColors: ['#faf7f2', '#f3eee3', '#e8dfd1', '#f5f0eb']
  },
  {
    id: 'recycled',
    name: 'Eco Recycled Pulp',
    category: 'paper',
    icon: '♻️',
    description: 'Bintik serpihan serat daur ulang alami dan flecks kayu organik ramah lingkungan.',
    defaultOpacity: 60,
    bestColors: ['#f4efe6', '#ebe4d8', '#e3dbcd', '#dfd5c4']
  },
  {
    id: 'watercolor_coldpress',
    name: 'Cotton Watercolor 300gsm',
    category: 'paper',
    icon: '🎨',
    description: 'Tekstur tooth berpori kasar kertas cat air katun murni dengan penyerapan pigmen alami.',
    defaultOpacity: 55,
    bestColors: ['#fbf9f5', '#f7f4ed', '#efe9dd', '#f8fafc']
  },
  {
    id: 'linen_blend',
    name: 'Tenun Linen & Canvas',
    category: 'fabric',
    icon: '🧵',
    description: 'Anyaman serat benang horizontal dan vertikal yang rapat dan bertekstur taktil mewah.',
    defaultOpacity: 50,
    bestColors: ['#f2ece1', '#e8e0d0', '#dfe4ea', '#e2e8e0']
  },
  {
    id: 'gilded_gold_leaf',
    name: 'Serpihan Emas 24K (Gold Leaf)',
    category: 'luxury',
    icon: '✨',
    description: 'Flek lembaran emas 24k dan taburan mikro-glitter yang memantulkan kilau elegan.',
    defaultOpacity: 75,
    bestColors: ['#1e1b18', '#0f172a', '#2a2421', '#fefce8']
  },
  {
    id: 'terrazzo_stone',
    name: 'Batu Terrazzo Modern',
    category: 'stone',
    icon: '🏛️',
    description: 'Fragmen pecahan batu marmer dan mineral warna-warni khas desain interior kontemporer.',
    defaultOpacity: 60,
    bestColors: ['#f8fafc', '#f1f5f9', '#faf5ff', '#fff7ed']
  },
  {
    id: 'marble_vein',
    name: 'Marmer Carrara Italia',
    category: 'stone',
    icon: '💎',
    description: 'Urat-urat mineral marmer putih abu-abu elegan berliuk anggun di atas permukaan batu.',
    defaultOpacity: 45,
    bestColors: ['#f8fafc', '#f1f5f9', '#fdfefe', '#0f172a']
  },
  {
    id: 'cardboard',
    name: 'Kardus Kraft Alami',
    category: 'paper',
    icon: '📦',
    description: 'Garis serat karton bergelombang kasar dengan warna coklat earthy alami.',
    defaultOpacity: 65,
    bestColors: ['#d7ba8d', '#caa572', '#be965e', '#b0874e']
  },
  {
    id: 'frosted_vellum',
    name: 'Kalkir Arsitektur (Vellum)',
    category: 'paper',
    icon: '📐',
    description: 'Kertas kalkir semi-buram matte yang memberikan pendaran cahaya lembut dan elegan.',
    defaultOpacity: 50,
    bestColors: ['#ffffff', '#f8fafc', '#f1f5f9', '#f0fdf4']
  },
  {
    id: 'holographic_foil',
    name: 'Foil Hologram Pelangi',
    category: 'luxury',
    icon: '🌈',
    description: 'Lapisan foil prisma pelangi yang memancarkan kilau iridescence futuristik.',
    defaultOpacity: 45,
    bestColors: ['#0f172a', '#18181b', '#ffffff', '#312e81']
  },
  {
    id: 'halftone',
    name: 'Vintage Halftone Print',
    category: 'print',
    icon: '📰',
    description: 'Pola titik-titik raster mikro cetak koran dan majalah editorial retro klasik.',
    defaultOpacity: 40,
    bestColors: ['#f5f0eb', '#fdf6e2', '#f0ede6', '#ffffff']
  },
  {
    id: 'leatherette',
    name: 'Kulit Sintetis Deboss',
    category: 'fabric',
    icon: '👜',
    description: 'Tekstur butiran pori kulit binatang deboss halus dengan kedalaman mikro-shadow.',
    defaultOpacity: 50,
    bestColors: ['#292524', '#451a03', '#1c1917', '#78350f']
  },
  {
    id: 'wood_veneer',
    name: 'Serat Kayu Oak Veneer',
    category: 'stone',
    icon: '🪵',
    description: 'Serat kambium kayu alami dengan lekukan cincin tahunan pohon yang menawan.',
    defaultOpacity: 50,
    bestColors: ['#e2c29d', '#d4a373', '#ba7e4c', '#fefae0']
  },
  {
    id: 'rough_slate',
    name: 'Batu Tulis Arang Slate',
    category: 'stone',
    icon: '⬛',
    description: 'Permukaan batuan mineral slate gelap dengan serpihan patahan alami matte.',
    defaultOpacity: 55,
    bestColors: ['#1e293b', '#0f172a', '#18181b', '#27272a']
  },
  {
    id: 'grid',
    name: 'Grid Milimeter Blueprint',
    category: 'print',
    icon: '📐',
    description: 'Garis grid teknik 10px & 50px presisi untuk karya grafis arsitektural dan editorial.',
    defaultOpacity: 45,
    bestColors: ['#ffffff', '#faf7f2', '#f0fdf4', '#0f172a']
  },
  {
    id: 'cotton_rag',
    name: 'Kertas Katun Organik Rag',
    category: 'paper',
    icon: '📜',
    description: 'Kertas serat katun lembut bebas asam dengan butiran halus tak beraturan.',
    defaultOpacity: 45,
    bestColors: ['#fcfaf7', '#f6f1e8', '#ebe3d5', '#f8fafc']
  },
  {
    id: 'creased_lines',
    name: 'Garis Lipatan Origami',
    category: 'paper',
    icon: '✉️',
    description: 'Garis-garis tekukan dan lipatan geometris kertas multi-arah yang realistis.',
    defaultOpacity: 50,
    bestColors: ['#faf7f2', '#ffffff', '#f4efe6', '#ede8df']
  }
];

// Deterministic seed random generator
function seedRand(seed: number) {
  let s = Math.sin(seed * 9876.54) * 10000;
  return () => {
    s = Math.sin(s * 9876.54) * 10000;
    return s - Math.floor(s);
  };
}

/**
 * Procedurally draws rich material textures directly into Canvas 2D
 */
export function drawMaterialTextureToCanvas(
  ctx: CanvasRenderingContext2D,
  textureType: TextureType,
  textureOpacity: number,
  w: number,
  h: number,
  path2d: Path2D,
  seed: number = 1
) {
  if (!textureType || textureType === 'none' || textureOpacity <= 0) return;

  const alpha = (textureOpacity / 100) * 0.9;
  const rand = seedRand(seed || 42);

  ctx.save();
  ctx.clip(path2d);

  switch (textureType) {
    // 1. JAPANESE KOZO / WASHI FIBERS
    case 'washi_kozo':
    case 'washi_fibers': {
      ctx.globalAlpha = alpha;
      const fiberCount = Math.round((w * h) / 1200);

      // Long botanical mulberry fibers
      for (let i = 0; i < fiberCount; i++) {
        const x1 = rand() * w;
        const y1 = rand() * h;
        const len = 15 + rand() * 45;
        const angle = rand() * Math.PI * 2;
        const curve = (rand() - 0.5) * 15;

        const x2 = x1 + Math.cos(angle) * len;
        const y2 = y1 + Math.sin(angle) * len;
        const cx = (x1 + x2) / 2 + Math.cos(angle + Math.PI / 2) * curve;
        const cy = (y1 + y2) / 2 + Math.sin(angle + Math.PI / 2) * curve;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.quadraticCurveTo(cx, cy, x2, y2);
        
        const isDark = rand() > 0.4;
        ctx.strokeStyle = isDark ? `rgba(90, 70, 50, ${0.15 + rand() * 0.25})` : `rgba(255, 255, 255, ${0.25 + rand() * 0.35})`;
        ctx.lineWidth = 0.6 + rand() * 1.2;
        ctx.stroke();
      }

      // Small translucent pulp clouds
      for (let i = 0; i < 25; i++) {
        const px = rand() * w;
        const py = rand() * h;
        const pr = 8 + rand() * 24;
        const pGrad = ctx.createRadialGradient(px, py, 0, px, py, pr);
        pGrad.addColorStop(0, 'rgba(255, 255, 255, 0.12)');
        pGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = pGrad;
        ctx.beginPath();
        ctx.arc(px, py, pr, 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }

    // 2. RECYCLED ECO PULP
    case 'recycled': {
      ctx.globalAlpha = alpha;
      const speckCount = Math.round((w * h) / 600);

      for (let i = 0; i < speckCount; i++) {
        const sx = rand() * w;
        const sy = rand() * h;
        const size = 0.8 + rand() * 2.5;
        const isDark = rand() > 0.25;

        ctx.fillStyle = isDark
          ? `rgba(60, 45, 30, ${0.2 + rand() * 0.4})`
          : `rgba(255, 255, 255, ${0.3 + rand() * 0.4})`;

        if (rand() > 0.6) {
          // Tiny elongated fiber fleck
          const rot = rand() * Math.PI;
          ctx.save();
          ctx.translate(sx, sy);
          ctx.rotate(rot);
          ctx.fillRect(-size, -size * 0.4, size * 2, size * 0.8);
          ctx.restore();
        } else {
          // Micro dot
          ctx.beginPath();
          ctx.arc(sx, sy, size * 0.7, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      break;
    }

    // 3. 300GSM WATERCOLOR COLD-PRESSED TOOTH
    case 'watercolor_coldpress':
    case 'watercolor_paper': {
      ctx.globalAlpha = alpha;
      const step = 6;
      for (let y = 0; y < h; y += step) {
        for (let x = 0; x < w; x += step) {
          const jitterX = (rand() - 0.5) * 3;
          const jitterY = (rand() - 0.5) * 3;
          const px = x + jitterX;
          const py = y + jitterY;
          const isHigh = rand() > 0.5;

          ctx.fillStyle = isHigh
            ? `rgba(255, 255, 255, ${0.12 + rand() * 0.18})`
            : `rgba(0, 0, 0, ${0.06 + rand() * 0.1})`;

          ctx.beginPath();
          ctx.arc(px, py, 1.5 + rand() * 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      break;
    }

    // 4. LINEN BLEND & CANVAS FABRIC
    case 'linen_blend':
    case 'canvas_fabric': {
      ctx.globalAlpha = alpha;
      const spacing = 5;

      // Horizontal threads
      for (let y = 0; y < h; y += spacing) {
        const offset = (rand() - 0.5) * 0.8;
        ctx.beginPath();
        ctx.moveTo(0, y + offset);
        ctx.lineTo(w, y + offset);
        ctx.strokeStyle = y % (spacing * 2) === 0 ? 'rgba(255, 255, 255, 0.16)' : 'rgba(0, 0, 0, 0.1)';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }

      // Vertical threads
      for (let x = 0; x < w; x += spacing) {
        const offset = (rand() - 0.5) * 0.8;
        ctx.beginPath();
        ctx.moveTo(x + offset, 0);
        ctx.lineTo(x + offset, h);
        ctx.strokeStyle = x % (spacing * 2) === 0 ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.16)';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
      break;
    }

    // 5. GILDED 24K GOLD LEAF & FLECK SHIMMER
    case 'gold_dust':
    case 'gilded_gold_leaf': {
      ctx.globalAlpha = alpha;
      const flakeCount = Math.round((w * h) / 1000);

      for (let i = 0; i < flakeCount; i++) {
        const gx = rand() * w;
        const gy = rand() * h;
        const gSize = 1.5 + rand() * 6;
        const rot = rand() * Math.PI * 2;

        ctx.save();
        ctx.translate(gx, gy);
        ctx.rotate(rot);

        // Gold Foil Gradient
        const gGrad = ctx.createLinearGradient(-gSize, -gSize, gSize, gSize);
        gGrad.addColorStop(0, '#fef08a'); // Light Gold
        gGrad.addColorStop(0.5, '#eab308'); // Pure 24K Gold
        gGrad.addColorStop(1, '#ca8a04'); // Deep Antique Gold

        ctx.fillStyle = gGrad;
        ctx.shadowColor = '#fef08a';
        ctx.shadowBlur = 4;

        // Irregular foil jagged polygon
        ctx.beginPath();
        const numPts = 5 + Math.floor(rand() * 4);
        for (let p = 0; p < numPts; p++) {
          const pAngle = (p / numPts) * Math.PI * 2;
          const pRadius = gSize * (0.6 + rand() * 0.8);
          const px = Math.cos(pAngle) * pRadius;
          const py = Math.sin(pAngle) * pRadius;
          if (p === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      }

      // Sparkle stars
      for (let i = 0; i < 8; i++) {
        const starX = rand() * w;
        const starY = rand() * h;
        const starSize = 4 + rand() * 6;

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(starX - starSize, starY);
        ctx.lineTo(starX + starSize, starY);
        ctx.moveTo(starX, starY - starSize);
        ctx.lineTo(starX, starY + starSize);
        ctx.stroke();
      }
      break;
    }

    // 6. MODERN TERRAZZO STONE
    case 'terrazzo_stone': {
      ctx.globalAlpha = alpha;
      const chipsCount = Math.round((w * h) / 1800);
      const palette = ['#e11d48', '#0284c7', '#059669', '#d97706', '#475569', '#7c3aed', '#fbbf24'];

      for (let i = 0; i < chipsCount; i++) {
        const tx = rand() * w;
        const ty = rand() * h;
        const tSize = 4 + rand() * 12;
        const color = palette[Math.floor(rand() * palette.length)];

        ctx.save();
        ctx.translate(tx, ty);
        ctx.rotate(rand() * Math.PI * 2);

        ctx.fillStyle = color;
        ctx.beginPath();
        const numPoints = 4 + Math.floor(rand() * 3);
        for (let p = 0; p < numPoints; p++) {
          const ang = (p / numPoints) * Math.PI * 2;
          const rad = tSize * (0.5 + rand() * 0.7);
          const px = Math.cos(ang) * rad;
          const py = Math.sin(ang) * rad;
          if (p === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      }
      break;
    }

    // 7. ITALIAN CARRARA MARBLE VEINS
    case 'marble_vein': {
      ctx.globalAlpha = alpha;
      const numVeins = 5 + Math.floor(rand() * 4);

      for (let v = 0; v < numVeins; v++) {
        let vx = rand() * w;
        let vy = rand() * h;
        const vLen = 60 + rand() * 120;
        const baseAngle = (rand() * 0.8 + 0.2) * Math.PI;

        ctx.beginPath();
        ctx.moveTo(vx, vy);

        for (let seg = 0; seg < 8; seg++) {
          const ang = baseAngle + (rand() - 0.5) * 0.9;
          const segDist = vLen / 8;
          vx += Math.cos(ang) * segDist;
          vy += Math.sin(ang) * segDist;
          ctx.lineTo(vx, vy);
        }

        ctx.strokeStyle = `rgba(100, 116, 139, ${0.15 + rand() * 0.25})`;
        ctx.lineWidth = 1 + rand() * 2.5;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.stroke();
      }
      break;
    }

    // 8. CARDBOARD / KRAFT FIBERS
    case 'cardboard': {
      ctx.globalAlpha = alpha;
      const stripeW = 12;
      for (let x = 0; x < w; x += stripeW) {
        ctx.fillStyle = (x / stripeW) % 2 === 0 ? 'rgba(0, 0, 0, 0.08)' : 'rgba(255, 255, 255, 0.08)';
        ctx.fillRect(x, 0, stripeW, h);
      }
      // Woody specks
      for (let i = 0; i < 150; i++) {
        const kx = rand() * w;
        const ky = rand() * h;
        ctx.fillStyle = 'rgba(70, 45, 20, 0.3)';
        ctx.fillRect(kx, ky, 2 + rand() * 4, 1);
      }
      break;
    }

    // 9. ARCHITECTURAL FROSTED VELLUM
    case 'frosted_vellum': {
      ctx.globalAlpha = alpha;
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, 'rgba(255, 255, 255, 0.25)');
      grad.addColorStop(0.5, 'rgba(255, 255, 255, 0.08)');
      grad.addColorStop(1, 'rgba(255, 255, 255, 0.2)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Fine milky stipple
      for (let i = 0; i < 400; i++) {
        const fx = rand() * w;
        const fy = rand() * h;
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.beginPath();
        ctx.arc(fx, fy, 1 + rand(), 0, Math.PI * 2);
        ctx.fill();
      }
      break;
    }

    // 10. HOLOGRAPHIC FOIL
    case 'holographic_foil': {
      ctx.globalAlpha = alpha;
      const holoGrad = ctx.createLinearGradient(0, 0, w, h);
      holoGrad.addColorStop(0, 'rgba(236, 72, 153, 0.35)'); // Pink
      holoGrad.addColorStop(0.2, 'rgba(168, 85, 247, 0.35)'); // Purple
      holoGrad.addColorStop(0.4, 'rgba(59, 130, 246, 0.35)'); // Blue
      holoGrad.addColorStop(0.6, 'rgba(16, 185, 129, 0.35)'); // Emerald
      holoGrad.addColorStop(0.8, 'rgba(245, 158, 11, 0.35)'); // Amber
      holoGrad.addColorStop(1, 'rgba(239, 68, 68, 0.35)'); // Red

      ctx.fillStyle = holoGrad;
      ctx.fillRect(0, 0, w, h);

      // Specular sheen sweep line
      const sheen = ctx.createLinearGradient(0, 0, w * 0.8, h * 0.8);
      sheen.addColorStop(0, 'rgba(255, 255, 255, 0)');
      sheen.addColorStop(0.5, 'rgba(255, 255, 255, 0.45)');
      sheen.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = sheen;
      ctx.fillRect(0, 0, w, h);
      break;
    }

    // 11. VINTAGE HALFTONE
    case 'halftone': {
      ctx.globalAlpha = alpha;
      const gridDist = 8;
      for (let y = 0; y < h; y += gridDist) {
        for (let x = 0; x < w; x += gridDist) {
          const distToCenter = Math.hypot(x - w / 2, y - h / 2) / (Math.max(w, h) / 2);
          const radius = Math.max(0.6, 2.5 * (1 - distToCenter * 0.5));
          ctx.fillStyle = 'rgba(0, 0, 0, 0.18)';
          ctx.beginPath();
          ctx.arc(x, y, radius, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      break;
    }

    // 12. LEATHERETTE DEBOSS
    case 'leatherette': {
      ctx.globalAlpha = alpha;
      const cells = 10;
      for (let y = 0; y < h; y += cells) {
        for (let x = 0; x < w; x += cells) {
          const jx = x + (rand() - 0.5) * 4;
          const jy = y + (rand() - 0.5) * 4;
          ctx.fillStyle = rand() > 0.5 ? 'rgba(0, 0, 0, 0.12)' : 'rgba(255, 255, 255, 0.1)';
          ctx.beginPath();
          ctx.ellipse(jx, jy, 3.5, 2.5, rand() * Math.PI, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      break;
    }

    // 13. WOOD VENEER
    case 'wood_veneer': {
      ctx.globalAlpha = alpha;
      const numGrains = 18;
      for (let i = 0; i < numGrains; i++) {
        const yPos = (i / numGrains) * h;
        ctx.beginPath();
        ctx.moveTo(0, yPos);
        ctx.bezierCurveTo(w * 0.3, yPos + (rand() - 0.5) * 30, w * 0.7, yPos + (rand() - 0.5) * 30, w, yPos);
        ctx.strokeStyle = i % 2 === 0 ? 'rgba(60, 35, 15, 0.15)' : 'rgba(255, 255, 255, 0.12)';
        ctx.lineWidth = 2 + rand() * 3;
        ctx.stroke();
      }
      break;
    }

    // 14. ROUGH SLATE MINERAL
    case 'rough_slate': {
      ctx.globalAlpha = alpha;
      for (let i = 0; i < 300; i++) {
        const sx = rand() * w;
        const sy = rand() * h;
        const sW = 4 + rand() * 12;
        const sH = 1 + rand() * 3;
        ctx.fillStyle = rand() > 0.5 ? 'rgba(255, 255, 255, 0.14)' : 'rgba(0, 0, 0, 0.2)';
        ctx.fillRect(sx, sy, sW, sH);
      }
      break;
    }

    // 15. BLUEPRINT GRID & RULED
    case 'grid': {
      ctx.globalAlpha = alpha;
      const smallGrid = 16;
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.12)';
      ctx.lineWidth = 0.75;
      for (let x = 0; x < w; x += smallGrid) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += smallGrid) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }
      break;
    }

    case 'ruled': {
      ctx.globalAlpha = alpha;
      const lineDist = 24;
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.2)';
      ctx.lineWidth = 1;
      for (let y = 30; y < h; y += lineDist) {
        ctx.beginPath();
        ctx.moveTo(20, y);
        ctx.lineTo(w - 20, y);
        ctx.stroke();
      }
      break;
    }

    case 'dotted': {
      ctx.globalAlpha = alpha;
      const dotSpacing = 18;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
      for (let y = 18; y < h; y += dotSpacing) {
        for (let x = 18; x < w; x += dotSpacing) {
          ctx.beginPath();
          ctx.arc(x, y, 1.2, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      break;
    }

    // 16. GRAIN & PARCHMENT DEFAULT
    case 'grain':
    case 'parchment':
    case 'cotton_rag':
    case 'cotton_paper':
    default: {
      ctx.globalAlpha = alpha;
      const dots = Math.round((w * h) / 400);
      for (let i = 0; i < dots; i++) {
        const gx = rand() * w;
        const gy = rand() * h;
        const isBright = rand() > 0.5;
        ctx.fillStyle = isBright ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.08)';
        ctx.fillRect(gx, gy, 1.2, 1.2);
      }
      break;
    }
  }

  ctx.restore();
}
