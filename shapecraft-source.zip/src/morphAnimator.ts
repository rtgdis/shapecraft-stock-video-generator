import { ShapeState, MotionPreset } from './types';
import { getShapePathString } from './shapeRenderer';
import { drawMaterialTextureToCanvas } from './materialTextures';

// Math & Easing Helpers
function easeOutCubic(x: number): number {
  return 1 - Math.pow(1 - x, 3);
}

function easeInCubic(x: number): number {
  return x * x * x;
}

function easeOutBack(x: number, c1 = 1.70158): number {
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
}

function clamp(val: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, val));
}

function pseudoRandom(seed: number) {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

// Draw text inside paper container if hideText is false
function drawContainerTypography(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  alpha: number = 1
) {
  if (state.hideText || !state.textContent) return;

  ctx.save();
  ctx.globalAlpha = clamp(alpha, 0, 1);
  ctx.fillStyle = state.fontColor || '#292524';
  const size = state.fontSize || Math.max(16, Math.min(w * 0.055, 28));
  const weight = state.fontWeight || '600';
  const family = state.fontFamily || 'Inter, sans-serif';
  ctx.font = `${weight} ${size}px ${family}`;
  ctx.textAlign = (state.textAlign as CanvasTextAlign) || 'center';
  ctx.textBaseline = 'middle';

  const lines = state.textContent.split('\n');
  const lineHeight = size * 1.35;
  const totalH = lines.length * lineHeight;
  let startY = h / 2 - totalH / 2 + lineHeight / 2;

  const textX = state.textAlign === 'left' ? w * 0.12 : state.textAlign === 'right' ? w * 0.88 : w / 2;

  lines.forEach((line) => {
    ctx.fillText(line, textX, startY);
    startY += lineHeight;
  });

  ctx.restore();
}

// Clean finished shape renderer during hold
function drawFinishedCleanPaper(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  path2d: Path2D
) {
  ctx.save();
  // Drop shadow
  if ((state.shadowOpacity || 0) > 0) {
    ctx.shadowColor = `rgba(0, 0, 0, ${(state.shadowOpacity || 15) / 100})`;
    ctx.shadowBlur = state.shadowBlur || 20;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = state.shadowDistance || 8;
  }

  ctx.fillStyle = state.bgColor;
  ctx.fill(path2d);

  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;

  if (state.textureType && state.textureType !== 'none' && (state.textureOpacity || 0) > 0) {
    drawMaterialTextureToCanvas(ctx, state.textureType, state.textureOpacity || 50, w, h, path2d, state.creaseSeed || 1);
  }

  if (state.borderStyle !== 'none' && (state.borderWidth || 0) > 0) {
    ctx.strokeStyle = state.borderColor;
    ctx.lineWidth = state.borderWidth;
    if (state.borderStyle === 'dashed') ctx.setLineDash([8, 6]);
    else if (state.borderStyle === 'dotted') ctx.setLineDash([3, 4]);
    else ctx.setLineDash([]);
    ctx.stroke(path2d);
    ctx.setLineDash([]);
  }

  drawContainerTypography(ctx, state, w, h, 1);
  ctx.restore();
}

/**
 * =========================================================================
 * 1. PAPER REVEAL (Judul Teks / Editorial Cardstock Slide & Fold Reveal)
 * Kertas masuk dari samping -> sedikit terbuka/terlipat -> teks muncul -> hold 4s -> keluar
 * =========================================================================
 */
export function drawPaperReveal(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let textAlpha = 1;
  let slideX = 0;
  let foldAngle = 0; // 0 deg flat

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutCubic(rawP), 0, 1);
    slideX = (1 - progress) * -240; // Slide from left
    foldAngle = (1 - progress) * -8; // Slight tilt
    textAlpha = rawP > 0.45 ? (rawP - 0.45) / 0.55 : 0;
  } else if (time <= holdEnd) {
    progress = 1;
    slideX = 0;
    foldAngle = 0;
    textAlpha = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    slideX = easeInCubic(outP) * 260; // Slide to right
    foldAngle = easeInCubic(outP) * 6;
    textAlpha = 1 - outP * 2;
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2 + slideX, -h / 2);

  if (foldAngle !== 0) {
    ctx.translate(w / 2, h / 2);
    ctx.rotate((foldAngle * Math.PI) / 180);
    ctx.translate(-w / 2, -h / 2);
  }

  // Draw paper base
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.14)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;
  ctx.fillStyle = state.bgColor;
  ctx.fill(path2d);
  ctx.restore();

  // Texture
  if (state.textureType && state.textureType !== 'none' && (state.textureOpacity || 0) > 0) {
    drawMaterialTextureToCanvas(ctx, state.textureType, state.textureOpacity || 50, w, h, path2d, state.creaseSeed || 1);
  }

  // Subtle paper fold dog-ear crease line on top corner
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(w - 36, 0);
  ctx.lineTo(w - 36, 36);
  ctx.lineTo(w, 36);
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.12)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();

  // Border
  if (state.borderStyle !== 'none' && (state.borderWidth || 0) > 0) {
    ctx.strokeStyle = state.borderColor;
    ctx.lineWidth = state.borderWidth;
    ctx.stroke(path2d);
  }

  // Text content
  drawContainerTypography(ctx, state, w, h, textAlpha);

  ctx.restore();
}

/**
 * =========================================================================
 * 2. TORN PAPER TEXT (Sobekan Kertas Editorial Bertekstur Serat Deckle Edge)
 * Potongan kertas sobek masuk -> terbuka -> teks muncul -> sedikit bergerak -> keluar
 * =========================================================================
 */
export function drawTornPaperText(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let textAlpha = 1;
  let translateY = 0;
  let rot = 0;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.3), 0, 1);
    translateY = (1 - easeOutCubic(rawP)) * 140;
    rot = (1 - progress) * -4;
    textAlpha = rawP > 0.4 ? (rawP - 0.4) / 0.6 : 0;
  } else if (time <= holdEnd) {
    const holdProgress = (time - holdStart) / (holdEnd - holdStart);
    progress = 1;
    translateY = Math.sin(holdProgress * Math.PI * 2) * 3;
    rot = Math.cos(holdProgress * Math.PI * 2) * 0.4;
    textAlpha = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    translateY = easeInCubic(outP) * 160;
    rot = easeInCubic(outP) * 5;
    textAlpha = 1 - outP * 1.8;
  }

  ctx.save();
  ctx.translate(-w / 2, -h / 2 + translateY);

  if (rot !== 0) {
    ctx.translate(w / 2, h / 2);
    ctx.rotate((rot * Math.PI) / 180);
    ctx.translate(-w / 2, -h / 2);
  }

  // Draw torn paper polygon with jagged fiber deckle edge top and bottom
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(0, 20);

  // Top torn edge
  const steps = 24;
  for (let i = 0; i <= steps; i++) {
    const tx = (i / steps) * w;
    const ty = (pseudoRandom(i * 17) - 0.5) * 8;
    ctx.lineTo(tx, ty);
  }

  ctx.lineTo(w, h - 20);

  // Bottom torn edge
  for (let i = steps; i >= 0; i--) {
    const bx = (i / steps) * w;
    const by = h + (pseudoRandom(i * 23) - 0.5) * 8;
    ctx.lineTo(bx, by);
  }
  ctx.closePath();

  ctx.shadowColor = 'rgba(0, 0, 0, 0.16)';
  ctx.shadowBlur = 22;
  ctx.shadowOffsetY = 10;
  ctx.fillStyle = state.bgColor;
  ctx.fill();

  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;

  // Paper fiber texture
  if (state.textureType && state.textureType !== 'none' && (state.textureOpacity || 0) > 0) {
    const path2d = new Path2D();
    path2d.rect(0, 0, w, h);
    drawMaterialTextureToCanvas(ctx, state.textureType, state.textureOpacity || 50, w, h, path2d, state.creaseSeed || 1);
  }

  // Deckle fiber line on top and bottom
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
  ctx.lineWidth = 1.2;
  ctx.stroke();

  ctx.restore();

  drawContainerTypography(ctx, state, w, h, textAlpha);

  ctx.restore();
}

/**
 * =========================================================================
 * 3. STICKY NOTE COLLECTION (Sticky Note Tilt Drop & Tip/Checklist Text)
 * Satu sticky note muncul miring -> Teks tips/checklist masuk bertahap -> keluar
 * =========================================================================
 */
export function drawStickyNoteSequence(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let textAlpha = 1;
  let dropY = 0;
  let tilt = -2.5;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.35), 0, 1);
    dropY = (1 - easeOutCubic(rawP)) * -180;
    tilt = -2.5 + (1 - rawP) * 12;
    textAlpha = rawP > 0.4 ? (rawP - 0.4) / 0.6 : 0;
  } else if (time <= holdEnd) {
    progress = 1;
    dropY = 0;
    tilt = -2.5;
    textAlpha = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    dropY = -easeInCubic(outP) * 220; // Float up as if blown by wind
    tilt = -2.5 - outP * 15;
    textAlpha = 1 - outP * 2;
  }

  ctx.save();
  ctx.translate(-w / 2, -h / 2 + dropY);

  ctx.translate(w / 2, h / 2);
  ctx.rotate((tilt * Math.PI) / 180);
  ctx.translate(-w / 2, -h / 2);

  // 1. Realistic Curved Corner Drop Shadow (Sticky note adhesive at top, loose at bottom)
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.18)';
  ctx.shadowBlur = 20;
  ctx.shadowOffsetX = 2;
  ctx.shadowOffsetY = 12;

  // Base sticky square
  const noteBg = state.bgColor || '#fef08a'; // Pastel Yellow
  ctx.fillStyle = noteBg;
  ctx.beginPath();
  ctx.roundRect(0, 0, w, h, 4);
  ctx.fill();
  ctx.restore();

  // 2. Adhesive strip line at top
  ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
  ctx.fillRect(0, 0, w, 28);

  // 3. Texture
  if (state.textureType && state.textureType !== 'none' && (state.textureOpacity || 0) > 0) {
    const path2d = new Path2D();
    path2d.roundRect(0, 0, w, h, 4);
    drawMaterialTextureToCanvas(ctx, state.textureType, state.textureOpacity || 40, w, h, path2d, state.creaseSeed || 1);
  }

  // 4. Clean blank container or user custom typography if enabled
  drawContainerTypography(ctx, state, w, h, textAlpha);

  ctx.restore();
}

/**
 * =========================================================================
 * 4. TAPE + PAPER (Kertas Ditempel Washi / Masking Tape Realistis)
 * Kertas muncul -> ditempel masking tape washi -> teks muncul -> tape peel off
 * =========================================================================
 */
export function drawTapeAndPaper(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let tapeSlap = 0; // 0 -> 1 when tape drops on paper
  let textAlpha = 1;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.2), 0, 1);
    tapeSlap = rawP > 0.35 ? clamp((rawP - 0.35) / 0.3, 0, 1) : 0;
    textAlpha = rawP > 0.6 ? (rawP - 0.6) / 0.4 : 0;
  } else if (time <= holdEnd) {
    progress = 1;
    tapeSlap = 1;
    textAlpha = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    tapeSlap = 1 - outP;
    textAlpha = 1 - outP * 2;
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  // Base Paper Card
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.16)';
  ctx.shadowBlur = 22;
  ctx.shadowOffsetY = 10;
  ctx.fillStyle = state.bgColor;
  ctx.fill(path2d);
  ctx.restore();

  if (state.textureType && state.textureType !== 'none' && (state.textureOpacity || 0) > 0) {
    drawMaterialTextureToCanvas(ctx, state.textureType, state.textureOpacity || 50, w, h, path2d, state.creaseSeed || 1);
  }

  if (state.borderStyle !== 'none' && (state.borderWidth || 0) > 0) {
    ctx.strokeStyle = state.borderColor;
    ctx.lineWidth = state.borderWidth;
    ctx.stroke(path2d);
  }

  // Draw Washi Tape Strips Slapped on Top-Left and Top-Right Corners
  if (tapeSlap > 0.05) {
    const tapeAlpha = clamp(tapeSlap * 1.5, 0, 0.85);

    // Left Diagonal Washi Tape Strip
    ctx.save();
    ctx.translate(30, -10);
    ctx.rotate((-25 * Math.PI) / 180);
    ctx.fillStyle = `rgba(224, 210, 185, ${tapeAlpha})`; // Semi-translucent kraft tape
    ctx.shadowColor = 'rgba(0, 0, 0, 0.12)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetY = 2;
    ctx.fillRect(-60, 0, 120, 26);
    // Torn fiber ends
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.lineWidth = 1;
    ctx.strokeRect(-60, 0, 120, 26);
    ctx.restore();

    // Right Diagonal Washi Tape Strip
    ctx.save();
    ctx.translate(w - 30, -10);
    ctx.rotate((25 * Math.PI) / 180);
    ctx.fillStyle = `rgba(224, 210, 185, ${tapeAlpha})`;
    ctx.shadowColor = 'rgba(0, 0, 0, 0.12)';
    ctx.shadowBlur = 6;
    ctx.shadowOffsetY = 2;
    ctx.fillRect(-60, 0, 120, 26);
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.lineWidth = 1;
    ctx.strokeRect(-60, 0, 120, 26);
    ctx.restore();
  }

  drawContainerTypography(ctx, state, w, h, textAlpha);

  ctx.restore();
}

/**
 * =========================================================================
 * 5. LAYERED SCRAPBOOK (Paper + Polaroid Photo Frame + Washi Tape + Text)
 * Komposisi berlapis scrapbook digital premium untuk travel, lifestyle, memories
 * =========================================================================
 */
export function drawLayeredScrapbook(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.5 : 1.3;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.15), 0, 1);
  } else if (time <= holdEnd) {
    progress = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
  }

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  const cx = w / 2;
  const cy = h / 2;

  // 1. Layer 1: Base Kraft / Linen Paper Sheet (Tilt -2°)
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate((-2 * Math.PI) / 180);
  ctx.translate(-cx, -cy);

  ctx.shadowColor = 'rgba(0, 0, 0, 0.15)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;
  ctx.fillStyle = '#f5f0ea';
  ctx.beginPath();
  ctx.roundRect(10, 10, w - 20, h - 20, 8);
  ctx.fill();
  ctx.restore();

  // 2. Layer 2: Polaroid Cutout Frame on Left (Tilt +3°)
  const frameW = Math.min(w * 0.38, 200);
  const frameH = frameW * 1.22;

  ctx.save();
  ctx.translate(35, cy - frameH / 2);
  ctx.rotate((3.5 * Math.PI) / 180);

  ctx.shadowColor = 'rgba(0, 0, 0, 0.12)';
  ctx.shadowBlur = 14;
  ctx.shadowOffsetY = 6;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, frameW, frameH);

  // Photo Inner Window (Empty / Placeholder for Buyer's footage)
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(12, 12, frameW - 24, frameW - 24);

  // Washi Tape over Polaroid Frame
  ctx.fillStyle = 'rgba(217, 119, 6, 0.55)'; // Amber washi tape
  ctx.fillRect(frameW / 2 - 35, -8, 70, 18);
  ctx.restore();

  // 3. Layer 3: Main Blank Editorial Text Container Area on Right
  ctx.save();
  ctx.translate(w * 0.42, 30);
  const textAreaW = w * 0.54;
  const textAreaH = h - 60;

  // Render user text only if not hidden and provided
  drawContainerTypography(ctx, state, textAreaW, textAreaH, 1);

  ctx.restore();
  ctx.restore();
}

/**
 * =========================================================================
 * 6. PAPER STACK TITLES (Tumpukan 2-3 Kertas Bergeser: Title + Subtitle)
 * =========================================================================
 */
export function drawPaperStackTitles(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let stagger2 = 1;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.25), 0, 1);
    stagger2 = rawP > 0.2 ? clamp(easeOutBack((rawP - 0.2) / 0.8, 1.2), 0, 1) : 0;
  } else if (time <= holdEnd) {
    progress = 1;
    stagger2 = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    stagger2 = 1 - easeInCubic(outP);
  }

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  // Stack 1: Bottom Sheet (Title Container)
  const bottomSlide = (1 - progress) * -160;
  ctx.save();
  ctx.translate(bottomSlide, 0);
  ctx.shadowColor = 'rgba(0, 0, 0, 0.16)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 10;
  ctx.fillStyle = state.bgColor;
  ctx.beginPath();
  ctx.roundRect(0, 0, w, h * 0.72, 8);
  ctx.fill();

  // Title Text
  drawContainerTypography(ctx, state, w, h * 0.72, progress);
  ctx.restore();

  // Stack 2: Subtitle Card overlapping at bottom-right (Blank contrast copy space)
  const subW = w * 0.62;
  const subH = h * 0.38;
  const subSlide = (1 - stagger2) * 160;

  ctx.save();
  ctx.translate(w - subW + subSlide, h * 0.62);
  ctx.shadowColor = 'rgba(0, 0, 0, 0.18)';
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  ctx.fillStyle = '#292524'; // Dark contrast card
  ctx.beginPath();
  ctx.roundRect(0, 0, subW, subH, 6);
  ctx.fill();

  ctx.restore();
  ctx.restore();
}

/**
 * =========================================================================
 * 7. HANDWRITTEN + PAPER (Kertas Editorial + Aksen Tulisan Tangan / Underline)
 * =========================================================================
 */
export function drawHandwrittenPaper(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let markProgress = 1;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutCubic(rawP), 0, 1);
    markProgress = rawP > 0.5 ? clamp((rawP - 0.5) / 0.5, 0, 1) : 0;
  } else if (time <= holdEnd) {
    progress = 1;
    markProgress = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    markProgress = 1 - outP;
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  ctx.shadowColor = 'rgba(0, 0, 0, 0.14)';
  ctx.shadowBlur = 24;
  ctx.shadowOffsetY = 8;
  ctx.fillStyle = state.bgColor;
  ctx.fill(path2d);

  // Handwritten Brush Underline drawn in real time
  if (markProgress > 0.05) {
    ctx.save();
    ctx.strokeStyle = '#dc2626'; // Editorial Crimson Pen Mark
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    const startX = w * 0.18;
    const endX = startX + w * 0.64 * markProgress;
    const markY = h * 0.76;
    ctx.moveTo(startX, markY);
    ctx.quadraticCurveTo(startX + (endX - startX) * 0.5, markY + 4, endX, markY - 2);
    ctx.stroke();
    ctx.restore();
  }

  drawContainerTypography(ctx, state, w, h, progress);

  ctx.restore();
}

/**
 * =========================================================================
 * 8. PAPER WINDOW / MASK (Kertas Membuka dari Tengah -> Text -> Menutup)
 * =========================================================================
 */
export function drawPaperWindowMask(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let openP = 1; // 0 (closed mask) -> 1 (open window)

  if (time < holdStart) {
    const rawP = time / holdStart;
    openP = clamp(easeOutCubic(rawP), 0, 1);
  } else if (time <= holdEnd) {
    openP = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    openP = 1 - easeInCubic(outP);
  }

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  const splitGap = openP * (w * 0.5);

  // Left Paper Flap
  ctx.save();
  ctx.fillStyle = state.bgColor;
  ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
  ctx.shadowBlur = 18;
  ctx.fillRect(-splitGap, 0, w / 2, h);
  ctx.restore();

  // Right Paper Flap
  ctx.save();
  ctx.fillStyle = state.bgColor;
  ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
  ctx.shadowBlur = 18;
  ctx.fillRect(w / 2 + splitGap, 0, w / 2, h);
  ctx.restore();

  // Text Content revealed in the center window
  drawContainerTypography(ctx, state, w, h, openP);

  ctx.restore();
}

/**
 * =========================================================================
 * 9. FLOATING PAPER LABELS (Label Kertas Kecil Minimalis: NEW, TIP, 01, NOTE)
 * =========================================================================
 */
export function drawFloatingPaperLabels(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.2 : 1.0;
  const outDur = duration >= 7 ? 1.2 : 1.0;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let floatY = 0;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.4), 0, 1);
  } else if (time <= holdEnd) {
    const holdP = (time - holdStart) / (holdEnd - holdStart);
    progress = 1;
    floatY = Math.sin(holdP * Math.PI * 2) * 4;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2, -h / 2 + floatY);

  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.scale(progress, progress);
  ctx.translate(-w / 2, -h / 2);

  ctx.shadowColor = 'rgba(0, 0, 0, 0.16)';
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  ctx.fillStyle = state.bgColor;
  ctx.fill(path2d);

  if (state.borderStyle !== 'none' && (state.borderWidth || 0) > 0) {
    ctx.strokeStyle = state.borderColor;
    ctx.lineWidth = state.borderWidth;
    ctx.stroke(path2d);
  }

  drawContainerTypography(ctx, state, w, h, 1);
  ctx.restore();
  ctx.restore();
}

/**
 * =========================================================================
 * 10. 3D CRUMPLED PAPER UNFOLD (Bola Kertas Kusut 3D -> Lembaran Rapi)
 * =========================================================================
 */
export function drawCrumpledPaperUnfold(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let unfoldProgress = 1;

  if (time < holdStart) {
    const rawP = time / holdStart;
    unfoldProgress = clamp(easeOutBack(rawP, 1.25), 0, 1);
  } else if (time <= holdEnd) {
    unfoldProgress = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    unfoldProgress = 1 - easeInCubic(outP);
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  if (unfoldProgress >= 0.999) {
    drawFinishedCleanPaper(ctx, state, w, h, path2d);
    ctx.restore();
    return;
  }

  const cx = w / 2;
  const cy = h / 2;
  const crumpleAmount = 1 - unfoldProgress;
  const seed = (state.creaseSeed || 42) + 77;

  // Spherical 3D Crumpled Paper Ball
  if (crumpleAmount > 0.65) {
    const ballStage = (crumpleAmount - 0.65) / 0.35;
    const ballRadius = Math.min(w, h) * (0.22 + (1 - ballStage) * 0.18);
    const ballRot = (1 - unfoldProgress) * 75 * (Math.PI / 180);

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(ballRot);

    ctx.beginPath();
    ctx.arc(0, 0, ballRadius, 0, Math.PI * 2);
    ctx.fillStyle = state.bgColor;
    ctx.fill();

    for (let i = 0; i < 18; i++) {
      const a1 = (i / 18) * Math.PI * 2;
      const a2 = ((i + 1) / 18) * Math.PI * 2;
      const r1 = ballRadius * (0.65 + pseudoRandom(seed + i) * 0.35);

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(a1) * r1, Math.sin(a1) * r1);
      ctx.lineTo(Math.cos(a2) * ballRadius, Math.sin(a2) * ballRadius);
      ctx.closePath();

      ctx.fillStyle = i % 2 === 0 ? 'rgba(0, 0, 0, 0.35)' : 'rgba(255, 255, 255, 0.35)';
      ctx.fill();

      ctx.strokeStyle = 'rgba(0, 0, 0, 0.45)';
      ctx.lineWidth = 1.8;
      ctx.stroke();
    }

    const bGrad = ctx.createRadialGradient(0, -ballRadius * 0.3, 5, 0, 0, ballRadius);
    bGrad.addColorStop(0, 'rgba(255,255,255,0.4)');
    bGrad.addColorStop(0.6, 'rgba(0,0,0,0.15)');
    bGrad.addColorStop(1, 'rgba(0,0,0,0.65)');
    ctx.fillStyle = bGrad;
    ctx.beginPath();
    ctx.arc(0, 0, ballRadius, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // Unfurling sheet
  const sheetScale = 0.4 + unfoldProgress * 0.6;
  const rotAngle = (1 - unfoldProgress) * 35 * (Math.PI / 180);

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rotAngle);
  ctx.scale(sheetScale, sheetScale);
  ctx.translate(-cx, -cy);

  ctx.globalAlpha = clamp(unfoldProgress * 2.2, 0, 1);
  ctx.fillStyle = state.bgColor;
  ctx.fill(path2d);

  ctx.save();
  ctx.clip(path2d);

  const numFacets = 22;
  for (let i = 0; i < numFacets; i++) {
    const x1 = pseudoRandom(seed + i * 7) * w;
    const y1 = pseudoRandom(seed + i * 7 + 1) * h;
    const x2 = pseudoRandom(seed + i * 7 + 2) * w;
    const y2 = pseudoRandom(seed + i * 7 + 3) * h;
    const x3 = pseudoRandom(seed + i * 7 + 4) * w;
    const y3 = pseudoRandom(seed + i * 7 + 5) * h;

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.closePath();

    ctx.fillStyle = i % 2 === 0
      ? `rgba(255, 255, 255, ${crumpleAmount * 0.35})`
      : `rgba(0, 0, 0, ${crumpleAmount * 0.4})`;
    ctx.fill();

    ctx.strokeStyle = `rgba(0, 0, 0, ${crumpleAmount * 0.5})`;
    ctx.lineWidth = 1 + crumpleAmount * 2.5;
    ctx.stroke();
  }

  ctx.restore();

  if (state.borderStyle !== 'none' && (state.borderWidth || 0) > 0) {
    ctx.strokeStyle = state.borderColor;
    ctx.lineWidth = state.borderWidth;
    ctx.stroke(path2d);
  }

  ctx.restore();
  ctx.restore();
}

/**
 * =========================================================================
 * 11. SHATTER ASSEMBLE (Voronoi Shatter Reassembly)
 * =========================================================================
 */
export function drawShatterAssemble(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  const cx = w / 2;
  const cy = h / 2;
  const numShards = 18;

  let progress = 1;
  let seamGlow = 0;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.2), 0, 1);
    if (rawP > 0.8) seamGlow = Math.sin(((rawP - 0.8) / 0.2) * Math.PI);
  } else if (time <= holdEnd) {
    progress = 1;
    seamGlow = 0;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    seamGlow = outP < 0.2 ? Math.sin((outP / 0.2) * Math.PI) : 0;
  }

  if (progress >= 0.999 && seamGlow <= 0.01) {
    ctx.save();
    ctx.translate(-w / 2, -h / 2);
    drawFinishedCleanPaper(ctx, state, w, h, path2d);
    ctx.restore();
    return;
  }

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  const shardAngles: number[] = [];
  for (let i = 0; i < numShards; i++) {
    const baseAngle = (i / numShards) * Math.PI * 2;
    const jitter = (pseudoRandom(i * 19 + (state.creaseSeed || 1)) - 0.5) * 0.3;
    shardAngles.push(baseAngle + jitter);
  }
  shardAngles.push(shardAngles[0] + Math.PI * 2);

  const scatterDist = (1 - progress) * Math.max(w, h) * 1.15;

  for (let i = 0; i < numShards; i++) {
    const a1 = shardAngles[i];
    const a2 = shardAngles[i + 1];
    const midA = (a1 + a2) / 2;

    const seed = i * 31 + (state.creaseSeed || 1);
    const angleOffset = (pseudoRandom(seed + 1) - 0.5) * 0.5;
    const speedMult = 0.85 + pseudoRandom(seed + 2) * 0.45;
    const rotSpeed = (pseudoRandom(seed + 3) - 0.5) * 75 * (1 - progress);

    const dx = Math.cos(midA + angleOffset) * scatterDist * speedMult;
    const dy = Math.sin(midA + angleOffset) * scatterDist * speedMult;

    ctx.save();
    ctx.translate(cx + dx, cy + dy);
    ctx.rotate((rotSpeed * Math.PI) / 180);
    ctx.translate(-(cx + dx), -(cy + dy));

    ctx.beginPath();
    ctx.moveTo(cx, cy);
    const r = Math.max(w, h) * 1.6;
    ctx.lineTo(cx + Math.cos(a1) * r, cy + Math.sin(a1) * r);
    ctx.lineTo(cx + Math.cos(a2) * r, cy + Math.sin(a2) * r);
    ctx.closePath();

    ctx.save();
    ctx.clip();
    ctx.fillStyle = state.bgColor;
    ctx.globalAlpha = clamp(progress * 1.8 + 0.1, 0, 1);
    ctx.fill(path2d);

    ctx.strokeStyle = seamGlow > 0 ? `rgba(255, 255, 255, ${0.4 + seamGlow * 0.6})` : 'rgba(0, 0, 0, 0.2)';
    ctx.lineWidth = seamGlow > 0 ? 2 + seamGlow * 2 : 1.2;
    ctx.stroke();

    ctx.restore();
    ctx.restore();
  }

  if (seamGlow > 0.05) {
    ctx.strokeStyle = `rgba(255, 255, 255, ${seamGlow * 0.85})`;
    ctx.lineWidth = 3 + seamGlow * 4;
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 18 * seamGlow;
    ctx.stroke(path2d);
  }

  ctx.restore();
}

/**
 * =========================================================================
 * 12. SPEED WIND COMIC MORPH (Anime Speedlines & Wind Slashes)
 * =========================================================================
 */
export function drawSpeedWindComicMorph(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;
  let windAlpha = 0;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.4), 0, 1);
    windAlpha = 1 - easeOutCubic(rawP);
  } else if (time <= holdEnd) {
    progress = 1;
    windAlpha = 0;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
    windAlpha = easeInCubic(outP);
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  const cx = w / 2;
  const cy = h / 2;

  if (windAlpha > 0.01) {
    ctx.save();
    const numLines = 28;
    for (let i = 0; i < numLines; i++) {
      const angle = (i / numLines) * Math.PI * 2 + (pseudoRandom(i * 13) - 0.5) * 0.2;
      const length = Math.max(w, h) * (0.6 + pseudoRandom(i * 17) * 0.8);
      const startDist = Math.max(w, h) * (0.35 + (1 - progress) * 0.4);

      const x1 = cx + Math.cos(angle) * (startDist + length);
      const y1 = cy + Math.sin(angle) * (startDist + length);
      const x2 = cx + Math.cos(angle) * startDist;
      const y2 = cy + Math.sin(angle) * startDist;

      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.strokeStyle = i % 3 === 0 ? `rgba(6, 182, 212, ${windAlpha * 0.7})` : `rgba(255, 255, 255, ${windAlpha * 0.85})`;
      ctx.lineWidth = 1.5 + pseudoRandom(i * 7) * 3.5;
      ctx.stroke();
    }
    ctx.restore();
  }

  if (progress >= 0.999 && windAlpha <= 0.01) {
    drawFinishedCleanPaper(ctx, state, w, h, path2d);
    ctx.restore();
    return;
  }

  ctx.save();
  ctx.translate(cx, cy);
  const scale = 0.3 + progress * 0.7;
  ctx.scale(scale, scale);
  ctx.translate(-cx, -cy);

  ctx.fillStyle = state.bgColor;
  ctx.globalAlpha = clamp(progress * 1.5, 0, 1);
  ctx.fill(path2d);

  drawContainerTypography(ctx, state, w, h, progress);

  ctx.restore();
  ctx.restore();
}

/**
 * =========================================================================
 * 13. WEDDING RIBBON & FLORAL UNFURL
 * =========================================================================
 */
export function drawWeddingRibbonFloralUnfurl(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number,
  duration: number
) {
  const inDur = duration >= 7 ? 1.5 : 1.3;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  let progress = 1;

  if (time < holdStart) {
    const rawP = time / holdStart;
    progress = clamp(easeOutBack(rawP, 1.15), 0, 1);
  } else if (time <= holdEnd) {
    progress = 1;
  } else {
    const outP = (time - holdEnd) / outDur;
    progress = 1 - easeInCubic(outP);
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  if (progress >= 0.999) {
    drawFinishedCleanPaper(ctx, state, w, h, path2d);
    ctx.restore();
    return;
  }

  ctx.fillStyle = state.bgColor;
  ctx.globalAlpha = progress;
  ctx.fill(path2d);

  drawContainerTypography(ctx, state, w, h, progress);

  ctx.restore();
}
