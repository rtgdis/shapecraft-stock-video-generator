import { ShapeType } from './types';

export interface ShapeDefinition {
  id: ShapeType | string;
  label: string;
  desc: string;
  category: 'text_container' | 'comment' | 'postcard' | 'greeting_card' | 'tape' | 'tag_bookmark';
  icon: string;
}

export const ALL_SHAPES: ShapeDefinition[] = [
  // --- 1. WADAH TEKS & LABEL MINIMALIS (10 BENTUK) ---
  { id: 'clean_minimal_card', label: 'Kartu Teks Minimalis', desc: 'Wadah serbaguna sudut halus 1.58:1', category: 'text_container', icon: '📄' },
  { id: 'smooth_pill_badge', label: 'Kapsul Pill Badge', desc: 'Badge kapsul modern horizontal 3.2:1', category: 'text_container', icon: '🏷️' },
  { id: 'arch_monoline_frame', label: 'Kubah Portal Arch', desc: 'Frame kubah arsitektural estetika boho', category: 'text_container', icon: '🏛️' },
  { id: 'chamfered_hex_label', label: 'Label Sudut Bevel 45°', desc: 'Tag sudut bevel terpotong geometris', category: 'text_container', icon: '📐' },
  { id: 'modern_square_memo', label: 'Memo Kubus Minimalis', desc: 'Kertas memo bujur sangkar 1:1', category: 'text_container', icon: '📓' },
  { id: 'scallop_border_plate', label: 'Plat Teks Scallop Renda', desc: 'Plat elegan gerigi gelombang scallop', category: 'text_container', icon: '🌸' },
  { id: 'curved_corner_plaque', label: 'Plakat Sudut Cekung', desc: 'Plakat cartouche sudut melengkung mewah', category: 'text_container', icon: '⚜️' },
  { id: 'soft_circle_badge', label: 'Badge Segel Lingkaran', desc: 'Segel bulat lingkaran stempel & logo', category: 'text_container', icon: '🔘' },
  { id: 'folded_corner_sheet', label: 'Kertas Lipat Dog-Ear', desc: 'Dokumen dengan lipatan sudut realistis', category: 'text_container', icon: '📑' },
  { id: 'minimal_quote_box', label: 'Kotak Kutipan Editorial', desc: 'Wadah kutipan bergaris aksen vertikal', category: 'text_container', icon: '💬' },

  // --- 2. KOMENTAR & BALON DIALOG (6 BENTUK) ---
  { id: 'clean_speech_bubble', label: 'Balon Komentar Halus', desc: 'Balon kata bulat dengan ekor dialog lancip', category: 'comment', icon: '💬' },
  { id: 'minimal_chat_pill', label: 'Balon Chat Messenger', desc: 'UI bubble chat modern takik sudut lancip', category: 'comment', icon: '💭' },
  { id: 'thought_dialog_cloud', label: 'Balon Awan Pikiran', desc: 'Awan dialog lembut dengan 2 titik satelit', category: 'comment', icon: '☁️' },
  { id: 'quote_dialog_card', label: 'Kotak Ulasan & Testimoni', desc: 'Kotak kartu testimoni dengan notch tengah', category: 'comment', icon: '⭐' },
  { id: 'curved_dialog_box', label: 'Balon Percakapan Dinamis', desc: 'Balon kata dengan ekor meliuk organik', category: 'comment', icon: '🍃' },
  { id: 'action_callout_badge', label: 'Balon Seruan 12-Point', desc: 'Lencana seruan aksi promo e-commerce', category: 'comment', icon: '💥' },

  // --- 3. POSTCARD & KARTU FOTO (5 BENTUK) ---
  { id: 'blank_classic_postcard', label: 'Kartu Pos Klasik 3:2', desc: 'Format pos internasional pembagi tengah & prangko', category: 'postcard', icon: '📮' },
  { id: 'vertical_art_postcard', label: 'Postcard Vertikal Galeri', desc: 'Kartu pos seni potret 2:3 frame cetak foto', category: 'postcard', icon: '🖼️' },
  { id: 'airmail_clean_postcard', label: 'Postcard Pos Udara Airmail', desc: 'Kartu pos airmail klasik dengan cap pos halus', category: 'postcard', icon: '✈️' },
  { id: 'vintage_grid_postcard', label: 'Kartu Pos Garis Alamat', desc: 'Kartu pos bergaris panduan alamat vintage', category: 'postcard', icon: '✉️' },
  { id: 'square_mini_postcard', label: 'Kartu Foto Persegi 1:1', desc: 'Foto mini 1:1 kontemporer gaya instagram', category: 'postcard', icon: '📸' },

  // --- 4. KARTU UCAPAN & UNDANGAN (6 BENTUK) ---
  { id: 'folded_greeting_card', label: 'Kartu Lipat Bifold 3D', desc: 'Kartu ucapan bifold dengan lipatan tulang realistis', category: 'greeting_card', icon: '💌' },
  { id: 'vertical_arch_greeting', label: 'Undangan Kubah Arch Mewah', desc: 'Undangan kubah favorit pernikahan & gala', category: 'greeting_card', icon: '💒' },
  { id: 'pocket_gift_card', label: 'Kartu Saku Voucher Amplop', desc: 'Voucher kartu terselip di saku amplop pouch', category: 'greeting_card', icon: '🎁' },
  { id: 'deckle_edge_greeting', label: 'Kartu Kertas Katun Deckle', desc: 'Kertas katun handmade pinggiran sobek alami', category: 'greeting_card', icon: '📜' },
  { id: 'ribbon_tied_card', label: 'Kartu Aksen Celah Pita', desc: 'Kartu undangan dengan celah sematan pita sutra', category: 'greeting_card', icon: '🎀' },
  { id: 'double_border_invitation', label: 'Undangan Garis Lis Ganda', desc: 'Stationery formal bergaris lis ganda elegan', category: 'greeting_card', icon: '🎖️' },

  // --- 5. TAPE LAKBAN & WASHI (7 BENTUK) ---
  { id: 'straight_washi_tape', label: 'Lakban Washi Lurus', desc: 'Strip washi jepang semi-transparan ujung lurus', category: 'tape', icon: '🩹' },
  { id: 'torn_masking_tape', label: 'Lakban Masking Ujung Sobek', desc: 'Isolasi kertas dengan serat robek bergerigi', category: 'tape', icon: '📜' },
  { id: 'diagonal_tape_strip', label: 'Lakban Sudut Miring', desc: 'Potongan isolasi miring untuk sudut bingkai', category: 'tape', icon: '📐' },
  { id: 'wide_kraft_packing_tape', label: 'Lakban Cokelat Kraft Lebar', desc: 'Lakban packing tebal parcel paket pengiriman', category: 'tape', icon: '📦' },
  { id: 'scotch_transparent_tape', label: 'Selotip Kaca Bening', desc: 'Cellophane plastik bening glossy mengkilap', category: 'tape', icon: '✨' },
  { id: 'cross_tape_cluster', label: 'Lakban Silang X Minimalis', desc: 'Dua isolasi silang pengait foto & memo', category: 'tape', icon: '❌' },
  { id: 'perforated_stamp_tape', label: 'Lakban Tiket Perforasi', desc: 'Washi tiket bergerigi lubang perforasi', category: 'tape', icon: '🎟️' },

  // --- 6. TAG & AKSESORIS KRAFT (4 BENTUK) ---
  { id: 'blank_luggage_tag', label: 'Tag Koper Kraft Gantung', desc: 'Tag travel klasik lubang mata ayam kuningan', category: 'tag_bookmark', icon: '🏷️' },
  { id: 'archival_bookmark', label: 'Pembatas Buku Ramping', desc: 'Bookmark vertikal ramping takik pita V', category: 'tag_bookmark', icon: '🔖' },
  { id: 'hexagonal_price_tag', label: 'Tag Harga Butik Geometris', desc: 'Tag harga retail heksagonal berlubang tali', category: 'tag_bookmark', icon: '🏷️' },
  { id: 'ceramic_art_tile', label: 'Ubin Keramik Estetik', desc: 'Plat keramik berglazur halus sudut membulat', category: 'tag_bookmark', icon: '🏺' },
];

export const MOTION_PRESETS = [
  // =========================================================================
  // SERI 1: PAPER TITLES (WADAH JUDUL TEKS) ⭐⭐⭐⭐⭐
  // =========================================================================
  {
    id: 'paper_reveal',
    name: '1. Paper Reveal (Slide & Unfold)',
    desc: 'Kertas katun meluncur masuk dari samping -> sedikit membuka/terlipat -> teks judul muncul -> hold 4s -> meluncur keluar',
    icon: '📄',
    series: 'paper_titles',
    bestFor: 'Judul Video, Nama Produk, Editorial Quote, Social Media'
  },
  {
    id: 'torn_paper_text',
    name: '2. Torn Paper Text (Sobekan Kertas Editorial)',
    desc: 'Potongan kertas robek berserat deckle edge masuk membal -> wadah sobekan terbuka -> teks muncul -> settle halus',
    icon: '📜',
    series: 'paper_titles',
    bestFor: 'Vlog Lifestyle, Editorial Header, Fashion, YouTube Title'
  },
  {
    id: 'paper_stack_titles',
    name: '6. Paper Stack Titles (Tumpukan Lembar Kertas)',
    desc: '2-3 lembar kertas bertumpuk bergeser bergantian satu per satu menampilkan Title utama dan Subtitle kontras',
    icon: '📑',
    series: 'paper_titles',
    bestFor: 'Title & Subtitle, Lower Third Editorial, Chapter Heading'
  },
  {
    id: 'paper_window_mask',
    name: '8. Paper Window / Mask (Tirai Kertas Tengah)',
    desc: 'Dua lembar kertas membelah dari tengah seperti tirai jendela mask -> menampakkan teks judul -> menutup kembali',
    icon: '🪟',
    series: 'paper_titles',
    bestFor: 'Title Transition, Opening Scene, Product Reveal'
  },

  // =========================================================================
  // SERI 2: PAPER LABELS & ANNOTATIONS ⭐⭐⭐⭐⭐
  // =========================================================================
  {
    id: 'sticky_note_seq',
    name: '3. Sticky Note Collection (Catatan Tempel)',
    desc: 'Sticky note warna pastel jatuh miring alami dengan bayangan lentur -> badge NOTE 01 & baris teks tips muncul',
    icon: '📌',
    series: 'paper_labels',
    bestFor: 'Tips, Tutorial, Checklist, Ranking, Educational Content'
  },
  {
    id: 'floating_paper_labels',
    name: '9. Floating Paper Labels (Label Anotasi Minimalis)',
    desc: 'Label kertas kecil minimalis (NEW, TIP, 01, DETAIL, LOOK, NOTE) pop masuk melayang halus di samping objek video',
    icon: '🏷️',
    series: 'paper_labels',
    bestFor: 'Video Callout, Product Tag, Price Annotation, Feature Callout'
  },

  // =========================================================================
  // SERI 3: SCRAPBOOK ELEMENTS & COMPOSITIONS ⭐⭐⭐⭐
  // =========================================================================
  {
    id: 'tape_and_paper',
    name: '4. Tape + Paper (Kertas Lakban Washi)',
    desc: 'Kertas meluncur masuk -> ditempel 2 strip masking tape washi semi-transparan -> teks muncul -> tape terkelupas keluar',
    icon: '🩹',
    series: 'scrapbook_elements',
    bestFor: 'Overlay Footage, Travel Vlog, Memories, Scrapbook Digital'
  },
  {
    id: 'layered_scrapbook',
    name: '5. Layered Scrapbook (Komposisi Bertingkat)',
    desc: 'Komposisi digital scrapbook premium: Paper Base + Polaroid Photo Frame + Washi Tape + Pencil Mark + Teks',
    icon: '🖼️',
    series: 'scrapbook_elements',
    bestFor: 'Travel, Lifestyle, Fashion, Wedding, Memories, Documentary'
  },
  {
    id: 'handwritten_paper',
    name: '7. Handwritten + Paper (Kertas & Garis Pensil)',
    desc: 'Kertas masuk -> teks utama muncul dengan animasi garis aksen kuas/pensil underline editorial yang digambar nyata',
    icon: '✍️',
    series: 'scrapbook_elements',
    bestFor: 'Quote Editorial, Branding Minimalis, Studio Vlog'
  },
  {
    id: 'wedding_ribbon_floral_unfurl',
    name: 'Undangan Wedding Ribbon & Floral (Pita Sutra & Daun Emas)',
    desc: 'Amplop dengan simpul pita sutra 3D & segel lilin emas membuka mengeluarkan kartu undangan mewah berlis emas',
    icon: '💌',
    series: 'scrapbook_elements',
    bestFor: 'Undangan Pernikahan Digital, Gala, Luxury Event'
  },

  // =========================================================================
  // SERI 4: PHYSICAL TRANSITIONS & MOTION KITS ⭐⭐⭐⭐
  // =========================================================================
  {
    id: 'paper_crumple_unfold',
    name: '10. 3D Crumpled Paper Unfold (Bola Kertas Remuk)',
    desc: 'Bola kertas kusut 3D pejal berputar dan membuka lipatan mesh facet secara fisik merapikan diri jadi lembaran datar',
    icon: '📜',
    series: 'paper_transitions',
    bestFor: 'Editorial Reveal, Stop Motion Effect, Creative Transition'
  },
  {
    id: 'shatter_assemble',
    name: 'Voronoi Shatter Reassembly (Pecah Jadi Utuh)',
    desc: '18 kepingan poligon Voronoi berhamburan dari ruang 3D lalu menyatu magnetik dengan kilatan energi seam weld',
    icon: '🧩',
    series: 'paper_transitions',
    bestFor: 'Plakat, Plat Keramik, Kartu Minimalis, Badge Segel'
  },
  {
    id: 'speed_wind_comic_morph',
    name: 'Speed Wind Anime Overlay (Kibasan Angin Lari Cepat)',
    desc: 'Overlay kibasan angin lari cepat + anime speedlines radial memotong ruang lalu memadat menjadi kotak seruan aksi',
    icon: '💨',
    series: 'paper_transitions',
    bestFor: 'Action Callout, Dynamic Video Title, Comic Dialogue'
  },
  {
    id: 'smooth_slide',
    name: 'Smooth Editorial Slide (Lower Third)',
    desc: 'Geser horizontal broadcast mulus dari kiri/bawah -> hold 4s -> geser keluar',
    icon: '📺',
    series: 'paper_transitions',
    bestFor: 'Lower Third, News Tag, Clean Subtitle'
  }
];

export const PRESET_COLORS = [
  { name: 'Kuning Kunyit', value: '#fbbf24' },
  { name: 'Kuning Pastel', value: '#fef08a' },
  { name: 'Biru Cerah', value: '#38bdf8' },
  { name: 'Biru Pastel', value: '#e0f2fe' },
  { name: 'Pink Merona', value: '#f9a8d4' },
  { name: 'Pink Romantis', value: '#fce7f3' },
  { name: 'Mint Segar', value: '#86efac' },
  { name: 'Mint Pastel', value: '#dcfce7' },
  { name: 'Kraft Vintage', value: '#e7d8c9' },
  { name: 'Kertas Hangat', value: '#fafaf9' },
  { name: 'Ungu Lavender', value: '#d8b4fe' },
  { name: 'Slate Gelap', value: '#334155' },
];
