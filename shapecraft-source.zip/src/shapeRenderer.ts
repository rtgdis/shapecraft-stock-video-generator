import { ShapeState, ShapeType } from './types';
import {
  getCleanMinimalCardPath,
  getSmoothPillBadgePath,
  getArchMonolineFramePath,
  getChamferedHexLabelPath,
  getModernSquareMemoPath,
  getScallopBorderPlatePath,
  getCurvedCornerPlaquePath,
  getSoftCircleBadgePath,
  getFoldedCornerSheetPath,
  getMinimalQuoteBoxPath,
  getCleanSpeechBubblePath,
  getMinimalChatPillPath,
  getThoughtDialogCloudPath,
  getQuoteDialogCardPath,
  getCurvedDialogBoxPath,
  getActionCalloutBadgePath,
  getBlankClassicPostcardPath,
  getVerticalArtPostcardPath,
  getAirmailCleanPostcardPath,
  getVintageGridPostcardPath,
  getSquareMiniPostcardPath,
  getFoldedGreetingCardPath,
  getVerticalArchGreetingPath,
  getPocketGiftCardPath,
  getDeckleEdgeGreetingPath,
  getRibbonTiedCardPath,
  getDoubleBorderInvitationPath,
  getStraightWashiTapePath,
  getTornMaskingTapePath,
  getDiagonalTapeStripPath,
  getWideKraftPackingTapePath,
  getScotchTransparentTapePath,
  getCrossTapeClusterPath,
  getPerforatedStampTapePath,
  getBlankLuggageTagPath,
  getArchivalBookmarkPath,
  getHexagonalPriceTagPath,
  getCeramicArtTilePath,
  getInnerDetailsSVG,
  getCreaseLines,
} from './shapeUtils';
import { getGeneratedShapePath, getGeneratedInnerDetailsSVG, loadStoredGeneratedItems } from './shapeGenerator';

export function getShapePathString(shapeType: ShapeType | string, w: number, h: number, creaseSeed: number = 1): string {
  if (shapeType.startsWith('gen_shape_')) {
    const items = loadStoredGeneratedItems();
    const item = items.find((it) => it.definition.id === shapeType);
    return getGeneratedShapePath(shapeType, w, h, item?.meta);
  }

  switch (shapeType) {
    case 'clean_minimal_card':
      return getCleanMinimalCardPath(w, h);
    case 'smooth_pill_badge':
      return getSmoothPillBadgePath(w, h);
    case 'arch_monoline_frame':
      return getArchMonolineFramePath(w, h);
    case 'chamfered_hex_label':
      return getChamferedHexLabelPath(w, h);
    case 'modern_square_memo':
      return getModernSquareMemoPath(w, h);
    case 'scallop_border_plate':
      return getScallopBorderPlatePath(w, h);
    case 'curved_corner_plaque':
      return getCurvedCornerPlaquePath(w, h);
    case 'soft_circle_badge':
      return getSoftCircleBadgePath(w, h);
    case 'folded_corner_sheet':
      return getFoldedCornerSheetPath(w, h);
    case 'minimal_quote_box':
      return getMinimalQuoteBoxPath(w, h);
    case 'clean_speech_bubble':
      return getCleanSpeechBubblePath(w, h);
    case 'minimal_chat_pill':
      return getMinimalChatPillPath(w, h);
    case 'thought_dialog_cloud':
      return getThoughtDialogCloudPath(w, h);
    case 'quote_dialog_card':
      return getQuoteDialogCardPath(w, h);
    case 'curved_dialog_box':
      return getCurvedDialogBoxPath(w, h);
    case 'action_callout_badge':
      return getActionCalloutBadgePath(w, h);
    case 'blank_classic_postcard':
      return getBlankClassicPostcardPath(w, h);
    case 'vertical_art_postcard':
      return getVerticalArtPostcardPath(w, h);
    case 'airmail_clean_postcard':
      return getAirmailCleanPostcardPath(w, h);
    case 'vintage_grid_postcard':
      return getVintageGridPostcardPath(w, h);
    case 'square_mini_postcard':
      return getSquareMiniPostcardPath(w, h);
    case 'folded_greeting_card':
      return getFoldedGreetingCardPath(w, h);
    case 'vertical_arch_greeting':
      return getVerticalArchGreetingPath(w, h);
    case 'pocket_gift_card':
      return getPocketGiftCardPath(w, h);
    case 'deckle_edge_greeting':
      return getDeckleEdgeGreetingPath(w, h, creaseSeed);
    case 'ribbon_tied_card':
      return getRibbonTiedCardPath(w, h);
    case 'double_border_invitation':
      return getDoubleBorderInvitationPath(w, h);
    case 'straight_washi_tape':
      return getStraightWashiTapePath(w, h);
    case 'torn_masking_tape':
      return getTornMaskingTapePath(w, h, creaseSeed);
    case 'diagonal_tape_strip':
      return getDiagonalTapeStripPath(w, h);
    case 'wide_kraft_packing_tape':
      return getWideKraftPackingTapePath(w, h);
    case 'scotch_transparent_tape':
      return getScotchTransparentTapePath(w, h);
    case 'cross_tape_cluster':
      return getCrossTapeClusterPath(w, h);
    case 'perforated_stamp_tape':
      return getPerforatedStampTapePath(w, h);
    case 'blank_luggage_tag':
      return getBlankLuggageTagPath(w, h);
    case 'archival_bookmark':
      return getArchivalBookmarkPath(w, h);
    case 'hexagonal_price_tag':
      return getHexagonalPriceTagPath(w, h);
    case 'ceramic_art_tile':
      return getCeramicArtTilePath(w, h);
    default:
      return getCleanMinimalCardPath(w, h);
  }
}

/**
 * Generates an SVG string representation of the shape
 * Options:
 * - showCopySpaceGuide: adds dotted safe guide box for preview (omitted during stock export)
 */
export function generateShapeSvg(
  state: ShapeState,
  options: { showCopySpaceGuide?: boolean } = {}
): string {
  const w = state.width;
  const h = state.height;
  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);

  // Gradient calculation
  const angleRad = ((state.gradientAngle || 135) * Math.PI) / 180;
  const r = 0.5;
  const gx1 = Math.round((0.5 - r * Math.cos(angleRad)) * 100);
  const gy1 = Math.round((0.5 - r * Math.sin(angleRad)) * 100);
  const gx2 = Math.round((0.5 + r * Math.cos(angleRad)) * 100);
  const gy2 = Math.round((0.5 + r * Math.sin(angleRad)) * 100);

  // Padding to allow shadow and decoration without clipping
  const pad = 40;
  const totalW = w + pad * 2;
  const totalH = h + pad * 2;

  const clipId = `clip_${Math.random().toString(36).substring(2, 9)}`;
  const gradId = `grad_${Math.random().toString(36).substring(2, 9)}`;
  const shadowId = `shad_${Math.random().toString(36).substring(2, 9)}`;

  // Shadow calculation (clean solid black with opacity for safe chroma keying)
  const shadowBlur = Math.round((state.shadowBlur || 20) * 0.7);
  const shadowDist = Math.round((state.shadowDistance || 10) * 0.7);
  const shadowOp = (state.shadowOpacity || 15) / 100;

  // Inner details
  let innerDetails = '';
  if (state.shapeType.startsWith('gen_shape_')) {
    const items = loadStoredGeneratedItems();
    const item = items.find((it) => it.definition.id === state.shapeType);
    if (item && item.meta) {
      innerDetails = getGeneratedInnerDetailsSVG(item.meta, w, h);
    }
  } else {
    innerDetails = getInnerDetailsSVG(state.shapeType as ShapeType, w, h);
  }

  // Crease lines
  const creaseSvg = state.paperCrease
    ? getCreaseLines(w, h, state.creaseSeed || 1)
        .map(
          (c) =>
            `<line x1="${c.x1}" y1="${c.y1}" x2="${c.x2}" y2="${c.y2}" stroke="rgba(0,0,0,${c.opacity})" stroke-width="${c.width}" />`
        )
        .join('')
    : '';

  // Copy space guide (cyan dashed box)
  let copySpaceGuideSvg = '';
  if (options.showCopySpaceGuide) {
    const marginX = Math.round(w * 0.16);
    const marginY = Math.round(h * 0.18);
    const guideW = w - marginX * 2;
    const guideH = h - marginY * 2;
    copySpaceGuideSvg = `
      <g opacity="0.75">
        <rect x="${marginX}" y="${marginY}" width="${guideW}" height="${guideH}" 
          fill="none" stroke="#06b6d4" stroke-width="2" stroke-dasharray="6,4" rx="8" />
        <rect x="${marginX}" y="${marginY}" width="${guideW}" height="${guideH}" 
          fill="rgba(6, 182, 212, 0.05)" rx="8" />
        <text x="${w / 2}" y="${h / 2 - 8}" font-family="sans-serif" font-size="13" font-weight="700" 
          fill="#0891b2" text-anchor="middle" letter-spacing="1.5">SAFE COPY SPACE</text>
        <text x="${w / 2}" y="${h / 2 + 12}" font-family="sans-serif" font-size="10" 
          fill="#0e7490" text-anchor="middle">HOLD FOR BUYER'S TEXT</text>
      </g>
    `;
  }

  // Border string
  const hasBorder = state.borderStyle !== 'none' && (state.borderWidth || 0) > 0;
  const strokeAttr = hasBorder
    ? `stroke="${state.borderColor}" stroke-width="${state.borderWidth}" ${
        state.borderStyle === 'dashed' ? 'stroke-dasharray="8,6"' : state.borderStyle === 'dotted' ? 'stroke-dasharray="3,4"' : ''
      }`
    : '';

  // Fill string
  const fillAttr = state.fillType === 'linear'
    ? `fill="url(#${gradId})"`
    : `fill="${state.bgColor}"`;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalW} ${totalH}" width="${totalW}" height="${totalH}">
    <defs>
      <linearGradient id="${gradId}" x1="${gx1}%" y1="${gy1}%" x2="${gx2}%" y2="${gy2}%">
        <stop offset="0%" stop-color="${state.bgColor}" />
        <stop offset="100%" stop-color="${state.bgColorSecondary || state.bgColor}" />
      </linearGradient>

      <filter id="${shadowId}" x="-30%" y="-30%" width="160%" height="160%">
        <feDropShadow dx="0" dy="${shadowDist}" stdDeviation="${shadowBlur}" flood-color="#000000" flood-opacity="${shadowOp}" />
      </filter>

      <clipPath id="${clipId}">
        <path d="${pathD}" />
      </clipPath>
    </defs>

    <g transform="translate(${pad}, ${pad})">
      <!-- Base Shape with Shadow & Fill -->
      <path d="${pathD}" ${fillAttr} ${strokeAttr} filter="url(#${shadowId})" opacity="${state.opacity / 100}" />

      <!-- Clipped Inner Details, Creases, and Texture -->
      <g clip-path="url(#${clipId})">
        ${creaseSvg}
        ${innerDetails}
      </g>

      <!-- Optional Specular Shine -->
      ${state.specularShine ? `
        <path d="${pathD}" fill="url(#spec_shine)" opacity="0.3" pointer-events="none" />
      ` : ''}

      <!-- Interactive Copy Space Visual Guide (if active) -->
      ${copySpaceGuideSvg}
    </g>
  </svg>`;
}
