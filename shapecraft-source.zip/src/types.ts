export type ShapeType = 
  // --- 1. WADAH TEKS & LABEL MINIMALIS (10 BENTUK) ---
  | 'clean_minimal_card'
  | 'smooth_pill_badge'
  | 'arch_monoline_frame'
  | 'chamfered_hex_label'
  | 'modern_square_memo'
  | 'scallop_border_plate'
  | 'curved_corner_plaque'
  | 'soft_circle_badge'
  | 'folded_corner_sheet'
  | 'minimal_quote_box'

  // --- 2. KOMENTAR & BALON DIALOG (6 BENTUK) ---
  | 'clean_speech_bubble'
  | 'minimal_chat_pill'
  | 'thought_dialog_cloud'
  | 'quote_dialog_card'
  | 'curved_dialog_box'
  | 'action_callout_badge'

  // --- 3. POSTCARD & KARTU FOTO (5 BENTUK) ---
  | 'blank_classic_postcard'
  | 'vertical_art_postcard'
  | 'airmail_clean_postcard'
  | 'vintage_grid_postcard'
  | 'square_mini_postcard'

  // --- 4. KARTU UCAPAN & UNDANGAN (6 BENTUK) ---
  | 'folded_greeting_card'
  | 'vertical_arch_greeting'
  | 'pocket_gift_card'
  | 'deckle_edge_greeting'
  | 'ribbon_tied_card'
  | 'double_border_invitation'

  // --- 5. TAPE LAKBAN & WASHI (7 BENTUK) ---
  | 'straight_washi_tape'
  | 'torn_masking_tape'
  | 'diagonal_tape_strip'
  | 'wide_kraft_packing_tape'
  | 'scotch_transparent_tape'
  | 'cross_tape_cluster'
  | 'perforated_stamp_tape'

  // --- 6. TAG & AKSESORIS KRAFT (4 BENTUK) ---
  | 'blank_luggage_tag'
  | 'archival_bookmark'
  | 'hexagonal_price_tag'
  | 'ceramic_art_tile';

export type FillType = 'solid' | 'linear' | 'radial' | 'glass' | 'holographic' | 'metallic' | 'claymorphism';

export type TextureType = 
  | 'none'
  | 'grain'
  | 'parchment'
  | 'recycled'
  | 'cardboard'
  | 'cotton_rag'
  | 'cotton_paper'
  | 'watercolor_coldpress'
  | 'washi_kozo'
  | 'washi_fibers'
  | 'linen_blend'
  | 'canvas_fabric'
  | 'watercolor_paper'
  | 'gilded_gold_leaf'
  | 'gold_dust'
  | 'terrazzo_stone'
  | 'marble_vein'
  | 'frosted_vellum'
  | 'holographic_foil'
  | 'leatherette'
  | 'wood_veneer'
  | 'rough_slate'
  | 'halftone'
  | 'grid'
  | 'ruled'
  | 'dotted'
  | 'creased_lines';

export type BorderStyle = 'solid' | 'dashed' | 'dotted' | 'double' | 'none';

export type DecorationType = 'none' | 'tape' | 'pin' | 'clip' | 'staple';
export type TapeStyle = 'classic' | 'washi' | 'duct' | 'scotch';

export type AssetSeries = 
  | 'paper_titles'       // Seri 1: Paper Titles (Judul Teks) ⭐⭐⭐⭐⭐
  | 'paper_labels'       // Seri 2: Paper Labels & Annotations ⭐⭐⭐⭐⭐
  | 'scrapbook_elements' // Seri 3: Tape, Notes, Photo Frames, Layers ⭐⭐⭐⭐
  | 'paper_transitions'; // Seri 4: Paper Transitions & Masks ⭐⭐⭐⭐

export type MotionPreset = 
  // --- 10 CORE MODULAR PAPER TEXT MOTION ARCHETYPES (ADOBE STOCK ASSETS) ---
  | 'paper_reveal'              // 1. Paper Reveal (Slide -> Slight Fold Open -> Text -> Hold 4s -> Exit)
  | 'torn_paper_text'           // 2. Torn Paper Text (Sobekan Kertas Deckle Edge Membuka -> Text Reveal)
  | 'sticky_note_seq'           // 3. Sticky Note Collection (Sticky Note Tilt Drop -> Number & Body Text)
  | 'tape_and_paper'            // 4. Tape + Paper (Kertas Muncul -> Ditempel Washi/Masking Tape -> Text)
  | 'layered_scrapbook'         // 5. Layered Scrapbook (Paper Layer + Polaroid Frame + Tape + Mark + Text)
  | 'paper_stack_titles'        // 6. Paper Stack Titles (Tumpukan 2-3 Kertas Bergeser: Title + Subtitle)
  | 'handwritten_paper'         // 7. Handwritten + Paper (Kertas Masuk -> Teks Editorial + Underline Aksen)
  | 'paper_window_mask'         // 8. Paper Window / Mask (Kertas Membuka dari Tengah -> Text -> Menutup)
  | 'floating_paper_labels'     // 9. Floating Paper Labels (Label Kecil Minimalis: NEW, TIP, 01, NOTE, LOOK)
  | 'paper_crumple_unfold'      // 10. 3D Crumpled Paper Unfold (Bola Kertas Kusut 3D -> Lembaran Datar)
  
  // --- ADDITIONAL COMMERCIAL GREEN SCREEN OVERLAYS ---
  | 'shatter_assemble'          // Voronoi Shatter Reassembly
  | 'speed_wind_comic_morph'    // Comic Speedlines & Wind Slash
  | 'wedding_ribbon_floral_unfurl' // Wedding Digital Invitation Ribbon & Floral
  | 'smooth_slide'              // Clean Lower Third Slide
  | 'elastic_pop'               // Elastic Spring Pop
  | 'subtle_float';             // Ambient Breathing Float

export type BounceIntensity = 'soft' | 'snappy' | 'ultra_bouncy';
export type IdleMotionStyle = 'breathing' | 'float' | 'sway' | 'still';

export type ChromaBg = 
  | 'green_screen'  // #00FF00 (Pure Chroma Key Green)
  | 'blue_screen'   // #0000FF (Pure Chroma Key Blue)
  | 'pure_black'    // #000000 (Pure Luma Key Black)
  | 'pure_white'    // #FFFFFF (Clean Pure White)
  | 'checkerboard'  // Alpha Transparency Preview
  | 'transparent';  // Pure Transparent Alpha

export type VideoDuration = 5 | 6 | 7 | 10;
export type VideoFps = 30 | 60;
export type VideoResolution = '1080p' | '4k' | 'reels_9_16' | 'square_1_1';

export interface MotionTransform {
  scale: number;
  scaleX: number;
  scaleY: number;
  translateX: number;
  translateY: number;
  rotate: number;
  rotateX: number;
  rotateY: number;
  opacity: number;
  originX: string;
  originY: string;
}

export interface StockMetadata {
  title: string;
  category: string;
  keywords: string[];
  description: string;
}

export interface ShapeState {
  shapeType: ShapeType | string;
  fillType: FillType;
  width: number;
  height: number;
  
  // Color configuration
  bgColor: string;          // Solid, or primary gradient color
  bgColorSecondary: string; // Secondary gradient color
  gradientAngle: number;
  opacity: number;          // Container fill opacity (0-100)
  
  // Glassmorphism controls
  glassBlur: number;
  glassSaturate: number;
  
  // Texture layer
  textureType: TextureType;
  textureOpacity: number; // 0-100
  
  // Border style
  borderStyle: BorderStyle;
  borderWidth: number;
  borderColor: string;
  
  // Decoration
  decorationType: DecorationType;
  tapeStyle: TapeStyle;
  tapeColor: string;
  tapeWidth: number;
  tapeAngle: number;
  tapeOpacity: number;
  decorationX: number;
  decorationY: number;
  
  // Drop Shadow
  shadowColor: string;
  shadowBlur: number;
  shadowDistance: number;
  shadowOpacity: number;
  
  // Realism premium effects
  specularShine?: boolean;      // Pantulan mengkilap specular
  paperCrease?: boolean;        // Efek serat kusut/kerut kertas
  creaseSeed?: number;          // Benih acak efek kusut
  tiltX?: number;               // 3D kemiringan sumbu X (tilt)
  tiltY?: number;               // 3D kemiringan sumbu Y (tilt)
  glowIntensity?: number;       // Pendaran neon backlight (0-100)
  lightX?: number;              // Kedalaman cahaya 3D arah X (-100 ke 100)
  lightY?: number;              // Kedalaman cahaya 3D arah Y (-100 ke 100)
  hideText?: boolean;           // Sembunyikan semua teks dekoratif
  objectRotation?: number;      // Rotasi objek 2D (-180 sampai 180 derajat)
  
  // Typographies
  textContent: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: string;
  isItalic: boolean;
  fontColor: string;
  letterSpacing: number; // -2 to 10
  textAlign: 'left' | 'center' | 'right';
  textShadowColor: string;
  textShadowBlur: number;
  lineHeight: number;
}

export interface PresetTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'text_container' | 'comment' | 'postcard' | 'greeting_card' | 'tape' | 'tag_bookmark';
  state: Partial<ShapeState>;
}
