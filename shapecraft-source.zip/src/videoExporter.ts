import { ShapeState, VideoResolution, VideoFps, VideoDuration, ChromaBg, MotionPreset, BounceIntensity, IdleMotionStyle } from './types';
import { computeMotionTransform, getChromaBackgroundColor } from './motionEngine';
import { getShapePathString } from './shapeRenderer';
import { getCreaseLines } from './shapeUtils';
import {
  drawPaperReveal,
  drawTornPaperText,
  drawStickyNoteSequence,
  drawTapeAndPaper,
  drawLayeredScrapbook,
  drawPaperStackTitles,
  drawHandwrittenPaper,
  drawPaperWindowMask,
  drawFloatingPaperLabels,
  drawCrumpledPaperUnfold,
  drawShatterAssemble,
  drawSpeedWindComicMorph,
  drawWeddingRibbonFloralUnfurl
} from './morphAnimator';
import { drawMaterialTextureToCanvas } from './materialTextures';
import { saveAs } from 'file-saver';
import JSZip from 'jszip';
import { Muxer, ArrayBufferTarget } from 'mp4-muxer';
// @ts-ignore
import { createH264MP4Encoder } from 'h264-mp4-encoder';

export interface VideoExportOptions {
  shapeState: ShapeState;
  shapeSvgString?: string;
  shapeWidth: number;
  shapeHeight: number;
  shapeType: string;
  shapeLabel: string;
  duration: VideoDuration;
  fps: VideoFps;
  resolution: VideoResolution;
  chromaBg: ChromaBg;
  motionPreset: MotionPreset;
  bounceIntensity?: BounceIntensity;
  idleStyle?: IdleMotionStyle;
  qualityProfile?: 'ultra' | 'high';
  preferredEngine?: 'auto' | 'webcodecs' | 'wasm_h264';
  onProgress?: (frame: number, totalFrames: number, percent: number, stage: string) => void;
}

export function getResolutionDimensions(res: VideoResolution): { width: number; height: number } {
  switch (res) {
    case '4k':
      return { width: 3840, height: 2160 }; // 16:9 4K UHD
    case '1080p':
      return { width: 1920, height: 1080 }; // 16:9 Full HD
    case 'reels_9_16':
      return { width: 1080, height: 1920 }; // 9:16 Vertical
    case 'square_1_1':
      return { width: 1080, height: 1080 }; // 1:1 Square
  }
}

/**
 * Native Canvas 2D Vector Renderer
 * Guaranteed to NEVER fail, NEVER be blank, and NEVER taint the canvas!
 * Directly draws mathematical paths, fills, shadows, borders, creases, and decorative inner details.
 * Also delegates to specialized physical transformation / morph animators when selected.
 */
export function drawShapeToCanvas(
  ctx: CanvasRenderingContext2D,
  state: ShapeState,
  w: number,
  h: number,
  time: number = 2.5,
  duration: number = 7,
  preset: MotionPreset = 'elastic_pop'
) {
  // --- 10 CORE MODULAR PAPER TEXT MOTION ARCHETYPES ---
  if (preset === 'paper_reveal') {
    drawPaperReveal(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'torn_paper_text') {
    drawTornPaperText(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'sticky_note_seq') {
    drawStickyNoteSequence(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'tape_and_paper') {
    drawTapeAndPaper(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'layered_scrapbook') {
    drawLayeredScrapbook(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'paper_stack_titles') {
    drawPaperStackTitles(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'handwritten_paper') {
    drawHandwrittenPaper(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'paper_window_mask') {
    drawPaperWindowMask(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'floating_paper_labels') {
    drawFloatingPaperLabels(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'paper_crumple_unfold') {
    drawCrumpledPaperUnfold(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'shatter_assemble') {
    drawShatterAssemble(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'speed_wind_comic_morph') {
    drawSpeedWindComicMorph(ctx, state, w, h, time, duration);
    return;
  }
  if (preset === 'wedding_ribbon_floral_unfurl') {
    drawWeddingRibbonFloralUnfurl(ctx, state, w, h, time, duration);
    return;
  }

  const pathD = getShapePathString(state.shapeType, w, h, state.creaseSeed || 1);
  const path2d = new Path2D(pathD);

  ctx.save();
  ctx.translate(-w / 2, -h / 2);

  // 1. Drop shadow. Use the editor-selected color so the exported frame
  // matches the creative control instead of always using black.
  if ((state.shadowOpacity || 0) > 0) {
    ctx.shadowColor = withAlpha(state.shadowColor || '#000000', (state.shadowOpacity || 15) / 100);
    ctx.shadowBlur = state.shadowBlur || 20;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = state.shadowDistance || 10;
  }

  // 2. Fill. Keep every advertised material style available in the video
  // renderer; the old implementation silently reduced most styles to solid.
  if (state.fillType === 'linear') {
    const angleRad = ((state.gradientAngle || 135) * Math.PI) / 180;
    const r = Math.max(w, h) * 0.5;
    const cx = w / 2;
    const cy = h / 2;
    const gx1 = cx - r * Math.cos(angleRad);
    const gy1 = cy - r * Math.sin(angleRad);
    const gx2 = cx + r * Math.cos(angleRad);
    const gy2 = cy + r * Math.sin(angleRad);
    const grad = ctx.createLinearGradient(gx1, gy1, gx2, gy2);
    grad.addColorStop(0, state.bgColor);
    grad.addColorStop(1, state.bgColorSecondary || state.bgColor);
    ctx.fillStyle = grad;
  } else if (state.fillType === 'radial' || state.fillType === 'glass' || state.fillType === 'claymorphism') {
    const grad = ctx.createRadialGradient(w * 0.36, h * 0.28, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.7);
    const highlight = state.fillType === 'glass' ? '#ffffff' : lightenColor(state.bgColor, state.fillType === 'claymorphism' ? 0.28 : 0.16);
    grad.addColorStop(0, state.fillType === 'glass' ? withAlpha(highlight, 0.8) : highlight);
    grad.addColorStop(0.45, state.bgColor);
    grad.addColorStop(1, state.bgColorSecondary || darkenColor(state.bgColor, 0.18));
    ctx.fillStyle = grad;
  } else if (state.fillType === 'metallic' || state.fillType === 'holographic') {
    const grad = ctx.createLinearGradient(0, 0, w, h);
    if (state.fillType === 'metallic') {
      grad.addColorStop(0, darkenColor(state.bgColor, 0.32));
      grad.addColorStop(0.22, lightenColor(state.bgColor, 0.35));
      grad.addColorStop(0.48, state.bgColorSecondary || state.bgColor);
      grad.addColorStop(0.72, '#ffffff');
      grad.addColorStop(1, darkenColor(state.bgColor, 0.25));
    } else {
      grad.addColorStop(0, '#67e8f9');
      grad.addColorStop(0.25, '#c084fc');
      grad.addColorStop(0.5, '#f9a8d4');
      grad.addColorStop(0.75, '#fde68a');
      grad.addColorStop(1, '#5eead4');
    }
    ctx.fillStyle = grad;
  } else {
    ctx.fillStyle = state.bgColor;
  }

  ctx.globalAlpha = (state.opacity || 100) / 100;
  ctx.fill(path2d);

  // Clear shadow before border, texture, and inner details
  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  // 2.5 Physical Material & Paper Texture (Washi, Recycled, Watercolor, Gold Leaf, Linen, etc.)
  if (state.textureType && state.textureType !== 'none' && (state.textureOpacity || 0) > 0) {
    drawMaterialTextureToCanvas(ctx, state.textureType, state.textureOpacity || 50, w, h, path2d, state.creaseSeed || 1);
  }

  // 3. Border
  if (state.borderStyle !== 'none' && (state.borderWidth || 0) > 0) {
    ctx.strokeStyle = state.borderColor;
    ctx.lineWidth = state.borderWidth;
    if (state.borderStyle === 'dashed') ctx.setLineDash([8, 6]);
    else if (state.borderStyle === 'dotted') ctx.setLineDash([3, 4]);
    else ctx.setLineDash([]);
    ctx.stroke(path2d);
    ctx.setLineDash([]);
  }

  // 4. Crease lines (Paper Crease)
  if (state.paperCrease) {
    const creases = getCreaseLines(w, h, state.creaseSeed || 1);
    ctx.save();
    ctx.clip(path2d);
    for (const c of creases) {
      ctx.beginPath();
      ctx.moveTo(c.x1, c.y1);
      ctx.lineTo(c.x2, c.y2);
      ctx.strokeStyle = `rgba(0, 0, 0, ${c.opacity})`;
      ctx.lineWidth = c.width;
      ctx.stroke();
    }
    ctx.restore();
  }

  // 5. Specular Shine Accent
  if (state.specularShine) {
    ctx.save();
    ctx.clip(path2d);
    const shineGrad = ctx.createLinearGradient(0, 0, w, h);
    shineGrad.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
    shineGrad.addColorStop(0.3, 'rgba(255, 255, 255, 0.1)');
    shineGrad.addColorStop(0.35, 'rgba(255, 255, 255, 0)');
    shineGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = shineGrad;
    ctx.fill(path2d);
    ctx.restore();
  }

  // 6. Inner decorative details (Postcards, Greeting Cards, Badges, Tags)
  ctx.save();
  ctx.clip(path2d);
  drawInnerDetails(ctx, state.shapeType, w, h);
  drawEditableText(ctx, state, w, h);
  ctx.restore();

  drawDecoration(ctx, state, w, h);

  ctx.restore();
}

function withAlpha(hex: string, alpha: number): string {
  const normalized = hex.replace('#', '');
  if (/^[0-9a-fA-F]{6}$/.test(normalized)) {
    const r = parseInt(normalized.slice(0, 2), 16);
    const g = parseInt(normalized.slice(2, 4), 16);
    const b = parseInt(normalized.slice(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${Math.max(0, Math.min(1, alpha))})`;
  }
  return hex;
}

function adjustColor(hex: string, amount: number): string {
  const normalized = hex.replace('#', '');
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) return hex;
  const channel = (offset: number) => Math.max(0, Math.min(255, Math.round(parseInt(normalized.slice(offset, offset + 2), 16) + 255 * amount)));
  return `rgb(${channel(0)}, ${channel(2)}, ${channel(4)})`;
}

function lightenColor(hex: string, amount: number): string { return adjustColor(hex, Math.abs(amount)); }
function darkenColor(hex: string, amount: number): string { return adjustColor(hex, -Math.abs(amount)); }

function drawEditableText(ctx: CanvasRenderingContext2D, state: ShapeState, w: number, h: number) {
  if (state.hideText || !state.textContent.trim()) return;

  const fontSize = Math.max(12, Math.min(state.fontSize || 28, h * 0.24));
  ctx.save();
  ctx.fillStyle = state.fontColor || '#111827';
  ctx.font = `${state.isItalic ? 'italic ' : ''}${state.fontWeight || '600'} ${fontSize}px ${state.fontFamily || 'sans-serif'}`;
  ctx.textAlign = state.textAlign || 'center';
  ctx.textBaseline = 'middle';
  ctx.letterSpacing = `${state.letterSpacing || 0}px`;
  ctx.shadowColor = state.textShadowColor || 'transparent';
  ctx.shadowBlur = state.textShadowBlur || 0;

  const maxWidth = w * 0.72;
  const words = state.textContent.trim().split(/\s+/);
  const lines: string[] = [];
  let line = '';
  for (const word of words) {
    const candidate = line ? `${line} ${word}` : word;
    if (line && ctx.measureText(candidate).width > maxWidth) {
      lines.push(line);
      line = word;
    } else {
      line = candidate;
    }
  }
  if (line) lines.push(line);

  const lineHeight = fontSize * (state.lineHeight || 1.2);
  const startY = h / 2 - ((lines.length - 1) * lineHeight) / 2;
  const x = state.textAlign === 'left' ? w * 0.16 : state.textAlign === 'right' ? w * 0.84 : w / 2;
  lines.slice(0, 4).forEach((text, index) => ctx.fillText(text, x, startY + index * lineHeight, maxWidth));
  ctx.restore();
}

function drawDecoration(ctx: CanvasRenderingContext2D, state: ShapeState, w: number, h: number) {
  if (state.decorationType === 'none') return;
  const x = w / 2 + (state.decorationX || 0);
  const y = h * 0.08 + (state.decorationY || 0);
  ctx.save();
  if (state.decorationType === 'tape') {
    const tapeW = Math.max(36, Math.min(w * 0.55, state.tapeWidth || w * 0.3));
    ctx.translate(x, y);
    ctx.rotate(((state.tapeAngle || 0) * Math.PI) / 180);
    ctx.globalAlpha = (state.tapeOpacity || 70) / 100;
    ctx.fillStyle = state.tapeColor || '#fef3c7';
    ctx.fillRect(-tapeW / 2, -12, tapeW, 24);
  } else if (state.decorationType === 'pin') {
    ctx.fillStyle = '#dc2626';
    ctx.beginPath(); ctx.arc(x, y, 11, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#7f1d1d'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y + 8); ctx.lineTo(x + 10, y + 28); ctx.stroke();
  } else if (state.decorationType === 'clip' || state.decorationType === 'staple') {
    ctx.strokeStyle = '#94a3b8'; ctx.lineWidth = state.decorationType === 'clip' ? 5 : 3;
    ctx.beginPath(); ctx.roundRect(x - 18, y - 8, 36, 18, 5); ctx.stroke();
  }
  ctx.restore();
}

/**
 * Draws inner vector details directly with Canvas 2D
 */
function drawInnerDetails(ctx: CanvasRenderingContext2D, shapeType: string, w: number, h: number) {
  const p = 18;
  const aw = w - 2 * p;
  const ah = h - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const cx = w / 2;
  const cy = h / 2;

  if (shapeType === 'clean_minimal_card') {
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.08)';
    ctx.lineWidth = 1;
    ctx.strokeRect(p + 10, p + 10, aw - 20, ah - 20);
  } else if (shapeType === 'smooth_pill_badge') {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 1.2;
    const r = (ah - 16) / 2;
    ctx.beginPath();
    ctx.roundRect(p + 8, p + 8, aw - 16, ah - 16, r);
    ctx.stroke();
  } else if (shapeType === 'blank_classic_postcard') {
    // Divider line & stamp area
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.12)';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(cx, p + 20);
    ctx.lineTo(cx, h - p - 20);
    ctx.stroke();
    ctx.setLineDash([]);
    // Stamp box on top right
    ctx.strokeRect(xr - 50, yt + 16, 36, 44);
  } else if (shapeType === 'folded_greeting_card') {
    // 3D center fold spine
    ctx.fillStyle = 'rgba(0, 0, 0, 0.12)';
    ctx.fillRect(cx - 1.5, yt, 1.5, ah);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.fillRect(cx, yt, 1.5, ah);
  } else if (shapeType === 'modern_square_memo') {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(xl, yt, aw, 16);
  } else if (shapeType === 'vintage_grid_postcard') {
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.12)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx, p + 20);
    ctx.lineTo(cx, h - p - 20);
    for (let y = p + 60; y <= p + 165; y += 35) {
      ctx.moveTo(cx + 20, y);
      ctx.lineTo(xr - 16, y);
    }
    ctx.stroke();
  } else if (shapeType.includes('tag') || shapeType.includes('bookmark')) {
    // Eyelet hole
    ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    ctx.beginPath();
    ctx.arc(cx, p + 24, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 2;
    ctx.stroke();
  }
}

/**
 * Probes browser hardware capabilities to find best supported AVC/H.264 profile
 */
async function getSupportedAvcConfig(
  desiredW: number,
  desiredH: number,
  fps: number,
  bitrate: number
): Promise<{ width: number; height: number; codec: string; bitrate: number } | null> {
  if (typeof VideoEncoder === 'undefined' || !VideoEncoder.isConfigSupported) {
    return null;
  }

  // Ensure width & height are strictly even numbers
  const w = desiredW % 2 === 0 ? desiredW : desiredW - 1;
  const h = desiredH % 2 === 0 ? desiredH : desiredH - 1;

  const codecsToTest = [
    'avc1.4d002a', // Main Profile Level 4.2 (Highly compatible across all modern OS & GPUs)
    'avc1.42001f', // Baseline Profile Level 3.1
    'avc1.640028', // High Profile Level 4.0
    'avc1.640033', // High Profile Level 5.1
    'avc1.42e01e', // Baseline Level 3.0
  ];

  for (const c of codecsToTest) {
    try {
      const support = await VideoEncoder.isConfigSupported({
        codec: c,
        width: w,
        height: h,
        bitrate,
        framerate: fps,
        avc: { format: 'avc' }
      });
      if (support && support.supported) {
        return { width: w, height: h, codec: c, bitrate };
      }
    } catch {
      // test next
    }
  }

  return null;
}

/**
 * Renders a single frame to Data URL for instant visual inspection / poster export
 */
export function renderSingleFrameToDataUrl(options: {
  shapeState: ShapeState;
  shapeWidth: number;
  shapeHeight: number;
  chromaBg: ChromaBg;
  motionPreset: MotionPreset;
  bounceIntensity?: BounceIntensity;
  idleStyle?: IdleMotionStyle;
  resolution: VideoResolution;
  duration: VideoDuration;
  time: number;
}): string {
  const { shapeState, shapeWidth, shapeHeight, chromaBg, motionPreset, bounceIntensity, idleStyle, resolution, duration, time } = options;
  const { width: canvasW, height: canvasH } = getResolutionDimensions(resolution);

  const canvas = document.createElement('canvas');
  canvas.width = canvasW;
  canvas.height = canvasH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const scaleFit = Math.min((canvasW * 0.72) / shapeWidth, (canvasH * 0.72) / shapeHeight, 2.4);
  const targetW = shapeWidth * scaleFit;
  const targetH = shapeHeight * scaleFit;

  if (chromaBg === 'transparent') {
    ctx.clearRect(0, 0, canvasW, canvasH);
  } else {
    const bgColor = getChromaBackgroundColor(chromaBg);
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, canvasW, canvasH);
  }

  const transform = computeMotionTransform(time, duration, motionPreset, shapeState.shapeType, { bounceIntensity, idleStyle });

  ctx.save();
  const centerX = canvasW / 2 + transform.translateX * (canvasW / 1920);
  const centerY = canvasH / 2 + transform.translateY * (canvasH / 1080);
  ctx.translate(centerX, centerY);

  if (transform.rotate) ctx.rotate((transform.rotate * Math.PI) / 180);
  const scale3Dx = Math.cos(((transform.rotateY || 0) * Math.PI) / 180);
  const scale3Dy = Math.cos(((transform.rotateX || 0) * Math.PI) / 180);
  ctx.scale(transform.scale * transform.scaleX * scale3Dx, transform.scale * transform.scaleY * scale3Dy);
  ctx.globalAlpha = Math.max(0, Math.min(1, transform.opacity));

  drawShapeToCanvas(ctx, shapeState, targetW, targetH, time, duration, motionPreset);
  ctx.restore();

  return canvas.toDataURL('image/png');
}

/**
 * Renders frame by frame using WebCodecs GPU + mp4-muxer
 */
async function renderWithWebCodecsMp4(
  options: VideoExportOptions,
  encoderConfig: { width: number; height: number; codec: string; bitrate: number }
): Promise<Blob> {
  const {
    shapeState,
    shapeWidth,
    shapeHeight,
    duration,
    fps,
    chromaBg,
    motionPreset,
    bounceIntensity,
    idleStyle,
    onProgress
  } = options;

  const canvasW = encoderConfig.width;
  const canvasH = encoderConfig.height;

  const canvas = document.createElement('canvas');
  canvas.width = canvasW;
  canvas.height = canvasH;
  const ctx = canvas.getContext('2d', {
    alpha: chromaBg === 'transparent',
    willReadFrequently: false
  });
  if (!ctx) throw new Error('Gagal menginisialisasi 2D Canvas context');

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  const scaleFit = Math.min((canvasW * 0.72) / shapeWidth, (canvasH * 0.72) / shapeHeight, 2.4);
  const targetW = shapeWidth * scaleFit;
  const targetH = shapeHeight * scaleFit;

  const bgColor = getChromaBackgroundColor(chromaBg);
  const totalFrames = duration * fps;

  const muxer = new Muxer({
    target: new ArrayBufferTarget(),
    video: {
      codec: 'avc',
      width: canvasW,
      height: canvasH,
      frameRate: fps
    },
    fastStart: 'in-memory',
    firstTimestampBehavior: 'offset'
  });

  let encodeError: any = null;
  const videoEncoder = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (e) => {
      console.error('VideoEncoder error:', e);
      encodeError = e;
    }
  });

  videoEncoder.configure({
    codec: encoderConfig.codec,
    width: canvasW,
    height: canvasH,
    bitrate: encoderConfig.bitrate,
    framerate: fps,
    avc: { format: 'avc' }
  });

  const frameDurationMicros = Math.round((1 / fps) * 1_000_000);

  for (let frame = 0; frame < totalFrames; frame++) {
    if (encodeError) throw encodeError;

    // Strict backpressure management: wait if encoder queue has more than 5 items
    while (videoEncoder.encodeQueueSize > 5) {
      await new Promise<void>((resolve) => {
        const timer = setTimeout(resolve, 20);
        videoEncoder.ondequeue = () => {
          clearTimeout(timer);
          resolve();
        };
      });
      if (encodeError) throw encodeError;
    }

    // 1. Draw Background
    if (chromaBg === 'transparent') {
      ctx.clearRect(0, 0, canvasW, canvasH);
    } else {
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, canvasW, canvasH);
    }

    // 2. Draw animated shape using native vector renderer (GUARANTEED NEVER BLANK)
    const currentTime = frame / fps;
    const transform = computeMotionTransform(currentTime, duration, motionPreset, shapeState.shapeType, { bounceIntensity, idleStyle });

    ctx.save();
    const scaleFactorW = canvasW / 1920;
    const scaleFactorH = canvasH / 1080;
    const centerX = canvasW / 2 + transform.translateX * scaleFactorW;
    const centerY = canvasH / 2 + transform.translateY * scaleFactorH;
    ctx.translate(centerX, centerY);

    if (transform.rotate) {
      ctx.rotate((transform.rotate * Math.PI) / 180);
    }

    const radY = ((transform.rotateY || 0) * Math.PI) / 180;
    const radX = ((transform.rotateX || 0) * Math.PI) / 180;
    const scale3Dx = Math.cos(radY);
    const scale3Dy = Math.cos(radX);

    const finalScaleX = transform.scale * transform.scaleX * scale3Dx;
    const finalScaleY = transform.scale * transform.scaleY * scale3Dy;
    ctx.scale(finalScaleX, finalScaleY);

    ctx.globalAlpha = Math.max(0, Math.min(1, transform.opacity));

    // NATIVE DIRECT VECTOR DRAWING (No Image tags, no cross-origin, no async blank)
    drawShapeToCanvas(ctx, shapeState, targetW, targetH, currentTime, duration, motionPreset);
    ctx.restore();

    // 3. Create VideoFrame and encode
    const frameTimestampMicros = Math.round(frame * frameDurationMicros);
    const videoFrame = new VideoFrame(canvas, {
      timestamp: frameTimestampMicros,
      duration: frameDurationMicros
    });

    const isKeyFrame = frame % Math.min(fps, 30) === 0;
    videoEncoder.encode(videoFrame, { keyFrame: isKeyFrame });
    videoFrame.close();

    const percent = Math.round(((frame + 1) / totalFrames) * 100);
    if (onProgress) {
      onProgress(
        frame + 1,
        totalFrames,
        percent,
        `GPU H.264: Frame ${frame + 1}/${totalFrames}`
      );
    }

    // Yield to browser UI thread periodically
    if (frame % 8 === 0) {
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  if (onProgress) {
    onProgress(totalFrames, totalFrames, 100, 'Memfinalisasi MP4 Container...');
  }

  await videoEncoder.flush();
  videoEncoder.close();
  muxer.finalize();

  const mp4Blob = new Blob([muxer.target.buffer], { type: 'video/mp4' });
  return mp4Blob;
}

/**
 * Renders frame by frame using WebAssembly OpenH264 (100% Reliable CPU Engine)
 * Runs in ANY browser, immune to GPU hardware issues, produces standard H.264 MP4.
 */
async function renderWithWasmH264(options: VideoExportOptions): Promise<Blob> {
  const {
    shapeState,
    shapeWidth,
    shapeHeight,
    duration,
    fps,
    resolution,
    chromaBg,
    motionPreset,
    bounceIntensity,
    idleStyle,
    onProgress
  } = options;

  const { width: rawW, height: rawH } = getResolutionDimensions(resolution);
  // WASM H.264 requires dimensions divisible by 2
  const canvasW = rawW % 2 === 0 ? rawW : rawW - 1;
  const canvasH = rawH % 2 === 0 ? rawH : rawH - 1;

  if (onProgress) {
    onProgress(0, duration * fps, 0, 'Memuat WebAssembly H.264 Video Engine...');
  }

  const encoder = await createH264MP4Encoder();
  encoder.width = canvasW;
  encoder.height = canvasH;
  encoder.frameRate = fps;
  encoder.quantizationParameter = 18; // Visually lossless quality (10-51 scale)
  encoder.groupOfPictures = Math.min(fps, 30); // Keyframe interval
  encoder.speed = 5; // Balanced CPU speed
  encoder.initialize();

  const canvas = document.createElement('canvas');
  canvas.width = canvasW;
  canvas.height = canvasH;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Gagal membuat Canvas 2D untuk WASM encoder');

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  const scaleFit = Math.min((canvasW * 0.72) / shapeWidth, (canvasH * 0.72) / shapeHeight, 2.4);
  const targetW = shapeWidth * scaleFit;
  const targetH = shapeHeight * scaleFit;

  const bgColor = getChromaBackgroundColor(chromaBg);
  const totalFrames = duration * fps;

  for (let frame = 0; frame < totalFrames; frame++) {
    // 1. Background
    if (chromaBg === 'transparent') {
      // H.264 cannot preserve alpha, but clearing still prevents stale pixels
      // from previous frames when the CPU fallback is selected.
      ctx.clearRect(0, 0, canvasW, canvasH);
    } else {
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, canvasW, canvasH);
    }

    // 2. Animated Shape
    const currentTime = frame / fps;
    const transform = computeMotionTransform(currentTime, duration, motionPreset, shapeState.shapeType, { bounceIntensity, idleStyle });

    ctx.save();
    const scaleFactorW = canvasW / 1920;
    const scaleFactorH = canvasH / 1080;
    const centerX = canvasW / 2 + transform.translateX * scaleFactorW;
    const centerY = canvasH / 2 + transform.translateY * scaleFactorH;
    ctx.translate(centerX, centerY);

    if (transform.rotate) ctx.rotate((transform.rotate * Math.PI) / 180);

    const radY = ((transform.rotateY || 0) * Math.PI) / 180;
    const radX = ((transform.rotateX || 0) * Math.PI) / 180;
    const scale3Dx = Math.cos(radY);
    const scale3Dy = Math.cos(radX);

    const finalScaleX = transform.scale * transform.scaleX * scale3Dx;
    const finalScaleY = transform.scale * transform.scaleY * scale3Dy;
    ctx.scale(finalScaleX, finalScaleY);

    ctx.globalAlpha = Math.max(0, Math.min(1, transform.opacity));

    drawShapeToCanvas(ctx, shapeState, targetW, targetH, currentTime, duration, motionPreset);
    ctx.restore();

    // 3. Extract RGBA pixel buffer and feed to OpenH264
    const imageData = ctx.getImageData(0, 0, canvasW, canvasH);
    encoder.addFrameRgba(imageData.data);

    const percent = Math.round(((frame + 1) / totalFrames) * 100);
    if (onProgress) {
      onProgress(
        frame + 1,
        totalFrames,
        percent,
        `WASM H.264: Frame ${frame + 1}/${totalFrames}`
      );
    }

    if (frame % 4 === 0) {
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  if (onProgress) {
    onProgress(totalFrames, totalFrames, 100, 'Menyelesaikan file MP4...');
  }

  encoder.finalize();
  const uint8 = encoder.FS.readFile(encoder.outputFilename);
  encoder.delete();

  return new Blob([uint8.buffer], { type: 'video/mp4' });
}

/**
 * Main Video Export Function
 * Tiers:
 * 1. WebCodecs GPU + mp4-muxer (Blazing fast, 4K/1080p 60fps)
 * 2. WebAssembly H.264 Encoder (100% Guaranteed 0-fail, universal fallback)
 */
export async function renderAndExportVideo(options: VideoExportOptions): Promise<Blob> {
  const {
    fps,
    resolution,
    qualityProfile = 'ultra',
    preferredEngine = 'auto',
    onProgress
  } = options;

  const { width: reqW, height: reqH } = getResolutionDimensions(resolution);
  const targetBitrate =
    resolution === '4k'
      ? qualityProfile === 'ultra'
        ? 45_000_000
        : 32_000_000
      : qualityProfile === 'ultra'
      ? 25_000_000
      : 18_000_000;

  // Try WebCodecs first if preferred !== 'wasm_h264'
  if (preferredEngine !== 'wasm_h264' && typeof VideoEncoder !== 'undefined') {
    try {
      const encoderConfig = await getSupportedAvcConfig(reqW, reqH, fps, targetBitrate);
      if (encoderConfig) {
        return await renderWithWebCodecsMp4(options, encoderConfig);
      }
    } catch (webCodecsErr) {
      console.warn('WebCodecs GPU render failed or unsupported, automatically falling back to WASM H.264:', webCodecsErr);
      if (onProgress) {
        onProgress(0, 100, 0, 'Beralih ke WebAssembly OpenH264 Engine...');
      }
    }
  }

  // Fallback to WASM H.264 (Guaranteed to work everywhere)
  return await renderWithWasmH264(options);
}

/**
 * Direct file download helper
 */
export async function downloadVideoFile(blob: Blob, filename: string) {
  saveAs(blob, filename);
}

/**
 * Batch render multiple items and bundle into a zip of MP4s
 */
export async function batchRenderZip(
  items: VideoExportOptions[],
  onOverallProgress: (currentIndex: number, totalItems: number, itemPercent: number, status: string) => void
): Promise<Blob> {
  const zip = new JSZip();

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const blob = await renderAndExportVideo({
      ...item,
      onProgress: (frame, total, percent, stage) => {
        onOverallProgress(i, items.length, percent, `Video ${i + 1}/${items.length}: ${stage}`);
      }
    });

    const isMp4 = blob.type.includes('mp4');
    const ext = isMp4 ? 'mp4' : 'webm';
    const cleanLabel = item.shapeLabel.toLowerCase().replace(/[^a-z0-9]/g, '_');
    const fileName = `${String(i + 1).padStart(2, '0')}_${cleanLabel}_${item.motionPreset}_${item.duration}s_${item.resolution}_60fps.${ext}`;
    zip.file(fileName, blob);
  }

  const zipBlob = await zip.generateAsync({ type: 'blob' });
  return zipBlob;
}
