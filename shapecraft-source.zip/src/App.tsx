import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Download,
  Film,
  Layers,
  Settings,
  Palette,
  Check,
  Copy,
  FolderArchive,
  Eye,
  EyeOff,
  Maximize2,
  Tv,
  Tag,
  FileVideo,
  Volume2,
  VolumeX,
  FastForward,
  Clock,
  ShieldCheck,
  Flame,
  LayoutGrid,
  ChevronRight,
  Info,
  HelpCircle,
  Share2,
  Sliders,
  Compass,
  Type,
  Star,
  Search,
  ArrowRight,
  CheckCircle2,
  Bookmark
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveAs } from 'file-saver';
import JSZip from 'jszip';

import { MASTER_PRESETS, MasterPreset } from './curatedPresets';

import {
  ShapeState,
  ShapeType,
  MotionPreset,
  ChromaBg,
  VideoDuration,
  VideoFps,
  VideoResolution,
  StockMetadata,
  BounceIntensity,
  IdleMotionStyle
} from './types';
import { ALL_SHAPES, MOTION_PRESETS, PRESET_COLORS, ShapeDefinition } from './shapeDefinitions';
import { presets, defaultState } from './presets';
import {
  computeMotionTransform,
  getChromaBackgroundColor,
  getTimelinePhase,
  generateStockMetadata
} from './motionEngine';
import { generateShapeSvg } from './shapeRenderer';
import {
  renderAndExportVideo,
  getResolutionDimensions,
  batchRenderZip,
  renderSingleFrameToDataUrl,
  drawShapeToCanvas
} from './videoExporter';
import {
  GeneratedPackItem,
  loadStoredGeneratedItems,
  saveStoredGeneratedItems,
  generateTenUniqueItems
} from './shapeGenerator';
import { MATERIAL_LIST, MaterialDef } from './materialTextures';

export default function App() {
  // Shape State: Clean, tactile editorial paper container with customizable text
  const [shapeState, setShapeState] = useState<ShapeState>(() => ({
    ...defaultState,
    shapeType: 'clean_minimal_card',
    width: 620,
    height: 380,
    bgColor: '#faf7f2', // Warm Cotton Cream
    textureType: 'cotton_rag',
    textureOpacity: 45,
    borderStyle: 'solid',
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.08)',
    shadowBlur: 22,
    shadowDistance: 10,
    shadowOpacity: 16,
    textContent: '',
    fontFamily: 'Inter, sans-serif',
    fontSize: 22,
    fontWeight: '700',
    fontColor: '#292524',
    textAlign: 'center',
    hideText: true
  }));

  // Video Motion & Timeline States
  const [motionPreset, setMotionPreset] = useState<MotionPreset>('paper_reveal');
  const [bounceIntensity, setBounceIntensity] = useState<BounceIntensity>('snappy');
  const [idleStyle, setIdleStyle] = useState<IdleMotionStyle>('breathing');
  const [videoDuration, setVideoDuration] = useState<VideoDuration>(7); // Default 7s (Adobe Stock sweet spot)
  const [videoFps, setVideoFps] = useState<VideoFps>(60); // Default 60 FPS
  const [videoResolution, setVideoResolution] = useState<VideoResolution>('1080p'); // Default 1080p Full HD
  const [qualityProfile, setQualityProfile] = useState<'ultra' | 'high'>('ultra'); // Ultra Master (50 Mbps)
  const [preferredEngine, setPreferredEngine] = useState<'auto' | 'webcodecs' | 'wasm_h264'>('auto');
  const [chromaBg, setChromaBg] = useState<ChromaBg>('green_screen'); // Default pure #00FF00
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [showCopyGuide, setShowCopyGuide] = useState<boolean>(true);
  const [previewScale, setPreviewScale] = useState<'standard' | 'large' | 'cinema'>('large');

  // Live Playback Engine
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const lastTimeRef = useRef<number>(performance.now());
  const animFrameRef = useRef<number | null>(null);
  const stageCanvasRef = useRef<HTMLCanvasElement>(null);

  // Active Category & Tab
  const [activeTab, setActiveTab] = useState<'presets' | 'motion' | 'typography' | 'shapes' | 'styling' | 'metadata' | 'export'>('presets');
  const [presetCategoryFilter, setPresetCategoryFilter] = useState<'all' | 'editorial' | 'action_comic' | 'wedding_luxury' | 'scrapbook_tape' | 'minimal_label'>('all');
  const [presetSearchQuery, setPresetSearchQuery] = useState<string>('');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('master_cotton_deckle_crumple');
  const [motionSeries, setMotionSeries] = useState<'all' | 'paper_titles' | 'paper_labels' | 'scrapbook_elements' | 'paper_transitions'>('all');
  const [shapeCategory, setShapeCategory] = useState<'all' | 'text_container' | 'comment' | 'postcard' | 'greeting_card' | 'tape' | 'tag_bookmark'>('all');
  const [materialFilter, setMaterialFilter] = useState<'all' | 'paper' | 'fabric' | 'luxury' | 'stone' | 'print'>('all');

  // Procedural Shapes
  const [generatedItems, setGeneratedItems] = useState<GeneratedPackItem[]>(() => loadStoredGeneratedItems());
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Export State & Progress
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<{ frame: number; total: number; percent: number; text: string }>({
    frame: 0,
    total: 0,
    percent: 0,
    text: ''
  });
  const [isBatchModalOpen, setIsBatchModalOpen] = useState<boolean>(false);
  const [batchSelectedShapes, setBatchSelectedShapes] = useState<string[]>(() => [
    'clean_minimal_card',
    'clean_speech_bubble',
    'blank_classic_postcard',
    'folded_greeting_card',
    'straight_washi_tape',
    'blank_luggage_tag'
  ]);
  const [isBatchRendering, setIsBatchRendering] = useState<boolean>(false);
  const [batchProgress, setBatchProgress] = useState<{ current: number; total: number; percent: number }>({
    current: 0,
    total: 0,
    percent: 0
  });

  // Metadata Copy State
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Combined Shapes List
  const allShapes = useMemo(() => {
    return [...ALL_SHAPES, ...generatedItems.map((g) => g.definition)];
  }, [generatedItems]);

  // Current Active Shape Definition
  const currentShapeDef = useMemo(() => {
    return allShapes.find((s) => s.id === shapeState.shapeType) || ALL_SHAPES[0];
  }, [allShapes, shapeState.shapeType]);

  // Show Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Playback Tick Engine
  useEffect(() => {
    const loop = (now: number) => {
      if (isPlaying) {
        const deltaSec = ((now - lastTimeRef.current) / 1000) * playbackSpeed;
        setCurrentTime((prev) => {
          const next = prev + deltaSec;
          if (next >= videoDuration) {
            return isLooping ? 0 : videoDuration;
          }
          return next;
        });
      }
      lastTimeRef.current = now;
      animFrameRef.current = requestAnimationFrame(loop);
    };

    lastTimeRef.current = performance.now();
    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, videoDuration, playbackSpeed, isLooping]);

  // Spacebar toggle shortcut for play/pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && (e.target as HTMLElement).tagName !== 'INPUT' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Compute live transform matrix for current time
  const currentTransform = useMemo(() => {
    return computeMotionTransform(currentTime, videoDuration, motionPreset, shapeState.shapeType, { bounceIntensity, idleStyle });
  }, [currentTime, videoDuration, motionPreset, shapeState.shapeType, bounceIntensity, idleStyle]);

  // Current timeline phase
  const currentPhase = useMemo(() => {
    return getTimelinePhase(currentTime, videoDuration);
  }, [currentTime, videoDuration]);

  // Generate SVG string for preview
  const liveSvgString = useMemo(() => {
    return generateShapeSvg(shapeState, { showCopySpaceGuide: showCopyGuide });
  }, [shapeState, showCopyGuide]);

  // Clean SVG without copy guide for clean export
  const cleanExportSvgString = useMemo(() => {
    return generateShapeSvg(shapeState, { showCopySpaceGuide: false });
  }, [shapeState]);

  // Stock metadata
  const stockMetadata = useMemo<StockMetadata>(() => {
    return generateStockMetadata(
      currentShapeDef.label,
      currentShapeDef.category,
      chromaBg,
      motionPreset,
      videoDuration,
      videoResolution,
      videoFps
    );
  }, [currentShapeDef, chromaBg, motionPreset, videoDuration, videoResolution, videoFps]);

  // Live Stage Canvas Rendering (Matches Exported MP4 100%)
  useEffect(() => {
    const canvas = stageCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // 1. Background
    if (chromaBg === 'transparent' || chromaBg === 'checkerboard') {
      ctx.clearRect(0, 0, w, h);
    } else {
      ctx.fillStyle = getChromaBackgroundColor(chromaBg);
      ctx.fillRect(0, 0, w, h);
    }

    // 2. Draw Transformed Shape & Physical Morph Animation
    const scaleFit = Math.min((w * 0.72) / shapeState.width, (h * 0.72) / shapeState.height, 2.4);
    const targetW = shapeState.width * scaleFit;
    const targetH = shapeState.height * scaleFit;

    const transform = computeMotionTransform(currentTime, videoDuration, motionPreset, shapeState.shapeType, { bounceIntensity, idleStyle });

    ctx.save();
    const centerX = w / 2 + transform.translateX * (w / 1920);
    const centerY = h / 2 + transform.translateY * (h / 1080);
    ctx.translate(centerX, centerY);

    if (transform.rotate) ctx.rotate((transform.rotate * Math.PI) / 180);
    const scale3Dx = Math.cos(((transform.rotateY || 0) * Math.PI) / 180);
    const scale3Dy = Math.cos(((transform.rotateX || 0) * Math.PI) / 180);
    ctx.scale(transform.scale * transform.scaleX * scale3Dx, transform.scale * transform.scaleY * scale3Dy);
    ctx.globalAlpha = Math.max(0, Math.min(1, transform.opacity));

    drawShapeToCanvas(ctx, shapeState, targetW, targetH, currentTime, videoDuration, motionPreset);

    // 3. Optional Copy Space Safe Guide during Hold Phase
    if (showCopyGuide && currentPhase === 'hold') {
      const marginX = targetW * 0.16;
      const marginY = targetH * 0.18;
      const gw = targetW - marginX * 2;
      const gh = targetH - marginY * 2;
      ctx.save();
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(-targetW / 2 + marginX, -targetH / 2 + marginY, gw, gh);
      ctx.fillStyle = 'rgba(6, 182, 212, 0.07)';
      ctx.fillRect(-targetW / 2 + marginX, -targetH / 2 + marginY, gw, gh);
      ctx.fillStyle = '#0891b2';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('SAFE COPY SPACE', 0, -4);
      ctx.font = '10px sans-serif';
      ctx.fillStyle = '#0e7490';
      ctx.fillText('HOLD FOR BUYER TEXT', 0, 12);
      ctx.restore();
    }

    ctx.restore();
  }, [
    currentTime,
    shapeState,
    motionPreset,
    chromaBg,
    videoDuration,
    videoResolution,
    bounceIntensity,
    idleStyle,
    showCopyGuide,
    currentPhase
  ]);

  // Generate Procedural Shapes
  const handleGenerateNewShapes = () => {
    const nextPack = Math.floor(generatedItems.length / 10) + 1;
    const newItems = generateTenUniqueItems(nextPack);
    const updated = [...generatedItems, ...newItems];
    setGeneratedItems(updated);
    saveStoredGeneratedItems(updated);
    if (newItems.length > 0) {
      setShapeState((prev) => ({
        ...prev,
        ...newItems[0].preset.state,
        shapeType: newItems[0].definition.id,
        hideText: true
      }));
    }
    showToast(`✨ Berhasil membuat 10 model bentuk baru (Paket #${nextPack})!`);
  };

  // Jump to specific timeline milestones
  const jumpTo = (time: number) => {
    setCurrentTime(Math.min(videoDuration, Math.max(0, time)));
  };

  // Single Video Render & Export
  const handleExportSingleVideo = async () => {
    setIsPlaying(false);
    setIsExporting(true);
    setExportProgress({
      frame: 0,
      total: videoDuration * videoFps,
      percent: 0,
      text: `Menyiapkan video MP4 ${videoResolution.toUpperCase()} (${qualityProfile === 'ultra' ? 'Master 50 Mbps' : '25 Mbps'}, ${videoFps} FPS)...`
    });

    try {
      const blob = await renderAndExportVideo({
        shapeState,
        shapeSvgString: cleanExportSvgString,
        shapeWidth: shapeState.width,
        shapeHeight: shapeState.height,
        shapeType: shapeState.shapeType,
        shapeLabel: currentShapeDef.label,
        duration: videoDuration,
        fps: videoFps,
        resolution: videoResolution,
        chromaBg,
        motionPreset,
        bounceIntensity,
        idleStyle,
        qualityProfile,
        preferredEngine,
        onProgress: (frame, total, percent, stage) => {
          setExportProgress({
            frame,
            total,
            percent,
            text: `${stage} [${frame}/${total}] (${percent}%)`
          });
        }
      });

      const isMp4 = blob.type.includes('mp4');
      const ext = isMp4 ? 'mp4' : 'webm';
      const cleanName = currentShapeDef.label.toLowerCase().replace(/[^a-z0-9]/g, '_');
      const fileName = `AdobeStock_${cleanName}_${motionPreset}_${chromaBg}_${videoDuration}s_${videoResolution}_${videoFps}fps.${ext}`;
      saveAs(blob, fileName);

      showToast(`🎬 Video ${ext.toUpperCase()} ${videoDuration}s ${videoResolution.toUpperCase()} berhasil diekspor!`);
    } catch (err: any) {
      console.error('Video export error:', err);
      showToast('⚠️ Gagal: ' + (err?.message || 'Kendala saat merender MP4'));
    } finally {
      setIsExporting(false);
    }
  };

  // Quick Test Single Frame verification
  const handleTestFrame = () => {
    const checkTime = currentTime > 0 ? currentTime : 2.5; // default hold phase
    const dataUrl = renderSingleFrameToDataUrl({
      shapeState,
      shapeWidth: shapeState.width,
      shapeHeight: shapeState.height,
      chromaBg,
      motionPreset,
      bounceIntensity,
      idleStyle,
      resolution: videoResolution,
      duration: videoDuration,
      time: checkTime
    });
    if (!dataUrl) {
      showToast('⚠️ Gagal menghasilkan preview frame.');
      return;
    }
    const link = document.createElement('a');
    const cleanName = currentShapeDef.label.toLowerCase().replace(/[^a-z0-9]/g, '_');
    link.download = `FrameTest_${cleanName}_${chromaBg}_${checkTime.toFixed(1)}s.png`;
    link.href = dataUrl;
    link.click();
    showToast('📸 Frame PNG berhasil diunduh untuk verifikasi bentuk & warna!');
  };

  // Batch Video Render & Export
  const handleBatchRender = async () => {
    if (batchSelectedShapes.length === 0) {
      showToast('Pilih minimal 1 bentuk untuk batch export.');
      return;
    }

    setIsPlaying(false);
    setIsBatchRendering(true);
    setBatchProgress({ current: 0, total: batchSelectedShapes.length, percent: 0 });

    try {
      const itemsToRender = batchSelectedShapes.map((shapeId) => {
        const def = allShapes.find((s) => s.id === shapeId) || ALL_SHAPES[0];
        const itemState = { ...shapeState, shapeType: shapeId, hideText: true };
        const svg = generateShapeSvg(itemState, { showCopySpaceGuide: false });
        return {
          shapeState: itemState,
          shapeSvgString: svg,
          shapeWidth: itemState.width,
          shapeHeight: itemState.height,
          shapeType: shapeId,
          shapeLabel: def.label,
          duration: videoDuration,
          fps: videoFps,
          resolution: videoResolution,
          chromaBg,
          motionPreset,
          bounceIntensity,
          idleStyle,
          qualityProfile,
          preferredEngine
        };
      });

      const zipBlob = await batchRenderZip(itemsToRender, (cur, total, itemPercent, status) => {
        setBatchProgress({
          current: cur + 1,
          total,
          percent: Math.round(((cur + itemPercent / 100) / total) * 100)
        });
      });

      saveAs(zipBlob, `AdobeStock_Batch_${batchSelectedShapes.length}_MP4_Videos_${videoDuration}s_${chromaBg}.zip`);
      showToast(`📦 Berhasil mengunduh ZIP berisi ${batchSelectedShapes.length} video klip!`);
      setIsBatchModalOpen(false);
    } catch (err) {
      console.error('Batch error:', err);
      showToast('⚠️ Gagal melakukan batch render.');
    } finally {
      setIsBatchRendering(false);
    }
  };

  // Copy to clipboard helper
  const copyText = (text: string, fieldId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldId);
    setTimeout(() => setCopiedField(null), 2500);
  };

  // Aspect Ratio for Video Canvas Viewport
  const aspectRatioClass = videoResolution === 'reels_9_16'
    ? 'aspect-[9/16] max-w-[340px]'
    : videoResolution === 'square_1_1'
    ? 'aspect-square max-w-[500px]'
    : 'aspect-video w-full max-w-[760px]';

  const chromaColor = getChromaBackgroundColor(chromaBg);

  return (
    <div className="min-h-screen bg-[#0a0d14] text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-emerald-500 text-slate-950 font-semibold px-5 py-2.5 rounded-full shadow-2xl flex items-center gap-2 text-sm border border-emerald-300"
          >
            <Sparkles className="w-4 h-4" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Navigation Bar */}
      <header className="h-16 border-b border-white/10 bg-slate-950/80 backdrop-blur-xl px-5 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black text-xl">
            🎬
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-white text-base">ShapeMotion Pro</span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-semibold px-2 py-0.5 rounded border border-emerald-500/30">
                ADOBE STOCK VIDEO STUDIO
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Generator Animasi 6–7s Tanpa Teks • Chroma Green Screen • 4K 60FPS
            </p>
          </div>
        </div>

        {/* Quick Badges & Actions */}
        <div className="flex items-center gap-3">
          <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Chroma: <strong className="text-emerald-300 font-medium">{chromaBg === 'green_screen' ? '#00FF00' : chromaBg}</strong></span>
            <span className="text-white/20">|</span>
            <span>Durasi: <strong className="text-white font-medium">{videoDuration}s</strong></span>
            <span className="text-white/20">|</span>
            <span>{videoResolution.toUpperCase()} @ {videoFps} FPS</span>
          </div>

          <button
            onClick={() => setIsBatchModalOpen(true)}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-medium text-slate-200 transition"
          >
            <FolderArchive className="w-3.5 h-3.5 text-amber-400" />
            <span>Batch Render Pack</span>
          </button>

          <button
            onClick={handleExportSingleVideo}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/25 transition disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Merender...' : 'Ekspor Video 4K'}</span>
          </button>
        </div>
      </header>

      {/* ========================================================= */}
      {/* 1. TOP FROZEN PANE: LIVE PREVIEW STAGE & SCRUBBER TIMELINE */}
      {/* ========================================================= */}
      <div className="sticky top-0 z-30 bg-[#090d16]/95 backdrop-blur-xl border-b border-white/10 shadow-2xl shrink-0">
        <div className="max-w-[1800px] mx-auto p-3 lg:p-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
            {/* Left Column: Canvas Cinema Viewport (7 cols on desktop for Large & Clear Visuals) */}
            <div className="lg:col-span-7 flex flex-col items-center justify-center">
              <div
                className={`relative rounded-2xl overflow-hidden border border-white/20 shadow-2xl flex items-center justify-center w-full transition-all duration-300 ${
                  previewScale === 'cinema'
                    ? 'h-[360px] sm:h-[420px] lg:h-[460px]'
                    : previewScale === 'large'
                    ? 'h-[270px] sm:h-[330px] lg:h-[360px]'
                    : 'h-[200px] sm:h-[240px] lg:h-[260px]'
                } ${chromaBg === 'checkerboard' ? 'checkerboard-dark' : ''}`}
                style={{
                  backgroundColor: chromaBg !== 'checkerboard' ? chromaColor : undefined
                }}
              >
                {/* Corner Watermark REC Badge */}
                <div className="absolute top-2.5 left-2.5 bg-black/75 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-mono text-emerald-400 border border-white/15 pointer-events-none z-10 flex items-center gap-1.5 shadow-lg">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>REC • {videoResolution.toUpperCase()} 60FPS</span>
                </div>

                <div className="absolute top-2.5 right-2.5 bg-black/75 backdrop-blur-md px-2.5 py-1 rounded-lg text-[10px] font-mono text-slate-200 border border-white/15 pointer-events-none z-10 shadow-lg">
                  Phase: <strong className={currentPhase === 'in' ? 'text-emerald-400' : currentPhase === 'hold' ? 'text-amber-300' : 'text-rose-400'}>
                    {currentPhase === 'in' ? 'IN 1.4s' : currentPhase === 'hold' ? 'HOLD 4s (COPY SPACE)' : 'OUT 1.3s'}
                  </strong>
                </div>

                {/* The Live High-Performance Stage Canvas (100% Identical to Rendered MP4) */}
                <canvas
                  ref={stageCanvasRef}
                  width={videoResolution === 'reels_9_16' ? 1080 : videoResolution === 'square_1_1' ? 1080 : 1920}
                  height={videoResolution === 'reels_9_16' ? 1920 : videoResolution === 'square_1_1' ? 1080 : 1080}
                  className="w-full h-full object-contain"
                />

                {/* Safe Copy Space Area banner */}
                {showCopyGuide && currentPhase === 'hold' && (
                  <div className="absolute bottom-3 bg-cyan-950/90 backdrop-blur border border-cyan-500/50 text-cyan-300 px-3 py-1 rounded-full text-[10px] font-medium tracking-wide flex items-center gap-1.5 z-10 pointer-events-none shadow-xl">
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Area Teks Aman (Copy Space 4s)</span>
                  </div>
                )}
              </div>
            </div>

            {/* Right Column: Screen Modes, Interactive Scrubber, Playback Controls, Quick Materials (5 cols) */}
            <div className="lg:col-span-5 flex flex-col justify-center space-y-2.5">
              {/* Top Controls Row: Screen background & Preview Zoom */}
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] text-slate-400 font-medium">Layar:</span>
                  <div className="flex items-center gap-1 bg-white/5 p-0.5 rounded-lg border border-white/10">
                    <button
                      onClick={() => setChromaBg('green_screen')}
                      className={`px-2 py-0.5 rounded text-[11px] font-semibold transition flex items-center gap-1 ${
                        chromaBg === 'green_screen'
                          ? 'bg-emerald-500 text-slate-950 shadow'
                          : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      <span className="w-2 h-2 rounded-full bg-[#00ff00] border border-black/30"></span>
                      Green
                    </button>
                    <button
                      onClick={() => setChromaBg('blue_screen')}
                      className={`px-2 py-0.5 rounded text-[11px] font-semibold transition flex items-center gap-1 ${
                        chromaBg === 'blue_screen'
                          ? 'bg-blue-600 text-white shadow'
                          : 'text-slate-300 hover:text-white'
                      }`}
                    >
                      <span className="w-2 h-2 rounded-full bg-[#0000ff] border border-white/30"></span>
                      Blue
                    </button>
                    <button
                      onClick={() => setChromaBg('pure_black')}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                        chromaBg === 'pure_black' ? 'bg-white/20 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Hitam
                    </button>
                    <button
                      onClick={() => setChromaBg('checkerboard')}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                        chromaBg === 'checkerboard' ? 'bg-white/20 text-white' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Alpha
                    </button>
                  </div>
                </div>

                {/* Preview Size Selector & Copy Space Guide Toggle */}
                <div className="flex items-center gap-1.5">
                  <div className="flex items-center gap-0.5 bg-white/5 p-0.5 rounded-lg border border-white/10 text-[10px]">
                    <span className="px-1 text-slate-400 font-medium">Ukuran:</span>
                    <button
                      onClick={() => setPreviewScale('standard')}
                      className={`px-1.5 py-0.5 rounded transition ${
                        previewScale === 'standard' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Kecil
                    </button>
                    <button
                      onClick={() => setPreviewScale('large')}
                      className={`px-1.5 py-0.5 rounded transition ${
                        previewScale === 'large' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Besar
                    </button>
                    <button
                      onClick={() => setPreviewScale('cinema')}
                      className={`px-1.5 py-0.5 rounded transition ${
                        previewScale === 'cinema' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Cinema
                    </button>
                  </div>

                  <button
                    onClick={() => setShowCopyGuide((g) => !g)}
                    className={`flex items-center gap-1 px-2 py-1 rounded-lg border text-[10px] transition ${
                      showCopyGuide
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                        : 'bg-white/5 text-slate-400 border-white/10 hover:text-white'
                    }`}
                    title="Toggle Garis Batas Safe Copy Space"
                  >
                    {showCopyGuide ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                    <span>Batas</span>
                  </button>
                </div>
              </div>

              {/* Interactive Timeline & Scrubber Panel */}
              <div className="bg-black/40 border border-white/10 rounded-xl p-2.5 space-y-1.5 shadow-inner">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setIsPlaying((p) => !p)}
                      className="w-8 h-8 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center font-bold shadow-md active:scale-95 transition"
                      title="Play/Pause (Spasi)"
                    >
                      {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                    </button>

                    <button
                      onClick={() => jumpTo(0)}
                      className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 flex items-center justify-center border border-white/10 transition"
                      title="Awal (0.0s)"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => setIsLooping((l) => !l)}
                      className={`px-2 py-1 rounded text-[10px] font-medium border transition ${
                        isLooping ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-white/5 text-slate-400 border-white/10'
                      }`}
                    >
                      Loop
                    </button>

                    {/* Speed Controls */}
                    <div className="flex items-center gap-0.5 bg-white/5 p-0.5 rounded border border-white/10 text-[10px]">
                      {[0.5, 1, 1.5].map((spd) => (
                        <button
                          key={spd}
                          onClick={() => setPlaybackSpeed(spd)}
                          className={`px-1.5 py-0.5 rounded font-mono ${
                            playbackSpeed === spd ? 'bg-white/20 text-white font-bold' : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Timecode & Quick Phase Jumps */}
                  <div className="flex items-center gap-2 text-[11px] font-mono">
                    <div className="bg-black/60 px-2 py-0.5 rounded border border-white/10 text-emerald-400 font-bold flex items-center gap-1.5">
                      <Clock className="w-3 h-3" />
                      <span>{currentTime.toFixed(2)}s</span>
                      <span className="text-slate-500">/</span>
                      <span className="text-slate-300">{videoDuration.toFixed(2)}s</span>
                    </div>

                    <div className="flex items-center gap-1 font-sans text-[10px]">
                      <button
                        onClick={() => jumpTo(0.1)}
                        className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 hover:bg-emerald-500/20"
                      >
                        ▶ In
                      </button>
                      <button
                        onClick={() => jumpTo(2.5)}
                        className="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20 hover:bg-amber-500/20"
                      >
                        ■ Hold 4s
                      </button>
                      <button
                        onClick={() => jumpTo(videoDuration - 0.8)}
                        className="px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20 hover:bg-rose-500/20"
                      >
                        ◀ Out
                      </button>
                    </div>
                  </div>
                </div>

                {/* Scrubber Range Bar */}
                <div className="relative pt-1">
                  <div className="h-2 w-full rounded-full bg-slate-800 overflow-hidden flex relative border border-white/10">
                    <div style={{ width: `${(1.4 / videoDuration) * 100}%` }} className="h-full bg-emerald-500/60 border-r border-slate-900" title="In" />
                    <div style={{ width: `${((videoDuration - 2.7) / videoDuration) * 100}%` }} className="h-full bg-amber-500/60 border-r border-slate-900" title="Hold Copy Space" />
                    <div style={{ width: `${(1.3 / videoDuration) * 100}%` }} className="h-full bg-rose-500/60" title="Out" />
                    <div style={{ width: `${(currentTime / videoDuration) * 100}%` }} className="absolute top-0 bottom-0 left-0 bg-white/30 pointer-events-none" />
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={videoDuration}
                    step={0.02}
                    value={currentTime}
                    onChange={(e) => {
                      setIsPlaying(false);
                      setCurrentTime(parseFloat(e.target.value));
                    }}
                    className="w-full mt-1.5 accent-emerald-400 cursor-pointer"
                  />
                </div>
              </div>

              {/* Quick Paper Motion Archetypes Bar */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 text-xs no-scrollbar">
                <span className="text-[10px] text-emerald-400 font-bold whitespace-nowrap flex items-center gap-1 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  <span>📁 Motion Kit:</span>
                </span>
                {[
                  { id: 'paper_reveal', label: '📄 1. Paper Reveal' },
                  { id: 'torn_paper_text', label: '📜 2. Torn Paper' },
                  { id: 'sticky_note_seq', label: '📌 3. Sticky Note' },
                  { id: 'tape_and_paper', label: '🩹 4. Tape + Paper' },
                  { id: 'layered_scrapbook', label: '🖼️ 5. Layered Scrapbook' },
                  { id: 'paper_stack_titles', label: '📑 6. Paper Stack' },
                  { id: 'handwritten_paper', label: '✍️ 7. Handwritten' },
                  { id: 'paper_window_mask', label: '🪟 8. Window Mask' },
                  { id: 'floating_paper_labels', label: '🏷️ 9. Floating Label' },
                  { id: 'paper_crumple_unfold', label: '📜 10. 3D Crumpled' },
                  { id: 'shatter_assemble', label: '🧩 Pecah Utuh' },
                  { id: 'speed_wind_comic_morph', label: '💨 Wind Speedlines' },
                  { id: 'wedding_ribbon_floral_unfurl', label: '💌 Wedding Floral' }
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      setMotionPreset(t.id as MotionPreset);
                      jumpTo(0);
                      setIsPlaying(true);
                    }}
                    className={`px-2 py-0.5 rounded-md border whitespace-nowrap text-[10px] font-medium transition ${
                      motionPreset === t.id
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold border-emerald-400 shadow-sm'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Quick Material Presets Bar */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 text-xs no-scrollbar">
                <span className="text-[10px] text-slate-400 font-semibold whitespace-nowrap flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-400" />
                  <span>Material:</span>
                </span>
                {[
                  { id: 'washi_kozo', label: '🎋 Washi Kozo', color: '#faf7f2' },
                  { id: 'recycled', label: '♻️ Eco Pulp', color: '#f4efe6' },
                  { id: 'gilded_gold_leaf', label: '✨ Emas 24K', color: '#1e1b18' },
                  { id: 'watercolor_coldpress', label: '🎨 Watercolor 300gsm', color: '#fbf9f5' },
                  { id: 'terrazzo_stone', label: '🏛️ Terrazzo', color: '#f8fafc' },
                  { id: 'marble_vein', label: '💎 Marmer', color: '#f1f5f9' },
                  { id: 'cardboard', label: '📦 Kraft', color: '#d7ba8d' },
                  { id: 'linen_blend', label: '🧵 Linen', color: '#f2ece1' },
                  { id: 'frosted_vellum', label: '📐 Kalkir', color: '#ffffff' },
                  { id: 'holographic_foil', label: '🌈 Hologram', color: '#0f172a' }
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() =>
                      setShapeState((prev) => ({
                        ...prev,
                        textureType: m.id as any,
                        textureOpacity: 60,
                        bgColor: m.color,
                        bgColorSecondary: m.color
                      }))
                    }
                    className={`px-2 py-0.5 rounded-md border whitespace-nowrap text-[10px] transition ${
                      shapeState.textureType === m.id
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400 font-semibold shadow-sm'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 2. SCROLLABLE STUDIO CONTROL WORKSPACE (WIDE MULTI-COLUMN) */}
      {/* ========================================================= */}
      <div className="flex-1 overflow-y-auto bg-slate-950/40 p-4 lg:p-6">
        <div className="max-w-[1700px] mx-auto space-y-5">
          {/* Tabs Navigation Header */}
          <div className="flex border border-white/10 bg-slate-900/90 rounded-2xl p-1.5 gap-1.5 text-xs shadow-xl overflow-x-auto">
            <button
              onClick={() => setActiveTab('presets')}
              className={`flex-1 py-2.5 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap transition ${
                activeTab === 'presets'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-lg shadow-emerald-500/20 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Star className="w-4 h-4" />
              <span>1. Preset Terbaik ({MASTER_PRESETS.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('motion')}
              className={`flex-1 py-2.5 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap transition ${
                activeTab === 'motion'
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Film className="w-4 h-4" />
              <span>2. Motion Series ({MOTION_PRESETS.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('shapes')}
              className={`flex-1 py-2.5 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap transition ${
                activeTab === 'shapes'
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>3. Wadah Kertas ({allShapes.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('styling')}
              className={`flex-1 py-2.5 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap transition ${
                activeTab === 'styling'
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Palette className="w-4 h-4" />
              <span>4. Material & Tekstur ({MATERIAL_LIST.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('typography')}
              className={`flex-1 py-2.5 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap transition ${
                activeTab === 'typography'
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Type className="w-4 h-4" />
              <span>5. Tipografi (Opsional)</span>
            </button>
            <button
              onClick={() => setActiveTab('metadata')}
              className={`flex-1 py-2.5 px-3 rounded-xl font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap transition ${
                activeTab === 'metadata'
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <Tag className="w-4 h-4" />
              <span>6. Metadata Stock</span>
            </button>
          </div>

          {/* Tab Content Panels */}
          <div className="bg-slate-900/60 border border-white/10 rounded-2xl p-5 lg:p-6 shadow-2xl">
            {/* TAB 0: MASTER PRESETS (DESAIN TERBAIK BARU) */}
            {activeTab === 'presets' && (
              <div className="space-y-5">
                {/* Header & Search Bar */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-white/10 pb-4">
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                      <span>Koleksi Preset Desain Terbaik & Baru (Commercial Ready)</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Kombinasi utuh wadah kertas, animasi transformasi fisik, material tekstur, dan durasi hold 4 detik bebas teks untuk Adobe Stock.
                    </p>
                  </div>

                  {/* Search Input */}
                  <div className="relative min-w-[240px]">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={presetSearchQuery}
                      onChange={(e) => setPresetSearchQuery(e.target.value)}
                      placeholder="Cari preset (crumple, wedding, wind)..."
                      className="w-full bg-slate-950/80 border border-white/15 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 transition"
                    />
                  </div>
                </div>

                {/* Category Filter Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
                  {[
                    { id: 'all', label: `✨ Semua Preset (${MASTER_PRESETS.length})` },
                    { id: 'editorial', label: '📜 Editorial & Paper' },
                    { id: 'action_comic', label: '⚡ Action & Comic Morph' },
                    { id: 'wedding_luxury', label: '💍 Wedding & Luxury' },
                    { id: 'scrapbook_tape', label: '🖼️ Scrapbook & Washi Tape' },
                    { id: 'minimal_label', label: '🏷️ Labels & Badges' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setPresetCategoryFilter(cat.id as any)}
                      className={`py-1.5 px-3 rounded-lg font-medium whitespace-nowrap transition ${
                        presetCategoryFilter === cat.id
                          ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                          : 'bg-white/5 text-slate-300 hover:bg-white/10 hover:text-white border border-white/10'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Presets Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {MASTER_PRESETS.filter((p) => {
                    const matchesCategory = presetCategoryFilter === 'all' || p.category === presetCategoryFilter;
                    const matchesSearch =
                      presetSearchQuery.trim() === '' ||
                      p.title.toLowerCase().includes(presetSearchQuery.toLowerCase()) ||
                      p.subtitle.toLowerCase().includes(presetSearchQuery.toLowerCase()) ||
                      p.bestFor.toLowerCase().includes(presetSearchQuery.toLowerCase()) ||
                      p.stockTags.some((t) => t.toLowerCase().includes(presetSearchQuery.toLowerCase()));
                    return matchesCategory && matchesSearch;
                  }).map((p) => {
                    const isSelected = selectedPresetId === p.id;
                    return (
                      <div
                        key={p.id}
                        className={`rounded-2xl border p-4 transition flex flex-col justify-between space-y-3 relative group ${
                          isSelected
                            ? 'bg-emerald-500/10 border-emerald-400 shadow-xl ring-1 ring-emerald-400/40'
                            : 'bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/[0.07]'
                        }`}
                      >
                        {/* Top Kicker & Badge */}
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-2">
                            <span className="text-[10px] font-bold text-amber-300 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                              {p.badge}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {p.categoryLabel}
                            </span>
                          </div>

                          <div className="flex items-start gap-2.5">
                            <span className="text-2xl">{p.icon}</span>
                            <div>
                              <h4 className="text-sm font-bold text-white group-hover:text-emerald-300 transition">
                                {p.title}
                              </h4>
                              <p className="text-xs text-slate-400 mt-1 leading-relaxed line-clamp-2">
                                {p.subtitle}
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Specs & Best For */}
                        <div className="space-y-2 text-[11px] pt-1 border-t border-white/5">
                          <div className="flex items-center justify-between text-slate-300">
                            <span className="text-slate-400">Motion:</span>
                            <span className="font-mono text-emerald-400 font-medium">
                              {p.motionPreset.replace(/_/g, ' ')}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-slate-300">
                            <span className="text-slate-400">Material:</span>
                            <span className="text-slate-200 capitalize">
                              {p.state.textureType?.replace(/_/g, ' ') || 'Alami'}
                            </span>
                          </div>

                          <div className="text-[10px] text-slate-400 bg-black/40 p-2 rounded-lg border border-white/5 leading-snug">
                            <strong className="text-slate-300">Cocok Untuk:</strong> {p.bestFor}
                          </div>
                        </div>

                        {/* 1-Click Apply Button */}
                        <button
                          onClick={() => {
                            setSelectedPresetId(p.id);
                            setMotionPreset(p.motionPreset);
                            setBounceIntensity(p.bounceIntensity);
                            setIdleStyle(p.idleStyle);
                            setVideoDuration(p.recommendedDuration as VideoDuration);
                            setChromaBg(p.chromaBg);
                            setShapeState((prev) => ({
                              ...prev,
                              ...p.state,
                              hideText: true,
                              textContent: ''
                            }));
                            jumpTo(0);
                            setIsPlaying(true);
                            setToastMessage(`✨ Preset "${p.title}" Berhasil Diterapkan!`);
                            setTimeout(() => setToastMessage(null), 3000);
                          }}
                          className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-[0.98] ${
                            isSelected
                              ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/25'
                              : 'bg-white/10 hover:bg-emerald-500 hover:text-slate-950 text-white border border-white/10'
                          }`}
                        >
                          {isSelected ? (
                            <>
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Sedang Aktif (Diuji di Preview)</span>
                            </>
                          ) : (
                            <>
                              <span>Terapkan Preset Ini</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            {/* TAB 1: MOTION & 4 ASSET SERIES */}
            {activeTab === 'motion' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-0.5">
                        <Sparkles className="w-4 h-4 text-emerald-400" />
                        <span>Modular Paper Text Motion System</span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Pilihan 10 Arketipe Gerakan Kertas Modular + 4s Hold Copy Space.
                      </p>
                    </div>
                  </div>

                  {/* 4 Series Filter Tabs */}
                  <div className="flex items-center gap-1.5 p-1 bg-white/5 rounded-xl border border-white/10 text-xs overflow-x-auto">
                    <button
                      onClick={() => setMotionSeries('all')}
                      className={`py-1.5 px-2.5 rounded-lg font-semibold whitespace-nowrap transition ${
                        motionSeries === 'all'
                          ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      Semua Seri
                    </button>
                    <button
                      onClick={() => setMotionSeries('paper_titles')}
                      className={`py-1.5 px-2.5 rounded-lg font-semibold whitespace-nowrap transition flex items-center gap-1 ${
                        motionSeries === 'paper_titles'
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md font-bold'
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <span>📄 1. Paper Titles</span>
                    </button>
                    <button
                      onClick={() => setMotionSeries('paper_labels')}
                      className={`py-1.5 px-2.5 rounded-lg font-semibold whitespace-nowrap transition flex items-center gap-1 ${
                        motionSeries === 'paper_labels'
                          ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <span>📌 2. Paper Labels</span>
                    </button>
                    <button
                      onClick={() => setMotionSeries('scrapbook_elements')}
                      className={`py-1.5 px-2.5 rounded-lg font-semibold whitespace-nowrap transition flex items-center gap-1 ${
                        motionSeries === 'scrapbook_elements'
                          ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <span>🩹 3. Tape & Elements</span>
                    </button>
                    <button
                      onClick={() => setMotionSeries('paper_transitions')}
                      className={`py-1.5 px-2.5 rounded-lg font-semibold whitespace-nowrap transition flex items-center gap-1 ${
                        motionSeries === 'paper_transitions'
                          ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                          : 'text-slate-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <span>🪟 4. Transitions</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 gap-2 max-h-[580px] overflow-y-auto pr-1">
                    {MOTION_PRESETS.filter((m) => {
                      if (motionSeries === 'all') return true;
                      return m.series === motionSeries;
                    }).map((m) => (
                      <button
                        key={m.id}
                        onClick={() => {
                          setMotionPreset(m.id as MotionPreset);
                          jumpTo(0);
                          setIsPlaying(true);
                        }}
                        className={`p-3 rounded-xl border text-left transition flex items-start gap-3 ${
                          motionPreset === m.id
                            ? 'bg-emerald-500/15 border-emerald-400 text-white shadow-lg ring-1 ring-emerald-500/30'
                            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        <span className="text-2xl mt-0.5">{m.icon}</span>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-xs text-white">{m.name}</span>
                            {motionPreset === m.id && (
                              <Check className="w-4 h-4 text-emerald-400" />
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{m.desc}</p>
                          <span className="inline-block mt-1 text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                            Cocok untuk: {m.bestFor}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Column 2: Physics, Format & MP4 Engine */}
                <div className="space-y-4">
                  {/* Physics & Copy-Space Idle Tuning */}
                  <div className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-4">
                    <h4 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center justify-between">
                      <span>Fisika Animasi & Copy Space</span>
                      <span className="text-[10px] text-emerald-400 font-mono">Adobe Stock Standard</span>
                    </h4>

                    {/* Bounce / Elasticity Strength */}
                    <div>
                      <label className="text-xs text-slate-400 block mb-1.5">Intensitas Pantulan (Bounce Easing):</label>
                      <div className="grid grid-cols-3 gap-1.5 text-xs">
                        {[
                          { id: 'soft', label: 'Soft Elegan', sub: 'Overshoot 4%' },
                          { id: 'snappy', label: 'Snappy Standar', sub: 'Overshoot 8%' },
                          { id: 'ultra_bouncy', label: 'Kenyal Bouncy', sub: 'Overshoot 14%' }
                        ].map((b) => (
                          <button
                            key={b.id}
                            onClick={() => setBounceIntensity(b.id as BounceIntensity)}
                            className={`p-2 rounded-lg border text-center transition ${
                              bounceIntensity === b.id
                                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-semibold'
                                : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                            }`}
                          >
                            <div className="text-[11px]">{b.label}</div>
                            <div className="text-[9px] text-slate-400">{b.sub}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Idle Copy-Space Motion */}
                    <div>
                      <label className="text-xs text-slate-400 block mb-1.5">Gerakan Saat Hold (Copy Space 4 Detik):</label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {[
                          { id: 'breathing', label: 'Nafas Mikro (1%)', desc: 'Denyut skala halus agar layer tetap hidup' },
                          { id: 'float', label: 'Hover Mengambang', desc: 'Melayang naik-turun halus gaya modern' },
                          { id: 'sway', label: 'Ayunan Santai', desc: 'Rotasi fisika mengayun lembut' },
                          { id: 'still', label: 'Diam Total', desc: 'Tanpa gerak, statis murni untuk teks padat' }
                        ].map((item) => (
                          <button
                            key={item.id}
                            onClick={() => setIdleStyle(item.id as IdleMotionStyle)}
                            className={`p-2 rounded-lg border text-left transition ${
                              idleStyle === item.id
                                ? 'bg-emerald-500/20 border-emerald-400 text-white'
                                : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                            }`}
                          >
                            <div className="font-semibold text-xs text-emerald-300">{item.label}</div>
                            <div className="text-[10px] text-slate-400 line-clamp-1">{item.desc}</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Format & Durasi Video */}
                  <div className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-4">
                    <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
                      Format & Durasi Video (Adobe Stock)
                    </h4>

                    {/* Duration Buttons */}
                    <div>
                      <label className="text-xs text-slate-400 block mb-1.5">Durasi Klip Video:</label>
                      <div className="grid grid-cols-4 gap-2">
                        {([5, 6, 7, 10] as VideoDuration[]).map((dur) => (
                          <button
                            key={dur}
                            onClick={() => {
                              setVideoDuration(dur);
                              jumpTo(0);
                            }}
                            className={`py-2 px-2 rounded-lg text-xs font-medium border text-center transition ${
                              videoDuration === dur
                                ? 'bg-emerald-500 text-slate-950 font-bold border-emerald-400 shadow'
                                : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                            }`}
                          >
                            {dur} Detik
                            {dur === 7 && <span className="block text-[9px] text-slate-950 font-extrabold uppercase">Terbaik</span>}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Resolution Selector */}
                    <div>
                      <label className="text-xs text-slate-400 block mb-1.5">Resolusi Kanvas Video:</label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <button
                          onClick={() => setVideoResolution('4k')}
                          className={`p-2 rounded-lg border text-left transition ${
                            videoResolution === '4k'
                              ? 'bg-emerald-500/20 border-emerald-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <div className="font-bold text-emerald-300">4K UHD (3840×2160)</div>
                          <div className="text-[10px] text-slate-400">16:9 Landscape • Nilai Jual Tinggi</div>
                        </button>

                        <button
                          onClick={() => setVideoResolution('1080p')}
                          className={`p-2 rounded-lg border text-left transition ${
                            videoResolution === '1080p'
                              ? 'bg-emerald-500/20 border-emerald-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <div className="font-bold text-white">Full HD (1920×1080)</div>
                          <div className="text-[10px] text-slate-400">16:9 Landscape • Render Cepat</div>
                        </button>

                        <button
                          onClick={() => setVideoResolution('reels_9_16')}
                          className={`p-2 rounded-lg border text-left transition ${
                            videoResolution === 'reels_9_16'
                              ? 'bg-emerald-500/20 border-emerald-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <div className="font-bold text-white">Vertical (1080×1920)</div>
                          <div className="text-[10px] text-slate-400">9:16 Reels / Shorts / TikTok</div>
                        </button>

                        <button
                          onClick={() => setVideoResolution('square_1_1')}
                          className={`p-2 rounded-lg border text-left transition ${
                            videoResolution === 'square_1_1'
                              ? 'bg-emerald-500/20 border-emerald-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <div className="font-bold text-white">Persegi (1080×1080)</div>
                          <div className="text-[10px] text-slate-400">1:1 Square Post & Ads</div>
                        </button>
                      </div>
                    </div>

                    {/* FPS Selector */}
                    <div>
                      <label className="text-xs text-slate-400 block mb-1.5">Framerate (FPS):</label>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <button
                          onClick={() => setVideoFps(60)}
                          className={`p-2 rounded-lg border font-medium text-center transition ${
                            videoFps === 60
                              ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                              : 'bg-white/5 border-white/10 text-slate-400'
                          }`}
                        >
                          60 FPS (Ultra Halus & Standar Stock)
                        </button>
                        <button
                          onClick={() => setVideoFps(30)}
                          className={`p-2 rounded-lg border font-medium text-center transition ${
                            videoFps === 30
                              ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                              : 'bg-white/5 border-white/10 text-slate-400'
                          }`}
                        >
                          30 FPS (Standar Normal)
                        </button>
                      </div>
                    </div>

                    {/* MP4 Format & Bitrate Profile */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-xs text-slate-400">Format & Kualitas Output:</label>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                          MP4 (H.264 / AVC)
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <button
                          onClick={() => setQualityProfile('ultra')}
                          className={`p-2.5 rounded-lg border text-left transition ${
                            qualityProfile === 'ultra'
                              ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-sm'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <div className="font-bold text-emerald-300 flex items-center justify-between">
                            <span>Ultra Master MP4</span>
                            {qualityProfile === 'ultra' && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">50 Mbps H.264 • Bebas Artefak Kompresi</div>
                        </button>

                        <button
                          onClick={() => setQualityProfile('high')}
                          className={`p-2.5 rounded-lg border text-left transition ${
                            qualityProfile === 'high'
                              ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-sm'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <div className="font-bold text-white flex items-center justify-between">
                            <span>High Broadcast MP4</span>
                            {qualityProfile === 'high' && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">25 Mbps H.264 • Ukuran Ringkas</div>
                        </button>
                      </div>
                    </div>

                    {/* MP4 Encoder Engine Selector */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="text-xs text-slate-400">Mesin Encoding H.264 MP4:</label>
                        <span className="text-[10px] text-emerald-400 font-mono">
                          {preferredEngine === 'auto' ? 'Otomatis Hybrid' : preferredEngine === 'webcodecs' ? 'WebCodecs GPU' : 'WASM CPU'}
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-1.5 text-xs">
                        <button
                          onClick={() => setPreferredEngine('auto')}
                          className={`p-2 rounded-lg border text-center transition ${
                            preferredEngine === 'auto'
                              ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-semibold'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          <div className="text-[11px]">Otomatis</div>
                          <div className="text-[9px] text-slate-400">GPU + Auto WASM</div>
                        </button>
                        <button
                          onClick={() => setPreferredEngine('webcodecs')}
                          className={`p-2 rounded-lg border text-center transition ${
                            preferredEngine === 'webcodecs'
                              ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-semibold'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          <div className="text-[11px]">WebCodecs</div>
                          <div className="text-[9px] text-slate-400">GPU Akselerasi</div>
                        </button>
                        <button
                          onClick={() => setPreferredEngine('wasm_h264')}
                          className={`p-2 rounded-lg border text-center transition ${
                            preferredEngine === 'wasm_h264'
                              ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 font-semibold'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          <div className="text-[11px]">OpenH264</div>
                          <div className="text-[9px] text-slate-400">CPU 100% Stabil</div>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: EDITORIAL TYPOGRAPHY & TEXT CUSTOMIZATION */}
            {activeTab === 'typography' && (
              <div className="space-y-6 max-w-3xl">
                <div className="bg-white/5 p-5 rounded-xl border border-white/10 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-semibold text-white">Kontrol Teks & Wadah Judul</h3>
                      <p className="text-xs text-slate-400">
                        Desainer dapat mengisi teks contoh atau menyembunyikan teks untuk aset video footage kosong (Blank Copy Space).
                      </p>
                    </div>
                    <button
                      onClick={() => setShapeState((s) => ({ ...s, hideText: !s.hideText }))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition flex items-center gap-2 ${
                        shapeState.hideText
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : 'bg-emerald-500 text-slate-950 font-bold border-emerald-400'
                      }`}
                    >
                      <span>{shapeState.hideText ? '🔒 Teks Tersembunyi (Blank Stock)' : '✏️ Teks Aktif'}</span>
                    </button>
                  </div>

                  {!shapeState.hideText && (
                    <div className="space-y-4 pt-2">
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Isi Teks Judul / Kutipan:</label>
                        <textarea
                          rows={3}
                          value={shapeState.textContent || ''}
                          onChange={(e) => setShapeState((s) => ({ ...s, textContent: e.target.value }))}
                          placeholder="Masukkan teks judul atau kutipan..."
                          className="w-full bg-slate-950 border border-white/15 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-emerald-500 font-sans"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        {/* Font Family */}
                        <div>
                          <label className="text-xs text-slate-400 block mb-1">Font Family:</label>
                          <select
                            value={shapeState.fontFamily || 'Inter, sans-serif'}
                            onChange={(e) => setShapeState((s) => ({ ...s, fontFamily: e.target.value }))}
                            className="w-full bg-slate-950 border border-white/15 rounded-lg p-2 text-xs text-white"
                          >
                            <option value="Inter, sans-serif">Inter (Modern Clean)</option>
                            <option value="Montserrat, sans-serif">Montserrat (Geometric Heading)</option>
                            <option value="'Playfair Display', serif">Playfair Display (Luxury Editorial)</option>
                            <option value="'Courier Prime', monospace">Courier (Typewriter Vintage)</option>
                            <option value="'Caveat', cursive">Caveat (Handwritten Signature)</option>
                          </select>
                        </div>

                        {/* Font Size */}
                        <div>
                          <div className="flex justify-between text-xs text-slate-400 mb-1">
                            <span>Ukuran Font:</span>
                            <span className="font-mono text-emerald-400">{shapeState.fontSize || 36}px</span>
                          </div>
                          <input
                            type="range"
                            min={16}
                            max={72}
                            value={shapeState.fontSize || 36}
                            onChange={(e) => setShapeState((s) => ({ ...s, fontSize: parseInt(e.target.value) }))}
                            className="w-full accent-emerald-500 cursor-pointer"
                          />
                        </div>

                        {/* Font Color */}
                        <div>
                          <label className="text-xs text-slate-400 block mb-1">Warna Teks:</label>
                          <div className="flex items-center gap-2">
                            <input
                              type="color"
                              value={shapeState.fontColor || '#292524'}
                              onChange={(e) => setShapeState((s) => ({ ...s, fontColor: e.target.value }))}
                              className="w-8 h-8 rounded border border-white/20 bg-transparent cursor-pointer"
                            />
                            <span className="text-xs font-mono text-slate-300">{shapeState.fontColor || '#292524'}</span>
                          </div>
                        </div>
                      </div>

                      {/* Alignment */}
                      <div>
                        <label className="text-xs text-slate-400 block mb-1">Perataan Teks:</label>
                        <div className="flex gap-2">
                          {(['left', 'center', 'right'] as const).map((align) => (
                            <button
                              key={align}
                              onClick={() => setShapeState((s) => ({ ...s, textAlign: align }))}
                              className={`flex-1 py-1.5 rounded-lg border text-xs capitalize transition ${
                                shapeState.textAlign === align
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400 font-bold'
                                  : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                              }`}
                            >
                              {align}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: SHAPE SELECTION & 38 WADAH */}
            {activeTab === 'shapes' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-white">Pilih Wadah Bentuk ({allShapes.length})</h3>
                  <button
                    onClick={handleGenerateNewShapes}
                    className="text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20 flex items-center gap-1"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>+10 Bentuk Baru</span>
                  </button>
                </div>

                {/* Category Pills */}
                <div className="flex flex-wrap gap-1 text-[11px]">
                  {[
                    { id: 'all', label: 'Semua' },
                    { id: 'text_container', label: 'Wadah Teks' },
                    { id: 'comment', label: 'Balon Dialog' },
                    { id: 'postcard', label: 'Postcard' },
                    { id: 'greeting_card', label: 'Kartu Lipat' },
                    { id: 'tape', label: 'Tape Lakban' },
                    { id: 'tag_bookmark', label: 'Tag & Bookmark' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setShapeCategory(cat.id as any)}
                      className={`px-2.5 py-1 rounded-lg transition ${
                        shapeCategory === cat.id
                          ? 'bg-white text-slate-950 font-bold shadow'
                          : 'bg-white/5 text-slate-400 hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Shapes Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 max-h-[550px] overflow-y-auto pr-1">
                  {allShapes
                    .filter((s) => shapeCategory === 'all' || s.category === shapeCategory)
                    .map((s) => {
                      const isSelected = shapeState.shapeType === s.id;
                      return (
                        <button
                          key={s.id}
                          onClick={() => {
                            setShapeState((prev) => ({
                              ...prev,
                              shapeType: s.id,
                              hideText: true
                            }));
                            jumpTo(0);
                          }}
                          className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                            isSelected
                              ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-md ring-1 ring-emerald-400/30'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-2xl">{s.icon}</span>
                            {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                          </div>
                          <div>
                            <div className="font-semibold text-xs truncate text-white">{s.label}</div>
                            <div className="text-[10px] text-slate-400 line-clamp-2 mt-0.5">{s.desc}</div>
                          </div>
                        </button>
                      );
                    })}
                </div>
              </div>
            )}

            {/* TAB 3: STYLING & MATERIAL TEKSTUR REALISTIS */}
            {activeTab === 'styling' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* 1. PHYSICAL MATERIAL & TEXTURE SUITE */}
                <div className="bg-gradient-to-br from-emerald-950/40 via-slate-900/60 to-slate-950/80 p-4 rounded-xl border border-emerald-500/30 space-y-3.5 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">
                        Tekstur & Material Fisik ({MATERIAL_LIST.length})
                      </span>
                    </div>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono">
                      Photorealistic 4K
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Sentuhan tekstur material organik (serat washi, pulp daur ulang, 300gsm watercolor, emas 24k, terrazzo, marmer) meningkatkan daya jual di Adobe Stock.
                  </p>

                  {/* Material Category Filter Pills */}
                  <div className="flex flex-wrap gap-1 text-[10px]">
                    {[
                      { id: 'all', label: 'Semua' },
                      { id: 'paper', label: '📄 Kertas Alami' },
                      { id: 'luxury', label: '✨ Emas & Mewah' },
                      { id: 'stone', label: '🏛️ Batu & Marmer' },
                      { id: 'fabric', label: '🧵 Kain & Kulit' },
                      { id: 'print', label: '📰 Cetak & Grid' }
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setMaterialFilter(cat.id as any)}
                        className={`px-2.5 py-1 rounded-lg transition ${
                          materialFilter === cat.id
                            ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                            : 'bg-white/5 text-slate-300 hover:bg-white/10'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>

                  {/* Materials Grid */}
                  <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
                    {/* None / Pure Clean option */}
                    <button
                      onClick={() =>
                        setShapeState((prev) => ({
                          ...prev,
                          textureType: 'none',
                          textureOpacity: 0
                        }))
                      }
                      className={`p-2.5 rounded-xl border text-left transition flex items-start gap-2 ${
                        shapeState.textureType === 'none' || !shapeState.textureType
                          ? 'bg-emerald-500/20 border-emerald-400 text-white shadow'
                          : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10'
                      }`}
                    >
                      <span className="text-xl">⚪</span>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-xs text-white">Polos / Bersih</div>
                        <div className="text-[10px] text-slate-400">Tanpa tekstur material</div>
                      </div>
                    </button>

                    {MATERIAL_LIST
                      .filter((m) => materialFilter === 'all' || m.category === materialFilter)
                      .map((mat) => {
                        const isSelected = shapeState.textureType === mat.id;
                        return (
                          <button
                            key={mat.id}
                            onClick={() => {
                              setShapeState((prev) => ({
                                ...prev,
                                textureType: mat.id,
                                textureOpacity: prev.textureOpacity > 0 ? prev.textureOpacity : mat.defaultOpacity,
                                // Suggest the best matching background color
                                bgColor: mat.bestColors[0] || prev.bgColor,
                                bgColorSecondary: mat.bestColors[0] || prev.bgColorSecondary
                              }));
                            }}
                            className={`p-2.5 rounded-xl border text-left transition flex items-start gap-2 ${
                              isSelected
                                ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-md'
                                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                            }`}
                          >
                            <span className="text-xl">{mat.icon}</span>
                            <div className="flex-1 min-w-0">
                              <div className="font-semibold text-xs text-white truncate">{mat.name}</div>
                              <div className="text-[10px] text-slate-400 line-clamp-1">{mat.description}</div>
                            </div>
                          </button>
                        );
                      })}
                  </div>

                  {/* Texture Opacity & Color Match */}
                  {shapeState.textureType && shapeState.textureType !== 'none' && (
                    <div className="pt-2 border-t border-white/10 space-y-2.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300">Intensitas Tekstur:</span>
                        <span className="font-mono text-emerald-400 font-bold">{shapeState.textureOpacity || 50}%</span>
                      </div>
                      <input
                        type="range"
                        min={10}
                        max={100}
                        value={shapeState.textureOpacity || 50}
                        onChange={(e) =>
                          setShapeState((prev) => ({
                            ...prev,
                            textureOpacity: parseInt(e.target.value)
                          }))
                        }
                        className="w-full accent-emerald-400 cursor-pointer"
                      />

                      {/* Best matching color chips for selected material */}
                      {(() => {
                        const currentMat = MATERIAL_LIST.find((m) => m.id === shapeState.textureType);
                        if (!currentMat || !currentMat.bestColors) return null;
                        return (
                          <div className="flex items-center gap-1.5 pt-1">
                            <span className="text-[10px] text-slate-400">Warna Alami:</span>
                            <div className="flex gap-1">
                              {currentMat.bestColors.map((hex, i) => (
                                <button
                                  key={i}
                                  onClick={() =>
                                    setShapeState((prev) => ({
                                      ...prev,
                                      bgColor: hex,
                                      bgColorSecondary: hex
                                    }))
                                  }
                                  style={{ backgroundColor: hex }}
                                  className="w-5 h-5 rounded-full border border-black/30 hover:scale-110 transition shadow-sm"
                                  title={`Terapkan warna ${hex}`}
                                />
                              ))}
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </div>

                {/* Column 2: Color Palette, Border, Crease Physics */}
                <div className="space-y-4">
                  {/* 2. Color Palette */}
                <div className="bg-white/5 p-3.5 rounded-xl border border-white/10 space-y-3">
                  <label className="text-xs font-semibold text-white block">Palet Warna Wadah:</label>
                  <div className="grid grid-cols-4 gap-2">
                    {PRESET_COLORS.map((col) => (
                      <button
                        key={col.value}
                        onClick={() =>
                          setShapeState((prev) => ({
                            ...prev,
                            bgColor: col.value,
                            bgColorSecondary: col.value
                          }))
                        }
                        className="p-1.5 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 flex items-center gap-2 text-left"
                      >
                        <span
                          className="w-4 h-4 rounded-full border border-black/20"
                          style={{ backgroundColor: col.value }}
                        />
                        <span className="text-[10px] text-slate-300 truncate">{col.name}</span>
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-3 pt-1">
                    <label className="text-xs text-slate-400">Kustom Hex:</label>
                    <input
                      type="color"
                      value={shapeState.bgColor}
                      onChange={(e) =>
                        setShapeState((prev) => ({
                          ...prev,
                          bgColor: e.target.value
                        }))
                      }
                      className="w-8 h-8 rounded border border-white/20 cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={shapeState.bgColor}
                      onChange={(e) =>
                        setShapeState((prev) => ({
                          ...prev,
                          bgColor: e.target.value
                        }))
                      }
                      className="bg-black/40 border border-white/10 px-2.5 py-1 rounded text-xs font-mono text-slate-200 w-24"
                    />
                  </div>
                </div>

                {/* 3. Border Settings */}
                <div className="bg-white/5 p-3.5 rounded-xl border border-white/10 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">Garis Tepi (Border)</span>
                    <select
                      value={shapeState.borderStyle}
                      onChange={(e) =>
                        setShapeState((prev) => ({
                          ...prev,
                          borderStyle: e.target.value as any
                        }))
                      }
                      className="bg-black/60 border border-white/10 rounded px-2 py-1 text-xs text-slate-200"
                    >
                      <option value="none">Tanpa Border</option>
                      <option value="solid">Solid Monoline</option>
                      <option value="dashed">Garis Putus (Dashed)</option>
                      <option value="dotted">Titik (Dotted)</option>
                    </select>
                  </div>

                  {shapeState.borderStyle !== 'none' && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs text-slate-400">
                        <span>Ketebalan: {shapeState.borderWidth}px</span>
                        <input
                          type="range"
                          min={1}
                          max={12}
                          value={shapeState.borderWidth}
                          onChange={(e) =>
                            setShapeState((prev) => ({
                              ...prev,
                              borderWidth: parseInt(e.target.value)
                            }))
                          }
                          className="w-32 accent-emerald-400"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* 4. Realism: Paper Crease & Shine */}
                <div className="bg-white/5 p-3.5 rounded-xl border border-white/10 space-y-3">
                  <span className="text-xs font-semibold text-white block">Efek Fisika & Lipatan Kertas</span>

                  <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                    <div>
                      <span className="font-medium">Lipatan Kertas Kusut (Paper Crease)</span>
                      <p className="text-[10px] text-slate-400">Menambahkan garis tekukan kusut kertas organik</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={Boolean(shapeState.paperCrease)}
                      onChange={(e) =>
                        setShapeState((prev) => ({
                          ...prev,
                          paperCrease: e.target.checked
                        }))
                      }
                      className="rounded accent-emerald-400 w-4 h-4"
                    />
                  </label>

                  {shapeState.paperCrease && (
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[11px] text-slate-400">Variasi Pola Kusut:</span>
                      <button
                        onClick={() =>
                          setShapeState((prev) => ({
                            ...prev,
                            creaseSeed: ((prev.creaseSeed || 1) % 50) + 1
                          }))
                        }
                        className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-xs text-emerald-300 flex items-center gap-1 border border-white/10"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Acak Pola #{shapeState.creaseSeed || 1}</span>
                      </button>
                    </div>
                  )}

                  <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer pt-2 border-t border-white/10">
                    <div>
                      <span className="font-medium">Kilau Mengkilap (Specular Shine)</span>
                      <p className="text-[10px] text-slate-400">Pantulan bias cahaya sudut atas</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={Boolean(shapeState.specularShine)}
                      onChange={(e) =>
                        setShapeState((prev) => ({
                          ...prev,
                          specularShine: e.target.checked
                        }))
                      }
                      className="rounded accent-emerald-400 w-4 h-4"
                    />
                  </label>
                </div>
                </div>
              </div>
            )}

            {/* TAB 4: ADOBE STOCK METADATA (AI TAGS & TITLE) */}
            {activeTab === 'metadata' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-1">
                    <Tag className="w-4 h-4 text-emerald-400" />
                    <span>Metadata Siap Unggah ke Adobe Stock</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Gunakan judul dan kata kunci bahasa Inggris ini untuk memaksimalkan ranking pencarian di portal kontributor.
                  </p>
                </div>

                {/* Commercial Title */}
                <div className="bg-white/5 p-3.5 rounded-xl border border-white/10 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-semibold text-emerald-400 uppercase">Commercial Title</label>
                    <button
                      onClick={() => copyText(stockMetadata.title, 'title')}
                      className="text-xs text-slate-300 hover:text-white flex items-center gap-1"
                    >
                      {copiedField === 'title' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedField === 'title' ? 'Tersalin!' : 'Salin'}</span>
                    </button>
                  </div>
                  <p className="text-xs font-mono text-white bg-black/40 p-2.5 rounded-lg border border-white/5">
                    {stockMetadata.title}
                  </p>
                </div>

                {/* 40+ Keywords */}
                <div className="bg-white/5 p-3.5 rounded-xl border border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-semibold text-emerald-400 uppercase">
                      Keywords ({stockMetadata.keywords.length} Kata Kunci)
                    </label>
                    <button
                      onClick={() => copyText(stockMetadata.keywords.join(', '), 'keywords')}
                      className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 hover:bg-emerald-500/30 flex items-center gap-1"
                    >
                      {copiedField === 'keywords' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedField === 'keywords' ? 'Semua Tersalin!' : 'Salin Semua'}</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-1 max-h-48 overflow-y-auto p-1">
                    {stockMetadata.keywords.map((kw, i) => (
                      <span
                        key={i}
                        className="text-[10px] bg-black/40 border border-white/10 text-slate-300 px-2 py-0.5 rounded-md"
                      >
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Technical Description */}
                <div className="bg-white/5 p-3.5 rounded-xl border border-white/10 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-semibold text-emerald-400 uppercase">Description</label>
                    <button
                      onClick={() => copyText(stockMetadata.description, 'desc')}
                      className="text-xs text-slate-300 hover:text-white flex items-center gap-1"
                    >
                      {copiedField === 'desc' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedField === 'desc' ? 'Tersalin!' : 'Salin'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed bg-black/40 p-2.5 rounded-lg border border-white/5">
                    {stockMetadata.description}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Export Bar */}
          <div className="p-4 border-t border-white/10 bg-slate-950/80 flex items-center gap-2">
            <button
              onClick={handleTestFrame}
              className="py-3 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-slate-200 font-semibold text-xs transition flex items-center gap-1.5"
              title="Unduh 1 Frame PNG saat ini untuk memverifikasi bentuk di atas greenscreen"
            >
              <span>📸 Cek Frame</span>
            </button>
            <button
              onClick={handleExportSingleVideo}
              disabled={isExporting}
              className="flex-1 py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>
                {isExporting
                  ? 'Sedang Meng-encode MP4...'
                  : `Ekspor MP4 ${videoResolution.toUpperCase()} (${qualityProfile === 'ultra' ? '50 Mbps' : '25 Mbps'} • 60 FPS)`}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Render Progress Modal */}
      {isExporting && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-2xl p-6 max-w-md w-full shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30 animate-pulse">
              <Film className="w-8 h-8" />
            </div>

            <div>
              <div className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 mb-1.5">
                H.264 / AVC MP4 • {qualityProfile === 'ultra' ? '50 Mbps Master' : '25 Mbps'} • 60 FPS
              </div>
              <h3 className="text-base font-bold text-white">Encoding Video MP4 Kualitas Tinggi</h3>
              <p className="text-xs text-slate-400 mt-1">{exportProgress.text}</p>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1.5">
              <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-white/10">
                <div
                  style={{ width: `${exportProgress.percent}%` }}
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-150"
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400">
                <span>Frame {exportProgress.frame} / {exportProgress.total}</span>
                <span className="text-emerald-400 font-bold">{exportProgress.percent}%</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-normal bg-black/40 p-2.5 rounded-xl border border-white/5">
              ✨ Format file murni <strong>.MP4 (H.264 / AVC)</strong> siap upload ke Adobe Stock tanpa perlu convert manual. Mendukung Chroma Keying 100% di Premiere Pro, Final Cut, DaVinci, dan CapCut.
            </p>
          </div>
        </div>
      )}

      {/* Batch Render Modal */}
      {isBatchModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/20 rounded-2xl p-6 max-w-xl w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FolderArchive className="w-5 h-5 text-amber-400" />
                  <span>Batch Render Video Pack (ZIP)</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Render beberapa video sekaligus dalam satu paket unduhan untuk Adobe Stock.
                </p>
              </div>
              <button
                onClick={() => setIsBatchModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            {/* Shape Selection Checklist */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-300 font-medium">Pilih Bentuk yang Ingin Dirender:</span>
                <button
                  onClick={() => {
                    if (batchSelectedShapes.length === allShapes.length) {
                      setBatchSelectedShapes([]);
                    } else {
                      setBatchSelectedShapes(allShapes.map((s) => s.id));
                    }
                  }}
                  className="text-emerald-400 hover:underline"
                >
                  {batchSelectedShapes.length === allShapes.length ? 'Hapus Semua' : 'Pilih Semua (38)'}
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-56 overflow-y-auto p-1 bg-black/40 rounded-xl border border-white/5">
                {allShapes.map((s) => {
                  const isChecked = batchSelectedShapes.includes(s.id);
                  return (
                    <label
                      key={s.id}
                      className={`flex items-center gap-2 p-2 rounded-lg border text-xs cursor-pointer transition ${
                        isChecked
                          ? 'bg-emerald-500/15 border-emerald-500/40 text-white'
                          : 'bg-white/5 border-white/10 text-slate-400'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setBatchSelectedShapes((prev) => [...prev, s.id]);
                          } else {
                            setBatchSelectedShapes((prev) => prev.filter((id) => id !== s.id));
                          }
                        }}
                        className="rounded accent-emerald-400"
                      />
                      <span className="truncate">{s.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Batch Progress Bar if rendering */}
            {isBatchRendering && (
              <div className="bg-black/60 p-4 rounded-xl border border-white/10 space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-300">Merender video {batchProgress.current} dari {batchProgress.total}...</span>
                  <span className="text-emerald-400 font-bold">{batchProgress.percent}%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${batchProgress.percent}%` }}
                    className="h-full bg-emerald-500 transition-all duration-200"
                  />
                </div>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setIsBatchModalOpen(false)}
                disabled={isBatchRendering}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-white/10 transition"
              >
                Batal
              </button>
              <button
                onClick={handleBatchRender}
                disabled={isBatchRendering || batchSelectedShapes.length === 0}
                className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition disabled:opacity-50"
              >
                {isBatchRendering ? 'Sedang Merender Batch...' : `Render ${batchSelectedShapes.length} Video & Download ZIP`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
