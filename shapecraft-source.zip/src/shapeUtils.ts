export interface CreaseLine {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  width: number;
  opacity: number;
}

// Pseudo-random deterministic generator for repeatable seed-based variations
function seedRandom(seed: number) {
  let s = Math.sin(seed * 9999) * 10000;
  return () => {
    s = Math.sin(s * 9999) * 10000;
    return s - Math.floor(s);
  };
}

// ==========================================
// 1. WADAH TEKS & LABEL MINIMALIS (10 BENTUK)
// ==========================================

export function getCleanMinimalCardPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const r = Math.min(24, Math.min(aw, ah) * 0.12);
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getSmoothPillBadgePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const r = ah / 2;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getArchMonolineFramePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yb = p + ah;
  const rDome = aw / 2;
  const rBottom = 8;
  const archY = p + rDome;

  return `M ${xl} ${archY}
    A ${rDome} ${rDome} 0 0 1 ${xr} ${archY}
    L ${xr} ${yb - rBottom}
    A ${rBottom} ${rBottom} 0 0 1 ${xr - rBottom} ${yb}
    L ${xl + rBottom} ${yb}
    A ${rBottom} ${rBottom} 0 0 1 ${xl} ${yb - rBottom}
    Z`;
}

export function getChamferedHexLabelPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const c = Math.min(28, Math.min(aw, ah) * 0.2);

  return `M ${xl + c} ${yt}
    L ${xr - c} ${yt}
    L ${xr} ${yt + c}
    L ${xr} ${yb - c}
    L ${xr - c} ${yb}
    L ${xl + c} ${yb}
    L ${xl} ${yb - c}
    L ${xl} ${yt + c}
    Z`;
}

export function getModernSquareMemoPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 8;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getScallopBorderPlatePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;

  const countX = Math.max(5, Math.round(aw / 28));
  const countY = Math.max(3, Math.round(ah / 28));
  const stepX = aw / countX;
  const stepY = ah / countY;
  const scallopR = 4;

  let d = `M ${xl} ${yt}`;
  // Top edge
  for (let i = 0; i < countX; i++) {
    const xMid = xl + (i + 0.5) * stepX;
    const xEnd = xl + (i + 1) * stepX;
    d += ` Q ${xMid} ${yt - scallopR} ${xEnd} ${yt}`;
  }
  // Right edge
  for (let i = 0; i < countY; i++) {
    const yMid = yt + (i + 0.5) * stepY;
    const yEnd = yt + (i + 1) * stepY;
    d += ` Q ${xr + scallopR} ${yMid} ${xr} ${yEnd}`;
  }
  // Bottom edge
  for (let i = countX - 1; i >= 0; i--) {
    const xMid = xl + (i + 0.5) * stepX;
    const xEnd = xl + i * stepX;
    d += ` Q ${xMid} ${yb + scallopR} ${xEnd} ${yb}`;
  }
  // Left edge
  for (let i = countY - 1; i >= 0; i--) {
    const yMid = yt + (i + 0.5) * stepY;
    const yEnd = yt + i * stepY;
    d += ` Q ${xl - scallopR} ${yMid} ${xl} ${yEnd}`;
  }
  d += ' Z';
  return d;
}

export function getCurvedCornerPlaquePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const c = Math.min(32, Math.min(aw, ah) * 0.18);

  return `M ${xl + c} ${yt}
    L ${xr - c} ${yt}
    A ${c} ${c} 0 0 0 ${xr} ${yt + c}
    L ${xr} ${yb - c}
    A ${c} ${c} 0 0 0 ${xr - c} ${yb}
    L ${xl + c} ${yb}
    A ${c} ${c} 0 0 0 ${xl} ${yb - c}
    L ${xl} ${yt + c}
    A ${c} ${c} 0 0 0 ${xl + c} ${yt}
    Z`;
}

export function getSoftCircleBadgePath(W: number, H: number): string {
  const cx = W / 2;
  const cy = H / 2;
  const rx = (W - 36) / 2;
  const ry = (H - 36) / 2;

  return `M ${cx} ${cy - ry}
    A ${rx} ${ry} 0 1 1 ${cx - 0.01} ${cy - ry}
    Z`;
}

export function getFoldedCornerSheetPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 6;
  const foldSize = Math.min(45, Math.min(aw, ah) * 0.22);

  return `M ${xl + r} ${yt}
    L ${xr - foldSize} ${yt}
    L ${xr} ${yt + foldSize}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getMinimalQuoteBoxPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 10;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

// ==========================================
// 2. KOMENTAR & BALON DIALOG (6 BENTUK)
// ==========================================

export function getCleanSpeechBubblePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah * 0.82;
  const r = 16;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + aw * 0.38} ${yb}
    L ${xl + aw * 0.22} ${p + ah}
    L ${xl + aw * 0.26} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getMinimalChatPillPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = Math.min(22, ah * 0.35);

  // Modern chat bubble with sharp lower-left corner
  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + 8} ${yb}
    L ${xl} ${yb}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getThoughtDialogCloudPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah * 0.82;

  // Smooth minimalist cloud body
  const cloud = `M ${xl + aw * 0.25} ${yb}
    C ${xl + aw * 0.08} ${yb}, ${xl} ${yb - ah * 0.18}, ${xl} ${yt + ah * 0.42}
    C ${xl} ${yt + ah * 0.18}, ${xl + aw * 0.14} ${yt}, ${xl + aw * 0.32} ${yt}
    C ${xl + aw * 0.45} ${yt - ah * 0.02}, ${xl + aw * 0.58} ${yt - ah * 0.02}, ${xl + aw * 0.68} ${yt}
    C ${xl + aw * 0.86} ${yt}, ${xr} ${yt + ah * 0.18}, ${xr} ${yt + ah * 0.42}
    C ${xr} ${yb - ah * 0.15}, ${xr - aw * 0.10} ${yb}, ${xl + aw * 0.74} ${yb}
    C ${xl + aw * 0.62} ${yb + ah * 0.04}, ${xl + aw * 0.42} ${yb + ah * 0.04}, ${xl + aw * 0.25} ${yb}
    Z`;

  // 2 floating thought dots
  const d1cx = xl + aw * 0.22;
  const d1cy = yb + ah * 0.08;
  const d1r = Math.min(aw, ah) * 0.05;
  const dot1 = `M ${d1cx} ${d1cy - d1r} A ${d1r} ${d1r} 0 1 1 ${d1cx - 0.01} ${d1cy - d1r} Z`;

  const d2cx = xl + aw * 0.12;
  const d2cy = yb + ah * 0.14;
  const d2r = Math.min(aw, ah) * 0.03;
  const dot2 = `M ${d2cx} ${d2cy - d2r} A ${d2r} ${d2r} 0 1 1 ${d2cx - 0.01} ${d2cy - d2r} Z`;

  return `${cloud} ${dot1} ${dot2}`;
}

export function getQuoteDialogCardPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah * 0.84;
  const r = 12;
  const cx = W / 2;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${cx + 18} ${yb}
    L ${cx} ${p + ah}
    L ${cx - 18} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getCurvedDialogBoxPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah * 0.84;
  const r = 20;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + aw * 0.45} ${yb}
    C ${xl + aw * 0.35} ${yb + 12}, ${xl + aw * 0.20} ${p + ah}, ${xl + aw * 0.15} ${p + ah}
    C ${xl + aw * 0.22} ${yb + 8}, ${xl + aw * 0.28} ${yb}, ${xl + aw * 0.30} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getActionCalloutBadgePath(W: number, H: number): string {
  const cx = W / 2;
  const cy = H / 2;
  const rMax = Math.min(W, H) / 2 - 18;
  const rMin = rMax * 0.82;
  const points = 12;
  let d = '';

  for (let i = 0; i < points * 2; i++) {
    const angle = (i * Math.PI) / points - Math.PI / 2;
    const r = i % 2 === 0 ? rMax : rMin;
    const x = cx + r * Math.cos(angle);
    const y = cy + r * Math.sin(angle);
    if (i === 0) d += `M ${x} ${y}`;
    else d += ` L ${x} ${y}`;
  }
  d += ' Z';
  return d;
}

// ==========================================
// 3. POSTCARD & KARTU FOTO (5 BENTUK)
// ==========================================

export function getBlankClassicPostcardPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 4;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getVerticalArtPostcardPath(W: number, H: number): string {
  return getBlankClassicPostcardPath(W, H);
}

export function getAirmailCleanPostcardPath(W: number, H: number): string {
  return getBlankClassicPostcardPath(W, H);
}

export function getVintageGridPostcardPath(W: number, H: number): string {
  return getBlankClassicPostcardPath(W, H);
}

export function getSquareMiniPostcardPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 6;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

// ==========================================
// 4. KARTU UCAPAN & UNDANGAN (6 BENTUK)
// ==========================================

export function getFoldedGreetingCardPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 6;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getVerticalArchGreetingPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yb = p + ah;
  const rDome = aw / 2;
  const rBottom = 6;
  const archY = p + rDome;

  return `M ${xl} ${archY}
    A ${rDome} ${rDome} 0 0 1 ${xr} ${archY}
    L ${xr} ${yb - rBottom}
    A ${rBottom} ${rBottom} 0 0 1 ${xr - rBottom} ${yb}
    L ${xl + rBottom} ${yb}
    A ${rBottom} ${rBottom} 0 0 1 ${xl} ${yb - rBottom}
    Z`;
}

export function getPocketGiftCardPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 8;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getDeckleEdgeGreetingPath(W: number, H: number, seed: number = 1): string {
  const rnd = seedRandom(seed);
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;

  let d = `M ${xl} ${yt}`;
  const stepsX = Math.round(aw / 8);
  const stepsY = Math.round(ah / 8);

  // Top deckle edge
  for (let i = 1; i <= stepsX; i++) {
    const x = xl + (i / stepsX) * aw;
    const y = yt + (rnd() - 0.5) * 2.5;
    d += ` L ${x} ${y}`;
  }
  // Right deckle edge
  for (let i = 1; i <= stepsY; i++) {
    const y = yt + (i / stepsY) * ah;
    const x = xr + (rnd() - 0.5) * 2.5;
    d += ` L ${x} ${y}`;
  }
  // Bottom deckle edge
  for (let i = stepsX - 1; i >= 0; i--) {
    const x = xl + (i / stepsX) * aw;
    const y = yb + (rnd() - 0.5) * 2.5;
    d += ` L ${x} ${y}`;
  }
  // Left deckle edge
  for (let i = stepsY - 1; i >= 0; i--) {
    const y = yt + (i / stepsY) * ah;
    const x = xl + (rnd() - 0.5) * 2.5;
    d += ` L ${x} ${y}`;
  }
  d += ' Z';
  return d;
}

export function getRibbonTiedCardPath(W: number, H: number): string {
  return getBlankClassicPostcardPath(W, H);
}

export function getDoubleBorderInvitationPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 6;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

// ==========================================
// 5. TAPE LAKBAN & WASHI (7 BENTUK)
// ==========================================

export function getStraightWashiTapePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;

  return `M ${xl} ${yt}
    L ${xr} ${yt}
    L ${xr} ${yb}
    L ${xl} ${yb}
    Z`;
}

export function getTornMaskingTapePath(W: number, H: number, seed: number = 1): string {
  const rnd = seedRandom(seed);
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;

  const teeth = 8;
  const stepH = ah / teeth;

  let d = `M ${xl} ${yt} L ${xr} ${yt}`;
  // Right torn jagged end
  for (let i = 0; i < teeth; i++) {
    const yMid = yt + (i + 0.5) * stepH;
    const yEnd = yt + (i + 1) * stepH;
    const xJitter = (i % 2 === 0 ? 5 : -4) + (rnd() - 0.5) * 3;
    d += ` L ${xr + xJitter} ${yMid} L ${xr} ${yEnd}`;
  }
  d += ` L ${xl} ${yb}`;
  // Left torn jagged end
  for (let i = teeth - 1; i >= 0; i--) {
    const yMid = yt + (i + 0.5) * stepH;
    const yEnd = yt + i * stepH;
    const xJitter = (i % 2 === 0 ? -5 : 4) + (rnd() - 0.5) * 3;
    d += ` L ${xl + xJitter} ${yMid} L ${xl} ${yEnd}`;
  }
  d += ' Z';
  return d;
}

export function getDiagonalTapeStripPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const slant = ah * 0.35;

  return `M ${xl + slant} ${yt}
    L ${xr} ${yt}
    L ${xr - slant} ${yb}
    L ${xl} ${yb}
    Z`;
}

export function getWideKraftPackingTapePath(W: number, H: number): string {
  return getStraightWashiTapePath(W, H);
}

export function getScotchTransparentTapePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 2;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getCrossTapeClusterPath(W: number, H: number): string {
  const cx = W / 2;
  const cy = H / 2;
  const tapeW = Math.min(W, H) * 0.28;
  const len = Math.min(W, H) * 0.85;
  const hlen = len / 2;
  const hw = tapeW / 2;

  // Cross X shape with rounded edges
  return `M ${cx - hlen} ${cy - hw}
    L ${cx - hw} ${cy - hw}
    L ${cx - hw} ${cy - hlen}
    L ${cx + hw} ${cy - hlen}
    L ${cx + hw} ${cy - hw}
    L ${cx + hlen} ${cy - hw}
    L ${cx + hlen} ${cy + hw}
    L ${cx + hw} ${cy + hw}
    L ${cx + hw} ${cy + hlen}
    L ${cx - hw} ${cy + hlen}
    L ${cx - hw} ${cy + hw}
    L ${cx - hlen} ${cy + hw}
    Z`;
}

export function getPerforatedStampTapePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const teeth = Math.max(6, Math.round(aw / 20));
  const stepX = aw / teeth;
  const notchR = 3.5;

  let d = `M ${xl} ${yt}`;
  // Top perforated semi-circle notches
  for (let i = 0; i < teeth; i++) {
    const xStart = xl + i * stepX;
    const xMid = xStart + stepX * 0.5;
    const xEnd = xl + (i + 1) * stepX;
    d += ` L ${xMid - notchR} ${yt} A ${notchR} ${notchR} 0 0 0 ${xMid + notchR} ${yt} L ${xEnd} ${yt}`;
  }
  d += ` L ${xr} ${yb}`;
  // Bottom perforated semi-circle notches
  for (let i = teeth - 1; i >= 0; i--) {
    const xStart = xl + (i + 1) * stepX;
    const xMid = xl + (i + 0.5) * stepX;
    const xEnd = xl + i * stepX;
    d += ` L ${xMid + notchR} ${yb} A ${notchR} ${notchR} 0 0 0 ${xMid - notchR} ${yb} L ${xEnd} ${yb}`;
  }
  d += ' Z';
  return d;
}

// ==========================================
// 6. TAG & AKSESORIS KRAFT (4 BENTUK)
// ==========================================

export function getBlankLuggageTagPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const cut = Math.min(aw, ah) * 0.18;
  const r = 6;

  return `M ${xl + cut} ${yt}
    L ${xr - cut} ${yt}
    L ${xr} ${yt + cut}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + cut}
    Z`;
}

export function getArchivalBookmarkPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 8;
  const cx = W / 2;

  // Vertical bookmark with ribbon notch at bottom
  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb}
    L ${cx} ${yb - ah * 0.08}
    L ${xl} ${yb}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

export function getHexagonalPriceTagPath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const cy = H / 2;
  const cut = Math.min(aw, ah) * 0.2;

  return `M ${xl + cut} ${yt}
    L ${xr - cut} ${yt}
    L ${xr} ${cy}
    L ${xr - cut} ${yb}
    L ${xl + cut} ${yb}
    L ${xl} ${cy}
    Z`;
}

export function getCeramicArtTilePath(W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const r = 16;

  return `M ${xl + r} ${yt}
    L ${xr - r} ${yt}
    A ${r} ${r} 0 0 1 ${xr} ${yt + r}
    L ${xr} ${yb - r}
    A ${r} ${r} 0 0 1 ${xr - r} ${yb}
    L ${xl + r} ${yb}
    A ${r} ${r} 0 0 1 ${xl} ${yb - r}
    L ${xl} ${yt + r}
    A ${r} ${r} 0 0 1 ${xl + r} ${yt}
    Z`;
}

// ==========================================
// INNER VECTOR DECORATIONS FOR EACH SHAPE
// ==========================================

export function getInnerDetailsSVG(shapeType: string, W: number, H: number): string {
  const p = 18;
  const aw = W - 2 * p;
  const ah = H - 2 * p;
  const xl = p;
  const xr = p + aw;
  const yt = p;
  const yb = p + ah;
  const cx = W / 2;
  const cy = H / 2;

  // --- 1. WADAH TEKS & LABEL ---
  if (shapeType === 'clean_minimal_card') {
    return `
      <!-- Inset Hairline Border -->
      <rect x="${p + 10}" y="${p + 10}" width="${aw - 20}" height="${ah - 20}" rx="10" fill="none" stroke="rgba(0,0,0,0.06)" stroke-width="1" />
    `;
  }
  if (shapeType === 'smooth_pill_badge') {
    const r = (ah - 16) / 2;
    return `
      <rect x="${p + 8}" y="${p + 8}" width="${aw - 16}" height="${ah - 16}" rx="${r}" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="1.2" />
    `;
  }
  if (shapeType === 'arch_monoline_frame') {
    const rDome = (aw - 20) / 2;
    const archY = p + 10 + rDome;
    return `
      <!-- Architectural Arch Inset Line -->
      <path d="M ${xl + 10} ${archY} A ${rDome} ${rDome} 0 0 1 ${xr - 10} ${archY} L ${xr - 10} ${yb - 10} L ${xl + 10} ${yb - 10} Z" fill="none" stroke="rgba(0,0,0,0.07)" stroke-width="1.2" />
    `;
  }
  if (shapeType === 'chamfered_hex_label') {
    const c = Math.min(24, Math.min(aw, ah) * 0.18);
    return `
      <polygon points="${xl + 8 + c},${yt + 8} ${xr - 8 - c},${yt + 8} ${xr - 8},${yt + 8 + c} ${xr - 8},${yb - 8 - c} ${xr - 8 - c},${yb - 8} ${xl + 8 + c},${yb - 8} ${xl + 8},${yb - 8 - c} ${xl + 8},${yt + 8 + c}" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1" stroke-dasharray="3,3" />
    `;
  }
  if (shapeType === 'modern_square_memo') {
    return `
      <!-- Top Subtle Glue Strip Accent -->
      <rect x="${xl}" y="${yt}" width="${aw}" height="14" fill="rgba(0,0,0,0.04)" />
      <line x1="${xl}" y1="${yt + 14}" x2="${xr}" y2="${yt + 14}" stroke="rgba(0,0,0,0.06)" stroke-width="1" />
    `;
  }
  if (shapeType === 'scallop_border_plate') {
    return `
      <rect x="${p + 14}" y="${p + 14}" width="${aw - 28}" height="${ah - 28}" rx="8" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1.2" stroke-dasharray="4,4" />
    `;
  }
  if (shapeType === 'curved_corner_plaque') {
    const c = Math.min(28, Math.min(aw, ah) * 0.16);
    return `
      <path d="M ${xl + 8 + c} ${yt + 8} L ${xr - 8 - c} ${yt + 8} A ${c} ${c} 0 0 0 ${xr - 8} ${yt + 8 + c} L ${xr - 8} ${yb - 8 - c} A ${c} ${c} 0 0 0 ${xr - 8 - c} ${yb - 8} L ${xl + 8 + c} ${yb - 8} A ${c} ${c} 0 0 0 ${xl + 8} ${yb - 8 - c} L ${xl + 8} ${yt + 8 + c} A ${c} ${c} 0 0 0 ${xl + 8 + c} ${yt + 8} Z" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1" />
    `;
  }
  if (shapeType === 'soft_circle_badge') {
    const rx = (aw - 20) / 2;
    const ry = (ah - 20) / 2;
    return `
      <!-- Concentric Delicate Inner Ring -->
      <ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1.2" stroke-dasharray="4,3" />
      <ellipse cx="${cx}" cy="${cy}" rx="${rx - 6}" ry="${ry - 6}" fill="none" stroke="rgba(0,0,0,0.05)" stroke-width="0.8" />
    `;
  }
  if (shapeType === 'folded_corner_sheet') {
    const foldSize = Math.min(45, Math.min(aw, ah) * 0.22);
    return `
      <!-- Top Right Folded Dog-Ear Flap with Realistic Soft Shadow -->
      <polygon points="${xr - foldSize},${yt} ${xr - foldSize},${yt + foldSize} ${xr},${yt + foldSize}" fill="rgba(0,0,0,0.08)" />
      <polygon points="${xr - foldSize},${yt} ${xr - foldSize},${yt + foldSize} ${xr},${yt + foldSize}" fill="rgba(255,255,255,0.7)" stroke="rgba(0,0,0,0.12)" stroke-width="1" />
      <!-- Fold Shadow Crease Line -->
      <line x1="${xr - foldSize}" y1="${yt}" x2="${xr}" y2="${yt + foldSize}" stroke="rgba(0,0,0,0.15)" stroke-width="1.2" />
    `;
  }
  if (shapeType === 'minimal_quote_box') {
    return `
      <!-- Editorial Left Accent Line and Subtle Quote Glyph -->
      <line x1="${xl + 14}" y1="${yt + 16}" x2="${xl + 14}" y2="${yb - 16}" stroke="rgba(0,0,0,0.3)" stroke-width="3" stroke-linecap="round" />
      <text x="${xl + 26}" y="${yt + 38}" font-family="Georgia, serif" font-size="34" fill="rgba(0,0,0,0.12)" font-weight="bold">“</text>
    `;
  }

  // --- 2. KOMENTAR & DIALOG ---
  if (shapeType === 'clean_speech_bubble' || shapeType === 'minimal_chat_pill' || shapeType === 'quote_dialog_card' || shapeType === 'curved_dialog_box') {
    return `
      <!-- Clean Chat Inner Highlight Line -->
      <line x1="${xl + 20}" y1="${yt + 8}" x2="${xr - 20}" y2="${yt + 8}" stroke="rgba(255,255,255,0.35)" stroke-width="1" stroke-linecap="round" />
    `;
  }
  if (shapeType === 'thought_dialog_cloud') {
    return `
      <!-- Cloud Subtle Depth Inset -->
      <ellipse cx="${cx}" cy="${yt + ah * 0.42}" rx="${aw * 0.38}" ry="${ah * 0.3}" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1" stroke-dasharray="3,3" />
    `;
  }
  if (shapeType === 'action_callout_badge') {
    const r = Math.min(aw, ah) * 0.32;
    return `
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(0,0,0,0.1)" stroke-width="1" stroke-dasharray="4,4" />
    `;
  }

  // --- 3. POSTCARD & KARTU FOTO ---
  if (shapeType === 'blank_classic_postcard') {
    const midX = W / 2;
    const stampW = 42;
    const stampH = 50;
    return `
      <!-- Classic Postcard Center Dividing Line & Stamp Frame Box -->
      <!-- Vertical Dividing Line -->
      <line x1="${midX}" y1="${p + 24}" x2="${midX}" y2="${H - p - 24}" stroke="rgba(0,0,0,0.14)" stroke-width="1" stroke-dasharray="4,4" />
      <!-- Postage Stamp Guide Box -->
      <rect x="${xr - stampW - 14}" y="${yt + 14}" width="${stampW}" height="${stampH}" fill="none" stroke="rgba(0,0,0,0.16)" stroke-width="1" stroke-dasharray="3,3" />
      <text x="${xr - stampW / 2 - 14}" y="${yt + 14 + stampH / 2 + 3}" text-anchor="middle" font-family="sans-serif" font-size="7" fill="rgba(0,0,0,0.25)" font-weight="bold">POSTAGE</text>
      <!-- 3 Address Guide Lines on Right Half -->
      <line x1="${midX + 24}" y1="${cy + 15}" x2="${xr - 16}" y2="${cy + 15}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" />
      <line x1="${midX + 24}" y1="${cy + 40}" x2="${xr - 16}" y2="${cy + 40}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" />
      <line x1="${midX + 24}" y1="${cy + 65}" x2="${xr - 16}" y2="${cy + 65}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" />
    `;
  }
  if (shapeType === 'vertical_art_postcard') {
    return `
      <!-- Art Postcard Crisp Inner Frame and Bottom Caption Notch -->
      <rect x="${p + 14}" y="${p + 14}" width="${aw - 28}" height="${ah - 60}" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1" />
      <line x1="${p + 24}" y1="${H - p - 24}" x2="${W - p - 24}" y2="${H - p - 24}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" stroke-dasharray="3,3" />
    `;
  }
  if (shapeType === 'airmail_clean_postcard') {
    const stampW = 38;
    const stampH = 46;
    return `
      <!-- Clean Minimal Airmail Stamp Postmark -->
      <circle cx="${xr - stampW - 24}" cy="${yt + 38}" r="16" fill="none" stroke="rgba(0,0,0,0.15)" stroke-width="1" />
      <line x1="${xr - stampW - 44}" y1="${yt + 32}" x2="${xr - stampW - 4}" y2="${yt + 32}" stroke="rgba(0,0,0,0.12)" stroke-width="1" />
      <line x1="${xr - stampW - 44}" y1="${yt + 44}" x2="${xr - stampW - 4}" y2="${yt + 44}" stroke="rgba(0,0,0,0.12)" stroke-width="1" />
      <rect x="${xr - stampW - 14}" y="${yt + 14}" width="${stampW}" height="${stampH}" fill="none" stroke="rgba(220,38,38,0.3)" stroke-width="1.2" stroke-dasharray="3,3" />
      <line x1="${cx}" y1="${p + 20}" x2="${cx}" y2="${H - p - 20}" stroke="rgba(0,0,0,0.12)" stroke-width="1" stroke-dasharray="4,4" />
    `;
  }
  if (shapeType === 'vintage_grid_postcard') {
    const midX = W / 2;
    return `
      <!-- Vintage Grid Address Lines -->
      <line x1="${midX}" y1="${p + 20}" x2="${midX}" y2="${H - p - 20}" stroke="rgba(0,0,0,0.12)" stroke-width="1" />
      <line x1="${midX + 20}" y1="${p + 60}" x2="${xr - 16}" y2="${p + 60}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" />
      <line x1="${midX + 20}" y1="${p + 95}" x2="${xr - 16}" y2="${p + 95}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" />
      <line x1="${midX + 20}" y1="${p + 130}" x2="${xr - 16}" y2="${p + 130}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" />
      <line x1="${midX + 20}" y1="${p + 165}" x2="${xr - 16}" y2="${p + 165}" stroke="rgba(0,0,0,0.12)" stroke-width="0.8" />
    `;
  }
  if (shapeType === 'square_mini_postcard') {
    return `
      <!-- Square Photo Card Photo Window & Bottom Memo Note -->
      <rect x="${p + 12}" y="${p + 12}" width="${aw - 24}" height="${ah * 0.72}" rx="4" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1" />
      <line x1="${p + 20}" y1="${H - p - 16}" x2="${W - p - 20}" y2="${H - p - 16}" stroke="rgba(0,0,0,0.1)" stroke-width="0.8" stroke-dasharray="2,2" />
    `;
  }

  // --- 4. KARTU UCAPAN & UNDANGAN ---
  if (shapeType === 'folded_greeting_card') {
    return `
      <!-- Greeting Card Realistic 3D Center Spine Fold Crease -->
      <!-- Shadow gradient side of fold -->
      <rect x="${cx - 1.5}" y="${yt}" width="1.5" height="${ah}" fill="rgba(0,0,0,0.12)" />
      <!-- Highlight side of fold -->
      <rect x="${cx}" y="${yt}" width="1.5" height="${ah}" fill="rgba(255,255,255,0.4)" />
      <!-- Subtle debossed inner frame on right panel -->
      <rect x="${cx + 14}" y="${p + 16}" width="${(aw / 2) - 28}" height="${ah - 32}" rx="4" fill="none" stroke="rgba(0,0,0,0.06)" stroke-width="0.8" />
    `;
  }
  if (shapeType === 'vertical_arch_greeting') {
    const rDome = (aw - 24) / 2;
    const archY = p + 12 + rDome;
    return `
      <!-- Luxury Wedding Arch Inset Golden/Delicate Border -->
      <path d="M ${xl + 12} ${archY} A ${rDome} ${rDome} 0 0 1 ${xr - 12} ${archY} L ${xr - 12} ${yb - 12} L ${xl + 12} ${yb - 12} Z" fill="none" stroke="rgba(217,119,6,0.35)" stroke-width="1" />
      <path d="M ${xl + 16} ${archY} A ${rDome - 4} ${rDome - 4} 0 0 1 ${xr - 16} ${archY} L ${xr - 16} ${yb - 16} L ${xl + 16} ${yb - 16} Z" fill="none" stroke="rgba(217,119,6,0.2)" stroke-width="0.8" stroke-dasharray="3,3" />
    `;
  }
  if (shapeType === 'pocket_gift_card') {
    const pocketY = yb - ah * 0.42;
    return `
      <!-- Bottom Pocket Sleeve Seam & Thumb Notch -->
      <line x1="${xl}" y1="${pocketY}" x2="${xr}" y2="${pocketY}" stroke="rgba(0,0,0,0.12)" stroke-width="1.5" />
      <path d="M ${cx - 24} ${pocketY} A 24 24 0 0 0 ${cx + 24} ${pocketY}" fill="none" stroke="rgba(0,0,0,0.12)" stroke-width="1.5" />
      <rect x="${xl + 8}" y="${pocketY + 6}" width="${aw - 16}" height="${ah * 0.42 - 14}" rx="4" fill="none" stroke="rgba(0,0,0,0.06)" stroke-width="1" stroke-dasharray="4,4" />
    `;
  }
  if (shapeType === 'deckle_edge_greeting') {
    return `
      <!-- Handmade Cotton Paper Pressed Inset Border -->
      <rect x="${p + 14}" y="${p + 14}" width="${aw - 28}" height="${ah - 28}" rx="2" fill="none" stroke="rgba(0,0,0,0.06)" stroke-width="1.2" />
    `;
  }
  if (shapeType === 'ribbon_tied_card') {
    return `
      <!-- Stationery Card Twin Vertical Ribbon Slits -->
      <rect x="${xl + 24}" y="${cy - 20}" width="4" height="40" rx="1.5" fill="rgba(0,0,0,0.25)" />
      <rect x="${xr - 28}" y="${cy - 20}" width="4" height="40" rx="1.5" fill="rgba(0,0,0,0.25)" />
      <rect x="${p + 12}" y="${p + 12}" width="${aw - 24}" height="${ah - 24}" rx="4" fill="none" stroke="rgba(0,0,0,0.06)" stroke-width="1" stroke-dasharray="4,4" />
    `;
  }
  if (shapeType === 'double_border_invitation') {
    return `
      <!-- Formal Gala Double Inset Border -->
      <rect x="${p + 10}" y="${p + 10}" width="${aw - 20}" height="${ah - 20}" rx="4" fill="none" stroke="rgba(0,0,0,0.14)" stroke-width="1.5" />
      <rect x="${p + 15}" y="${p + 15}" width="${aw - 30}" height="${ah - 30}" rx="2" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="0.8" />
    `;
  }

  // --- 5. TAPE LAKBAN & WASHI ---
  if (shapeType === 'straight_washi_tape' || shapeType === 'torn_masking_tape') {
    return `
      <!-- Semi-Translucent Washi Paper Fibers Striations -->
      <line x1="${xl}" y1="${yt + 4}" x2="${xr}" y2="${yt + 4}" stroke="rgba(255,255,255,0.4)" stroke-width="1" />
      <line x1="${xl}" y1="${yb - 4}" x2="${xr}" y2="${yb - 4}" stroke="rgba(0,0,0,0.08)" stroke-width="1" />
    `;
  }
  if (shapeType === 'wide_kraft_packing_tape') {
    return `
      <!-- Heavy Duty Brown Tape Fiber Lines -->
      <line x1="${xl}" y1="${cy - 6}" x2="${xr}" y2="${cy - 6}" stroke="rgba(0,0,0,0.06)" stroke-width="1.5" stroke-dasharray="12,6" />
      <line x1="${xl}" y1="${cy + 6}" x2="${xr}" y2="${cy + 6}" stroke="rgba(0,0,0,0.06)" stroke-width="1.5" stroke-dasharray="8,10" />
    `;
  }
  if (shapeType === 'scotch_transparent_tape') {
    return `
      <!-- Ultra-Clean Specular Light Glare Strip on Cellophane Tape -->
      <rect x="${xl}" y="${yt + 2}" width="${aw}" height="5" fill="rgba(255,255,255,0.35)" />
      <line x1="${xl}" y1="${yb - 2}" x2="${xr}" y2="${yb - 2}" stroke="rgba(255,255,255,0.2)" stroke-width="0.8" />
    `;
  }
  if (shapeType === 'cross_tape_cluster') {
    return `
      <!-- Crossed Tape Center Intersection Crease -->
      <line x1="${cx - 15}" y1="${cy - 15}" x2="${cx + 15}" y2="${cy + 15}" stroke="rgba(0,0,0,0.06)" stroke-width="1.2" />
      <line x1="${cx - 15}" y1="${cy + 15}" x2="${cx + 15}" y2="${cy - 15}" stroke="rgba(0,0,0,0.06)" stroke-width="1.2" />
    `;
  }
  if (shapeType === 'perforated_stamp_tape') {
    return `
      <!-- Perforated Stamp Ticket Divider Dashes -->
      <line x1="${cx}" y1="${yt}" x2="${cx}" y2="${yb}" stroke="rgba(0,0,0,0.12)" stroke-width="1" stroke-dasharray="3,3" />
    `;
  }

  // --- 6. TAG & BADGE ---
  if (shapeType === 'blank_luggage_tag') {
    return `
      <!-- Brass Eyelet Hole and String -->
      <circle cx="${cx}" cy="${yt + 22}" r="6" fill="rgba(0,0,0,0.25)" stroke="rgba(217,119,6,0.6)" stroke-width="2.5" />
      <circle cx="${cx}" cy="${yt + 22}" r="3.5" fill="rgba(0,0,0,0.5)" />
      <rect x="${p + 10}" y="${yt + 38}" width="${aw - 20}" height="${ah - 48}" rx="4" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1" stroke-dasharray="3,3" />
    `;
  }
  if (shapeType === 'archival_bookmark') {
    return `
      <!-- Bookmark Top Hole & Inset Guide Line -->
      <circle cx="${cx}" cy="${yt + 20}" r="5" fill="rgba(0,0,0,0.25)" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" />
      <rect x="${p + 8}" y="${yt + 36}" width="${aw - 16}" height="${ah - 54}" rx="4" fill="none" stroke="rgba(0,0,0,0.07)" stroke-width="1" stroke-dasharray="4,4" />
    `;
  }
  if (shapeType === 'hexagonal_price_tag') {
    return `
      <!-- Price Tag Punch Hole & Price Box Inset -->
      <circle cx="${xl + 18}" cy="${cy}" r="4.5" fill="rgba(0,0,0,0.3)" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" />
      <rect x="${xl + 32}" y="${yt + 12}" width="${aw - 46}" height="${ah - 24}" rx="4" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="1" />
    `;
  }
  if (shapeType === 'ceramic_art_tile') {
    return `
      <!-- Ceramic Glazed Bevel Inset -->
      <rect x="${p + 8}" y="${p + 8}" width="${aw - 16}" height="${ah - 16}" rx="10" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="1.5" />
      <rect x="${p + 10}" y="${p + 10}" width="${aw - 20}" height="${ah - 20}" rx="8" fill="none" stroke="rgba(0,0,0,0.06)" stroke-width="1" />
    `;
  }

  return '';
}

// Generates subtle realistic geometric paper crease lines
export function getCreaseLines(W: number, H: number, seed: number = 1, count: number = 14): CreaseLine[] {
  const rnd = seedRandom(seed);
  const lines: CreaseLine[] = [];

  for (let i = 0; i < count; i++) {
    const x1 = Math.round(W * 0.08 + rnd() * (W * 0.84));
    const y1 = Math.round(H * 0.08 + rnd() * (H * 0.84));
    const angle = rnd() * Math.PI * 2;
    const len = 35 + rnd() * 120;
    const x2 = Math.round(x1 + Math.cos(angle) * len);
    const y2 = Math.round(y1 + Math.sin(angle) * len);
    const width = 0.8 + rnd() * 0.9;
    const opacity = 0.08 + rnd() * 0.16;

    lines.push({ x1, y1, x2, y2, width, opacity });
  }

  return lines;
}
