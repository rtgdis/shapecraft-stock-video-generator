import { ShapeType, ShapeState } from './types';

export interface ShapeDimensionInfo {
  width: number;
  height: number;
  orientation: 'horizontal' | 'vertical' | 'square';
  label: string;
  description: string;
}

/**
 * Pemetaan dimensi dan proporsi wadah terbaik (optimal/ideal bounding dimensions)
 * untuk seluruh 38 bentuk dekoratif baru di ShapeCraft Pro.
 * Dirancang khusus untuk aset komersial bernilai jual tinggi di AdobeStock / Microstock.
 */
export const SHAPE_IDEAL_DIMENSIONS: Record<ShapeType, ShapeDimensionInfo> = {
  // --- 1. WADAH TEKS & LABEL MINIMALIS ---
  clean_minimal_card: {
    width: 600,
    height: 380,
    orientation: 'horizontal',
    label: 'Kartu Teks Minimalis',
    description: 'Rasio 1.58:1 standar kartu kredit/bisnis serbaguna',
  },
  smooth_pill_badge: {
    width: 580,
    height: 180,
    orientation: 'horizontal',
    label: 'Kapsul Pill Badge',
    description: 'Rasio horizontal 3.2:1 untuk judul/header/status badge',
  },
  arch_monoline_frame: {
    width: 440,
    height: 600,
    orientation: 'vertical',
    label: 'Kubah Portal Arch',
    description: 'Rasio vertikal 1:1.36 estetika arsitektural modern',
  },
  chamfered_hex_label: {
    width: 560,
    height: 320,
    orientation: 'horizontal',
    label: 'Label Sudut Bevel 45°',
    description: 'Rasio 1.75:1 modern geometris untuk tag produk',
  },
  modern_square_memo: {
    width: 480,
    height: 480,
    orientation: 'square',
    label: 'Memo Kubus Minimalis',
    description: 'Rasio 1:1 bujur sangkar untuk sticky note & quote pad',
  },
  scallop_border_plate: {
    width: 540,
    height: 360,
    orientation: 'horizontal',
    label: 'Plat Teks Scallop Renda',
    description: 'Rasio 1.5:1 elegan dengan gerigi scallop tepi halus',
  },
  curved_corner_plaque: {
    width: 560,
    height: 360,
    orientation: 'horizontal',
    label: 'Plakat Sudut Cekung',
    description: 'Rasio 1.55:1 gaya cartouche mewah klasik',
  },
  soft_circle_badge: {
    width: 480,
    height: 480,
    orientation: 'square',
    label: 'Badge Segel Lingkaran',
    description: 'Rasio 1:1 segel bulat untuk stempel & logo mockups',
  },
  folded_corner_sheet: {
    width: 460,
    height: 580,
    orientation: 'vertical',
    label: 'Kertas Lipat Dog-Ear',
    description: 'Rasio 1:1.26 dokumen kertas dengan lipatan sudut realistis',
  },
  minimal_quote_box: {
    width: 580,
    height: 320,
    orientation: 'horizontal',
    label: 'Kotak Kutipan Editorial',
    description: 'Rasio 1.8:1 dengan aksen garis vertikal kutipan',
  },

  // --- 2. KOMENTAR & BALON DIALOG ---
  clean_speech_bubble: {
    width: 520,
    height: 380,
    orientation: 'horizontal',
    label: 'Balon Komentar Halus',
    description: 'Rasio 1.37:1 dengan ekor penunjuk dialog presisi',
  },
  minimal_chat_pill: {
    width: 500,
    height: 240,
    orientation: 'horizontal',
    label: 'Balon Chat Messenger',
    description: 'Rasio 2.1:1 UI messenger modern dengan takik sudut',
  },
  thought_dialog_cloud: {
    width: 540,
    height: 400,
    orientation: 'horizontal',
    label: 'Balon Awan Pikiran',
    description: 'Rasio 1.35:1 awan kumulus lembut dan 2 titik satelit',
  },
  quote_dialog_card: {
    width: 540,
    height: 340,
    orientation: 'horizontal',
    label: 'Kotak Ulasan & Testimoni',
    description: 'Rasio 1.59:1 card testimonial dengan notch segitiga',
  },
  curved_dialog_box: {
    width: 520,
    height: 360,
    orientation: 'horizontal',
    label: 'Balon Percakapan Dinamis',
    description: 'Rasio 1.44:1 dengan ekor melengkung organik',
  },
  action_callout_badge: {
    width: 480,
    height: 480,
    orientation: 'square',
    label: 'Balon Seruan 12-Point',
    description: 'Rasio 1:1 seruan aksi geometris promo e-commerce',
  },

  // --- 3. POSTCARD & KARTU FOTO ---
  blank_classic_postcard: {
    width: 600,
    height: 400,
    orientation: 'horizontal',
    label: 'Kartu Pos Klasik 3:2',
    description: 'Rasio 1.5:1 standar pos internasional dengan garis bagi & prangko',
  },
  vertical_art_postcard: {
    width: 420,
    height: 600,
    orientation: 'vertical',
    label: 'Postcard Vertikal Galeri',
    description: 'Rasio 1:1.43 untuk foto cetak dan kartu pos seni',
  },
  airmail_clean_postcard: {
    width: 600,
    height: 400,
    orientation: 'horizontal',
    label: 'Postcard Pos Udara Airmail',
    description: 'Rasio 1.5:1 klasik airmail dengan cap pos',
  },
  vintage_grid_postcard: {
    width: 600,
    height: 400,
    orientation: 'horizontal',
    label: 'Kartu Pos Garis Alamat',
    description: 'Rasio 1.5:1 dilengkapi 4 baris panduan alamat vintage',
  },
  square_mini_postcard: {
    width: 480,
    height: 480,
    orientation: 'square',
    label: 'Kartu Foto Persegi 1:1',
    description: 'Rasio 1:1 kontemporer gaya instagram print',
  },

  // --- 4. KARTU UCAPAN & UNDANGAN ---
  folded_greeting_card: {
    width: 640,
    height: 440,
    orientation: 'horizontal',
    label: 'Kartu Lipat Bifold 3D',
    description: 'Rasio 1.45:1 kartu ucapan lipat dengan bayangan lipatan tulang',
  },
  vertical_arch_greeting: {
    width: 440,
    height: 620,
    orientation: 'vertical',
    label: 'Undangan Kubah Arch Mewah',
    description: 'Rasio 1:1.41 bentuk kubah favorit undangan pernikahan',
  },
  pocket_gift_card: {
    width: 500,
    height: 520,
    orientation: 'vertical',
    label: 'Kartu Saku Amplop Pouch',
    description: 'Rasio 1:1.04 kartu voucher terselip di saku amplop',
  },
  deckle_edge_greeting: {
    width: 580,
    height: 420,
    orientation: 'horizontal',
    label: 'Kartu Kertas Katun Deckle',
    description: 'Rasio 1.38:1 serat pinggiran sobek alami handmade paper',
  },
  ribbon_tied_card: {
    width: 580,
    height: 400,
    orientation: 'horizontal',
    label: 'Kartu Aksen Celah Pita',
    description: 'Rasio 1.45:1 dilengkapi slot celah untuk pita sutra',
  },
  double_border_invitation: {
    width: 580,
    height: 420,
    orientation: 'horizontal',
    label: 'Undangan Garis Lis Ganda',
    description: 'Rasio 1.38:1 formal elegan gala stationery',
  },

  // --- 5. TAPE LAKBAN & WASHI ---
  straight_washi_tape: {
    width: 600,
    height: 120,
    orientation: 'horizontal',
    label: 'Lakban Washi Lurus',
    description: 'Rasio memanjang 5:1 strip selotip jepang semi-transparan',
  },
  torn_masking_tape: {
    width: 580,
    height: 130,
    orientation: 'horizontal',
    label: 'Lakban Masking Ujung Sobek',
    description: 'Rasio 4.4:1 isolasi kertas dengan serat robek bergerigi',
  },
  diagonal_tape_strip: {
    width: 540,
    height: 130,
    orientation: 'horizontal',
    label: 'Lakban Sudut Miring',
    description: 'Rasio 4.1:1 potongan isolasi sudut diagonal',
  },
  wide_kraft_packing_tape: {
    width: 620,
    height: 160,
    orientation: 'horizontal',
    label: 'Lakban Cokelat Kraft Lebar',
    description: 'Rasio 3.8:1 lakban paket kardus tebal realistis',
  },
  scotch_transparent_tape: {
    width: 560,
    height: 110,
    orientation: 'horizontal',
    label: 'Selotip Kaca Bening',
    description: 'Rasio 5:1 plastik cellophane mengkilap transparan',
  },
  cross_tape_cluster: {
    width: 440,
    height: 440,
    orientation: 'square',
    label: 'Lakban Silang X Minimalis',
    description: 'Rasio 1:1 dua selotip silang pengait foto memo',
  },
  perforated_stamp_tape: {
    width: 580,
    height: 140,
    orientation: 'horizontal',
    label: 'Lakban Tiket Perforasi',
    description: 'Rasio 4.1:1 kupon washi bergerigi lubang perforasi',
  },

  // --- 6. TAG & AKSESORIS KRAFT ---
  blank_luggage_tag: {
    width: 360,
    height: 580,
    orientation: 'vertical',
    label: 'Tag Koper Kraft Gantung',
    description: 'Rasio 1:1.61 tag travel dengan lubang mata ayam kuningan',
  },
  archival_bookmark: {
    width: 280,
    height: 640,
    orientation: 'vertical',
    label: 'Pembatas Buku Ramping',
    description: 'Rasio tinggi 1:2.28 bookmark buku elegan',
  },
  hexagonal_price_tag: {
    width: 560,
    height: 280,
    orientation: 'horizontal',
    label: 'Tag Harga Butik Geometris',
    description: 'Rasio 2:1 label harga retail dengan lubang gantung',
  },
  ceramic_art_tile: {
    width: 480,
    height: 480,
    orientation: 'square',
    label: 'Ubin Keramik Estetik',
    description: 'Rasio 1:1 tembikar wabi-sabi tekstur sudut lembut',
  },
};

/**
 * Mengambil informasi dimensi ideal untuk tipe bentuk tertentu
 */
export function getIdealDimensionsForShape(shapeType: ShapeType | string): ShapeDimensionInfo {
  return (SHAPE_IDEAL_DIMENSIONS as Record<string, ShapeDimensionInfo>)[shapeType] || {
    width: 540,
    height: 380,
    orientation: 'horizontal',
    label: 'Wadah Teks Standar',
    description: 'Dimensi proporsional serbaguna',
  };
}

/**
 * Menyesuaikan ShapeState secara cerdas saat pengguna memilih bentuk baru.
 */
export function adaptStateToShape(currentState: ShapeState, newShapeType: ShapeType | string): ShapeState {
  const ideal = getIdealDimensionsForShape(newShapeType);

  let newBorderWidth = currentState.borderWidth;
  if (newBorderWidth > 0) {
    if (newShapeType.includes('tape')) {
      newBorderWidth = 0; // Tapes look best without borders
    } else {
      newBorderWidth = Math.min(newBorderWidth, 3);
    }
  }

  return {
    ...currentState,
    shapeType: newShapeType,
    width: ideal.width,
    height: ideal.height,
    borderWidth: newBorderWidth,
  };
}

/**
 * Menghitung dimensi artboard aman dan padding pelindung
 */
export function calculateSafeArtboardDimensions(
  state: ShapeState,
  options?: { marginPercent?: number; minPadding?: number }
): { width: number; height: number; paddingX: number; paddingY: number } {
  const marginPercent = options?.marginPercent !== undefined ? options.marginPercent : 15;
  const minPad = options?.minPadding !== undefined ? options.minPadding : 40;

  const w = state.width;
  const h = state.height;

  // Rotasi bounding box
  const rotDeg = Math.abs(state.objectRotation || 0);
  const rotRad = (rotDeg * Math.PI) / 180;
  const rotatedW = w * Math.cos(rotRad) + h * Math.sin(rotRad);
  const rotatedH = w * Math.sin(rotRad) + h * Math.cos(rotRad);
  const rotExtraW = Math.max(0, rotatedW - w);
  const rotExtraH = Math.max(0, rotatedH - h);

  // Bayangan & Glow
  const shadowDist = state.shadowDistance !== undefined ? state.shadowDistance : 20;
  const shadowBlur = state.shadowBlur !== undefined ? state.shadowBlur : 20;
  const shadowOpacity = state.shadowOpacity !== undefined ? state.shadowOpacity : 15;
  const glow = state.glowIntensity || 0;
  const hasShadow = shadowOpacity > 0 && (shadowDist > 0 || shadowBlur > 0);
  const shadowSpread = hasShadow 
    ? (shadowDist + shadowBlur + (glow > 0 ? 30 : 15)) 
    : (glow > 0 ? 30 : 0);

  // Aksesoris
  let decorExtraTop = 0;
  let decorExtraSides = 0;
  const decorY = state.decorationY || 0;
  const decorX = state.decorationX || 0;

  if (state.decorationType === 'clip') {
    decorExtraTop = Math.max(decorExtraTop, 50 + Math.abs(decorY));
    decorExtraSides = Math.max(decorExtraSides, 25 + Math.abs(decorX));
  } else if (state.decorationType === 'pin') {
    decorExtraTop = Math.max(decorExtraTop, 45 + Math.abs(decorY));
    decorExtraSides = Math.max(decorExtraSides, 25 + Math.abs(decorX));
  } else if (state.decorationType === 'tape') {
    decorExtraTop = Math.max(decorExtraTop, 35 + Math.abs(decorY));
    decorExtraSides = Math.max(decorExtraSides, 20 + Math.abs(decorX));
  } else if (state.decorationType === 'staple') {
    decorExtraTop = Math.max(decorExtraTop, 25 + Math.abs(decorY));
  }

  const baseMarginW = Math.round(w * (marginPercent / 100));
  const baseMarginH = Math.round(h * (marginPercent / 100));

  const padX = Math.max(
    minPad,
    Math.round(baseMarginW / 2) + Math.round(rotExtraW / 2) + Math.round(shadowSpread / 2) + decorExtraSides
  );

  const padY = Math.max(
    minPad,
    Math.round(baseMarginH / 2) + Math.round(rotExtraH / 2) + Math.round(shadowSpread / 2) + decorExtraTop
  );

  return {
    width: Math.round(w + padX * 2),
    height: Math.round(h + padY * 2),
    paddingX: padX,
    paddingY: padY,
  };
}
