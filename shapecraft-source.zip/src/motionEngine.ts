import { MotionPreset, ChromaBg, VideoDuration, VideoResolution, MotionTransform, StockMetadata, BounceIntensity, IdleMotionStyle } from './types';

// Easing math helpers for smooth Adobe Stock motion graphics
function easeOutBack(x: number, c1 = 1.70158): number {
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
}

function easeInBack(x: number, c1 = 1.70158): number {
  const c3 = c1 + 1;
  return c3 * x * x * x - c1 * x * x;
}

function easeOutCubic(x: number): number {
  return 1 - Math.pow(1 - x, 3);
}

function easeInCubic(x: number): number {
  return x * x * x;
}

function easeInOutSine(x: number): number {
  return -(Math.cos(Math.PI * x) - 1) / 2;
}

function clamp(val: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, val));
}

/**
 * Calculates current phase in the 6-7s stock video timeline:
 * - IN: 0 -> inDuration (e.g. 0 to 1.3s)
 * - HOLD: inDuration -> duration - outDuration (e.g. 1.3 to 5.7s) - Safe Copy Space
 * - OUT: duration - outDuration -> duration (e.g. 5.7 to 7.0s)
 */
export function getTimelinePhase(currentTime: number, duration: number): 'in' | 'hold' | 'out' {
  const inDuration = duration >= 7 ? 1.4 : 1.2;
  const outDuration = duration >= 7 ? 1.3 : 1.1;
  if (currentTime < inDuration) return 'in';
  if (currentTime > duration - outDuration) return 'out';
  return 'hold';
}

/**
 * Computes deterministic transform matrix for any frame
 */
export function computeMotionTransform(
  currentTime: number,
  duration: number,
  preset: MotionPreset,
  shapeType: string,
  options?: {
    bounceIntensity?: BounceIntensity;
    idleStyle?: IdleMotionStyle;
  }
): MotionTransform {
  const t = clamp(currentTime, 0, duration);
  const inDur = duration >= 7 ? 1.4 : 1.2;
  const outDur = duration >= 7 ? 1.3 : 1.1;
  const holdStart = inDur;
  const holdEnd = duration - outDur;

  const bounceSetting = options?.bounceIntensity || 'snappy';
  const idleSetting = options?.idleStyle || 'breathing';

  const bounceMult = bounceSetting === 'soft' ? 0.75 : bounceSetting === 'ultra_bouncy' ? 1.4 : 1.0;

  // Determine origin based on shape type
  let originX = '50%';
  let originY = '50%';

  if (shapeType.includes('speech_bubble') || shapeType.includes('chat_pill')) {
    originX = '25%';
    originY = '95%';
  } else if (shapeType.includes('luggage_tag') || shapeType.includes('bookmark') || shapeType.includes('price_tag')) {
    originX = '50%';
    originY = '8%';
  } else if (shapeType.includes('folded_greeting') || shapeType.includes('deckle_edge')) {
    originX = '10%';
    originY = '50%';
  }

  // Base default
  let scale = 1;
  let scaleX = 1;
  let scaleY = 1;
  let translateX = 0;
  let translateY = 0;
  let rotate = 0;
  let rotateX = 0;
  let rotateY = 0;
  let opacity = 1;

  switch (preset) {
    case 'elastic_pop': {
      if (t < holdStart) {
        const progress = t / holdStart;
        const c1 = 1.4 * bounceMult;
        const eased = easeOutBack(progress, c1);
        scale = Math.max(0, eased);
        opacity = clamp(progress * 1.8, 0, 1);
        translateY = (1 - easeOutCubic(progress)) * 40;
      } else if (t <= holdEnd) {
        const holdProgress = (t - holdStart) / (holdEnd - holdStart);
        if (idleSetting === 'breathing') {
          scale = 1 + Math.sin(holdProgress * Math.PI * 2) * 0.015;
          translateY = Math.sin(holdProgress * Math.PI * 2) * 3;
        } else if (idleSetting === 'float') {
          translateY = Math.sin(holdProgress * Math.PI * 2) * 8;
          rotate = Math.cos(holdProgress * Math.PI * 2) * 0.8;
        } else if (idleSetting === 'sway') {
          rotate = Math.sin(holdProgress * Math.PI * 2) * 2;
        }
        opacity = 1;
      } else {
        const outProgress = (t - holdEnd) / outDur;
        scale = Math.max(0, 1 - easeInBack(outProgress, 1.3 * bounceMult));
        opacity = 1 - easeInCubic(outProgress);
        translateY = easeInCubic(outProgress) * 30;
      }
      break;
    }

    case 'paper_reveal': {
      if (t < holdStart) {
        const progress = t / holdStart;
        const eased = easeOutCubic(progress);
        translateX = (1 - eased) * -120;
        rotate = (1 - eased) * -6;
        scale = 0.9 + eased * 0.1;
        opacity = clamp(progress * 1.8, 0, 1);
      } else if (t <= holdEnd) {
        const holdProgress = (t - holdStart) / (holdEnd - holdStart);
        translateY = Math.sin(holdProgress * Math.PI * 2) * 3;
        rotate = Math.cos(holdProgress * Math.PI * 2) * 0.4;
      } else {
        const outProgress = (t - holdEnd) / outDur;
        translateX = easeInCubic(outProgress) * 140;
        rotate = easeInCubic(outProgress) * 6;
        opacity = 1 - easeInCubic(outProgress);
      }
      break;
    }

    case 'torn_paper_text': {
      if (t < holdStart) {
        const progress = t / holdStart;
        const eased = easeOutBack(progress, 1.2 * bounceMult);
        scale = Math.max(0, eased);
        rotate = (1 - progress) * -4;
        opacity = clamp(progress * 2, 0, 1);
      } else if (t <= holdEnd) {
        const holdProgress = (t - holdStart) / (holdEnd - holdStart);
        scale = 1 + Math.sin(holdProgress * Math.PI * 2) * 0.008;
      } else {
        const outProgress = (t - holdEnd) / outDur;
        scale = Math.max(0, 1 - easeInBack(outProgress, 1.3));
        opacity = 1 - easeInCubic(outProgress);
      }
      break;
    }

    case 'sticky_note_seq': {
      if (t < holdStart) {
        const progress = t / holdStart;
        const eased = easeOutBack(progress, 1.5 * bounceMult);
        translateY = (1 - easeOutCubic(progress)) * -140;
        rotate = (1 - easeOutCubic(progress)) * -12 + 3;
        scale = Math.max(0, eased);
        opacity = clamp(progress * 2, 0, 1);
      } else if (t <= holdEnd) {
        const holdProgress = (t - holdStart) / (holdEnd - holdStart);
        rotate = 3 + Math.sin(holdProgress * Math.PI * 2) * 0.8;
      } else {
        const outProgress = (t - holdEnd) / outDur;
        translateY = easeInCubic(outProgress) * 160;
        rotate = 3 + outProgress * 10;
        opacity = 1 - easeInCubic(outProgress);
      }
      break;
    }

    case 'tape_and_paper': {
      if (t < holdStart) {
        const progress = t / holdStart;
        if (progress < 0.6) {
          const p1 = progress / 0.6;
          translateY = (1 - p1 * p1) * -180;
          rotate = (1 - p1) * -8;
          opacity = clamp(p1 * 2, 0, 1);
        } else {
          const impact = (progress - 0.6) / 0.4;
          const bounce = Math.sin(impact * Math.PI * 3) * Math.exp(-impact * 3);
          translateY = bounce * 8;
          rotate = bounce * 2;
          opacity = 1;
        }
      } else if (t <= holdEnd) {
        opacity = 1;
      } else {
        const outProgress = (t - holdEnd) / outDur;
        translateY = -easeInCubic(outProgress) * 160;
        rotate = easeInCubic(outProgress) * 8;
        opacity = 1 - easeInCubic(outProgress);
      }
      break;
    }

    case 'layered_scrapbook':
    case 'paper_stack_titles':
    case 'handwritten_paper':
    case 'paper_window_mask':
    case 'floating_paper_labels': {
      if (t < holdStart) {
        const progress = t / holdStart;
        const eased = easeOutBack(progress, 1.2 * bounceMult);
        scale = Math.max(0, eased);
        opacity = clamp(progress * 1.8, 0, 1);
      } else if (t <= holdEnd) {
        const holdProgress = (t - holdStart) / (holdEnd - holdStart);
        if (idleSetting === 'breathing') {
          scale = 1 + Math.sin(holdProgress * Math.PI * 2) * 0.01;
        } else if (idleSetting === 'float') {
          translateY = Math.sin(holdProgress * Math.PI * 2) * 4;
        }
      } else {
        const outProgress = (t - holdEnd) / outDur;
        scale = Math.max(0, 1 - easeInBack(outProgress, 1.2));
        opacity = 1 - easeInCubic(outProgress);
      }
      break;
    }

    case 'smooth_slide': {
      if (t < holdStart) {
        const progress = t / holdStart;
        const eased = easeOutCubic(progress);
        translateX = (1 - eased) * -120;
        opacity = clamp(progress * 1.5, 0, 1);
        scale = 0.94 + eased * 0.06;
      } else if (t <= holdEnd) {
        const holdProgress = (t - holdStart) / (holdEnd - holdStart);
        translateX = Math.sin(holdProgress * Math.PI) * 4;
        opacity = 1;
        scale = 1;
      } else {
        const outProgress = (t - holdEnd) / outDur;
        const eased = easeInCubic(outProgress);
        translateX = eased * 140;
        opacity = 1 - eased;
        scale = 1 - eased * 0.06;
      }
      break;
    }

    case 'subtle_float': {
      const loopT = (t / duration) * Math.PI * 2;
      translateY = Math.sin(loopT * 2) * 12;
      translateX = Math.cos(loopT) * 6;
      rotate = Math.sin(loopT * 1.5) * 1.8;
      scale = 1 + Math.sin(loopT * 3) * 0.02;
      opacity = 1;
      break;
    }

    default: {
      // Morph presets (paper_crumple_unfold, shatter_assemble, speed_wind_comic_morph, wedding_ribbon_floral_unfurl)
      // are rendered via custom high-fidelity Canvas Morph Engine
      scale = 1;
      opacity = 1;
      break;
    }
  }

  return {
    scale,
    scaleX,
    scaleY,
    translateX,
    translateY,
    rotate,
    rotateX,
    rotateY,
    opacity,
    originX,
    originY,
  };
}

/**
 * Returns RGB hex/rgba color for selected Chroma Background
 */
export function getChromaBackgroundColor(chroma: ChromaBg): string {
  switch (chroma) {
    case 'green_screen':
      return '#00ff00'; // Pure Chroma Green RGB(0, 255, 0)
    case 'blue_screen':
      return '#0000ff'; // Pure Chroma Blue RGB(0, 0, 255)
    case 'pure_black':
      return '#000000';
    case 'pure_white':
      return '#ffffff';
    case 'checkerboard':
    case 'transparent':
      return 'transparent';
  }
}

/**
 * Generates Adobe Stock commercial title, tags, and description
 */
export function generateStockMetadata(
  shapeLabel: string,
  category: string,
  chroma: ChromaBg,
  preset: MotionPreset,
  duration: number,
  resolution: VideoResolution = '4k',
  fps: number = 60
): StockMetadata {
  const bgName: Record<ChromaBg, string> = {
    green_screen: 'green screen',
    blue_screen: 'blue screen',
    pure_black: 'black background',
    pure_white: 'white background',
    checkerboard: 'transparent preview',
    transparent: 'transparent background'
  };
  const resolutionLabel: Record<VideoResolution, string> = {
    '4k': '4K UHD',
    '1080p': 'HD',
    'reels_9_16': 'vertical 1080 by 1920',
    'square_1_1': 'square 1080 by 1080'
  };
  const motionName = preset === 'paper_reveal'
    ? 'Paper Reveal Slide & Unfold Minimalist Title Container'
    : preset === 'torn_paper_text'
    ? 'Torn Paper Deckle Edge Editorial Text Box'
    : preset === 'sticky_note_seq'
    ? 'Sticky Note Collection Tips & Checklist Annotation'
    : preset === 'tape_and_paper'
    ? 'Tape and Paper Masking Washi Overlay'
    : preset === 'layered_scrapbook'
    ? 'Layered Digital Scrapbook Frame and Paper Title'
    : preset === 'paper_stack_titles'
    ? 'Paper Stack Multi-Layer Title and Subtitle'
    : preset === 'handwritten_paper'
    ? 'Handwritten Pencil Underline Paper Title'
    : preset === 'paper_window_mask'
    ? 'Paper Window Center Mask Title Transition'
    : preset === 'floating_paper_labels'
    ? 'Floating Paper Minimalist Label Annotation'
    : preset === 'paper_crumple_unfold'
    ? '3D Crumpled Paper Unfolding & Flattening'
    : preset === 'shatter_assemble'
    ? 'Voronoi Shatter Reassembly Snap'
    : preset === 'speed_wind_comic_morph'
    ? 'Anime Comic Speed Lines & Sonic Wind Slash Action Morph'
    : preset === 'wedding_ribbon_floral_unfurl'
    ? 'Luxury Wedding Digital Invitation Ribbon Untying & Gold Floral Unfurl'
    : 'Minimal Paper Text Container';

  const title = `Animated ${shapeLabel} ${motionName} on ${bgName[chroma]} with copy space`;

  const baseKeywords = [
    shapeLabel.toLowerCase(),
    motionName.toLowerCase(),
    bgName[chroma],
    'copy space',
    'motion graphics',
    'animated frame',
    'isolated',
    resolutionLabel[resolution].toLowerCase(),
    `${fps} fps`,
    'placeholder',
    'text placeholder',
    'video editing asset',
    'motion design'
  ];

  // Specific keywords based on category
  const categoryKeywords: Record<string, string[]> = {
    text_container: ['memo card', 'card frame', 'quote container', 'editorial box', 'blank pill badge', 'badge vector'],
    comment: ['speech bubble', 'chat pill', 'thought cloud', 'review card', 'testimonial box', 'messenger bubble'],
    postcard: ['classic postcard', 'airmail card', 'photo frame', 'vintage card', 'stationery mail', 'envelope card'],
    greeting_card: ['greeting card', 'bifold invitation', 'arch wedding', 'gift voucher', 'folded paper', 'cotton card'],
    tape: ['washi tape', 'masking tape', 'kraft packing tape', 'scotch tape', 'tape strip', 'scrapbook tape'],
    tag_bookmark: ['luggage tag', 'price tag', 'bookmark', 'hanging tag', 'gift tag', 'boutique label']
  };

  const specific = categoryKeywords[category] || [];
  const mergedKeywords = Array.from(new Set([...baseKeywords, ...specific, shapeLabel.toLowerCase()]));

  const description = `${duration}-second ${resolutionLabel[resolution]} ${fps} fps motion graphic of a blank ${shapeLabel} on ${bgName[chroma]}. It has an entrance, editable copy space during the hold, and an exit animation for video-editing workflows.`;

  return {
    title,
    category: 'Video / Motion Graphics',
    keywords: mergedKeywords,
    description
  };
}
