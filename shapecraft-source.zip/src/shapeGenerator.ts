import { ShapeState, PresetTemplate, TextureType, FillType } from './types';
import { ShapeDefinition } from './shapeDefinitions';
import { ShapeDimensionInfo } from './shapeDimensions';

export interface GeneratedShapeMeta {
  archetype: 
    | 'notched_ticket_stub'
    | 'gothic_stepped_arch'
    | 'perforated_stamp_seal'
    | 'wave_scallop_cartouche'
    | 'asymmetric_brutalist_tag'
    | 'swallowtail_ribbon_banner'
    | 'organic_pebble_wabisabi'
    | 'dynamic_tail_speech_bubble'
    | 'slitted_bookmark_sleeve'
    | 'torn_deckle_washi_strip';
  seed: number;
  params: Record<string, any>;
  idealWidth: number;
  idealHeight: number;
  orientation: 'horizontal' | 'vertical' | 'square';
}

export interface GeneratedPackItem {
  definition: ShapeDefinition;
  dimension: ShapeDimensionInfo;
  meta: GeneratedShapeMeta;
  preset: PresetTemplate;
}

const STORAGE_KEY = 'SHAPECRAFT_GENERATED_V1';

// Pseudo-random deterministic float between min and max based on seed
function seededRandom(seed: number): number {
  const x = Math.sin(seed * 9999) * 10000;
  return x - Math.floor(x);
}

function randomInRange(seed: number, min: number, max: number): number {
  return min + seededRandom(seed) * (max - min);
}

// ============================================================================
// 1. PROCEDURAL VECTOR PATH ALGORITHMS FOR 10 DISTINCT ARCHETYPES
// ============================================================================

/** Archetype 1: Notched Ticket Stub (Kupon / Tiket dengan takik potong punch & perforasi) */
export function generateTicketStubPath(w: number, h: number, seed: number, params: any = {}): string {
  const notchR = Math.round(randomInRange(seed, 14, 26));
  const cornerR = Math.round(randomInRange(seed + 1, 4, 12));
  const notchType = params.notchType || (seed % 3 === 0 ? 'top-bottom' : seed % 3 === 1 ? 'left-right' : 'four-sides');

  if (notchType === 'left-right') {
    const midY = h / 2;
    return `
      M ${cornerR} 0
      L ${w - cornerR} 0
      Q ${w} 0 ${w} ${cornerR}
      L ${w} ${midY - notchR}
      A ${notchR} ${notchR} 0 0 0 ${w} ${midY + notchR}
      L ${w} ${h - cornerR}
      Q ${w} ${h} ${w - cornerR} ${h}
      L ${cornerR} ${h}
      Q 0 ${h} 0 ${h - cornerR}
      L 0 ${midY + notchR}
      A ${notchR} ${notchR} 0 0 0 0 ${midY - notchR}
      L 0 ${cornerR}
      Q 0 0 ${cornerR} 0
      Z
    `.replace(/\s+/g, ' ').trim();
  } else if (notchType === 'top-bottom') {
    const notchX = Math.round(w * 0.32);
    return `
      M ${cornerR} 0
      L ${notchX - notchR} 0
      A ${notchR} ${notchR} 0 0 0 ${notchX + notchR} 0
      L ${w - cornerR} 0
      Q ${w} 0 ${w} ${cornerR}
      L ${w} ${h - cornerR}
      Q ${w} ${h} ${w - cornerR} ${h}
      L ${notchX + notchR} ${h}
      A ${notchR} ${notchR} 0 0 0 ${notchX - notchR} ${h}
      L ${cornerR} ${h}
      Q 0 ${h} 0 ${h - cornerR}
      L 0 ${cornerR}
      Q 0 0 ${cornerR} 0
      Z
    `.replace(/\s+/g, ' ').trim();
  } else {
    // 4 Corner notched ticket stub
    const bite = Math.round(notchR * 1.1);
    return `
      M ${bite} 0
      L ${w - bite} 0
      A ${bite} ${bite} 0 0 0 ${w} ${bite}
      L ${w} ${h - bite}
      A ${bite} ${bite} 0 0 0 ${w - bite} ${h}
      L ${bite} ${h}
      A ${bite} ${bite} 0 0 0 0 ${h - bite}
      L 0 ${bite}
      A ${bite} ${bite} 0 0 0 ${bite} 0
      Z
    `.replace(/\s+/g, ' ').trim();
  }
}

/** Archetype 2: Gothic / Stepped Arch (Kubah arsitektural bertingkat elegan) */
export function generateGothicArchPath(w: number, h: number, seed: number, params: any = {}): string {
  const archStyle = params.archStyle || (seed % 2 === 0 ? 'pointed_gothic' : 'stepped_pediment');
  const stepW = Math.round(randomInRange(seed + 1, 14, 24));
  const stepH = Math.round(randomInRange(seed + 2, 10, 18));
  const cornerR = 8;

  if (archStyle === 'pointed_gothic') {
    // Elegant lancet/pointed cathedral arch
    const springY = Math.round(h * 0.42);
    return `
      M ${cornerR} ${h}
      L 0 ${h - cornerR}
      L 0 ${springY}
      Q 0 ${springY * 0.4} ${w / 2} 0
      Q ${w} ${springY * 0.4} ${w} ${springY}
      L ${w} ${h - cornerR}
      L ${w - cornerR} ${h}
      Z
    `.replace(/\s+/g, ' ').trim();
  } else {
    // Stepped bottom pediment + semicircular top arch
    const archH = w / 2;
    return `
      M 0 ${archH}
      A ${w / 2} ${archH} 0 0 1 ${w} ${archH}
      L ${w} ${h - stepH}
      L ${w - stepW} ${h - stepH}
      L ${w - stepW} ${h}
      L ${stepW} ${h}
      L ${stepW} ${h - stepH}
      L 0 ${h - stepH}
      Z
    `.replace(/\s+/g, ' ').trim();
  }
}

/** Archetype 3: Perforated Stamp Seal (Stempel prangko bergerigi rapat dengan lengkung presisi) */
export function generatePerforatedStampPath(w: number, h: number, seed: number): string {
  const toothPitch = Math.round(randomInRange(seed, 16, 24));
  const toothR = Math.round(randomInRange(seed + 1, 3.5, 5.5));
  
  const countX = Math.max(6, Math.floor((w - 24) / toothPitch));
  const stepX = (w - 24) / countX;
  const countY = Math.max(4, Math.floor((h - 24) / toothPitch));
  const stepY = (h - 24) / countY;

  let d = `M 12 0 `;

  // Top edge
  for (let i = 0; i < countX; i++) {
    const curX = 12 + i * stepX;
    const midX = curX + stepX / 2;
    d += `L ${midX - toothR} 0 A ${toothR} ${toothR} 0 0 0 ${midX + toothR} 0 `;
  }
  d += `L ${w - 12} 0 Q ${w} 0 ${w} 12 `;

  // Right edge
  for (let i = 0; i < countY; i++) {
    const curY = 12 + i * stepY;
    const midY = curY + stepY / 2;
    d += `L ${w} ${midY - toothR} A ${toothR} ${toothR} 0 0 0 ${w} ${midY + toothR} `;
  }
  d += `L ${w} ${h - 12} Q ${w} ${h} ${w - 12} ${h} `;

  // Bottom edge
  for (let i = countX - 1; i >= 0; i--) {
    const curX = 12 + i * stepX;
    const midX = curX + stepX / 2;
    d += `L ${midX + toothR} ${h} A ${toothR} ${toothR} 0 0 0 ${midX - toothR} ${h} `;
  }
  d += `L 12 ${h} Q 0 ${h} 0 ${h - 12} `;

  // Left edge
  for (let i = countY - 1; i >= 0; i--) {
    const curY = 12 + i * stepY;
    const midY = curY + stepY / 2;
    d += `L 0 ${midY + toothR} A ${toothR} ${toothR} 0 0 0 0 ${midY - toothR} `;
  }
  d += `L 0 12 Q 0 0 12 0 Z`;

  return d.replace(/\s+/g, ' ').trim();
}

/** Archetype 4: Wave Scallop Cartouche (Plakat kartus gelombang renda mewah) */
export function generateWaveScallopPath(w: number, h: number, seed: number): string {
  const wavesX = Math.round(randomInRange(seed, 6, 10));
  const amp = Math.round(randomInRange(seed + 1, 6, 11));
  const insetCorner = Math.round(randomInRange(seed + 2, 20, 32));

  const stepX = (w - insetCorner * 2) / wavesX;

  let d = `M ${insetCorner} 0 `;
  // Top waves
  for (let i = 0; i < wavesX; i++) {
    const x0 = insetCorner + i * stepX;
    const x1 = x0 + stepX;
    d += `Q ${x0 + stepX / 2} ${-amp} ${x1} 0 `;
  }
  // Top-right bracket corner
  d += `Q ${w} 0 ${w} ${insetCorner} `;
  
  // Right side
  d += `L ${w} ${h - insetCorner} `;
  // Bottom-right bracket corner
  d += `Q ${w} ${h} ${w - insetCorner} ${h} `;
  
  // Bottom waves
  for (let i = wavesX - 1; i >= 0; i--) {
    const x0 = insetCorner + i * stepX;
    const x1 = x0 + stepX;
    d += `Q ${x0 + stepX / 2} ${h + amp} ${x0} ${h} `;
  }
  // Bottom-left bracket corner
  d += `Q 0 ${h} 0 ${h - insetCorner} `;
  
  // Left side
  d += `L 0 ${insetCorner} `;
  // Top-left bracket corner
  d += `Q 0 0 ${insetCorner} 0 Z`;

  return d.replace(/\s+/g, ' ').trim();
}

/** Archetype 5: Asymmetric Brutalist Tag (Label modern dengan sudut miring bevel kontras) */
export function generateAsymmetricBrutalistPath(w: number, h: number, seed: number): string {
  const cutTR = Math.round(randomInRange(seed, 35, 65));
  const cutBL = Math.round(randomInRange(seed + 1, 20, 45));
  const cornerR = Math.round(randomInRange(seed + 2, 4, 12));

  return `
    M ${cornerR} 0
    L ${w - cutTR} 0
    L ${w} ${cutTR}
    L ${w} ${h - cornerR}
    Q ${w} ${h} ${w - cornerR} ${h}
    L ${cutBL} ${h}
    L 0 ${h - cutBL}
    L 0 ${cornerR}
    Q 0 0 ${cornerR} 0
    Z
  `.replace(/\s+/g, ' ').trim();
}

/** Archetype 6: Swallowtail Ribbon Banner (Pita vintage dengan takik V & lipatan ekor) */
export function generateSwallowtailRibbonPath(w: number, h: number, seed: number): string {
  const tailV = Math.round(randomInRange(seed, 28, 48));
  const curvature = Math.round(randomInRange(seed + 1, -12, 12));
  const midY = h / 2;

  return `
    M ${tailV} ${curvature > 0 ? curvature : 0}
    Q ${w / 2} ${curvature} ${w - tailV} ${curvature > 0 ? curvature : 0}
    L ${w} ${midY}
    L ${w - tailV} ${h}
    Q ${w / 2} ${h + curvature} ${tailV} ${h}
    L 0 ${midY}
    Z
  `.replace(/\s+/g, ' ').trim();
}

/** Archetype 7: Organic Pebble Wabi-Sabi (Batu organik estetika Japandi / Skincare) */
export function generateOrganicPebblePath(w: number, h: number, seed: number): string {
  const cx = w / 2;
  const cy = h / 2;
  const rx = w / 2 - 8;
  const ry = h / 2 - 8;

  // 6 control points perturbed organically
  const p1x = cx + rx * (0.85 + seededRandom(seed) * 0.25);
  const p1y = cy * (0.45 + seededRandom(seed + 1) * 0.3);

  const p2x = cx + rx * (0.75 + seededRandom(seed + 2) * 0.25);
  const p2y = cy + ry * (0.75 + seededRandom(seed + 3) * 0.25);

  const p3x = cx * (0.9 + seededRandom(seed + 4) * 0.2);
  const p3y = cy + ry * (0.85 + seededRandom(seed + 5) * 0.25);

  const p4x = cx - rx * (0.85 + seededRandom(seed + 6) * 0.25);
  const p4y = cy + ry * (0.65 + seededRandom(seed + 7) * 0.25);

  const p5x = cx - rx * (0.8 + seededRandom(seed + 8) * 0.25);
  const p5y = cy * (0.5 + seededRandom(seed + 9) * 0.3);

  const p6x = cx * (0.85 + seededRandom(seed + 10) * 0.3);
  const p6y = cy - ry * (0.8 + seededRandom(seed + 11) * 0.25);

  return `
    M ${p6x} ${p6y}
    C ${w * 0.8} 0 ${p1x} ${p1y * 0.6} ${p1x} ${p1y}
    C ${p1x} ${h * 0.7} ${w * 0.9} ${p2y} ${p2x} ${p2y}
    C ${w * 0.6} ${h} ${p3x * 1.2} ${h} ${p3x} ${p3y}
    C ${w * 0.25} ${h} ${p4x} ${p4y * 1.1} ${p4x} ${p4y}
    C ${p4x} ${h * 0.4} ${0} ${p5y * 0.8} ${p5x} ${p5y}
    C ${p5x} ${cy * 0.2} ${w * 0.3} ${0} ${p6x} ${p6y}
    Z
  `.replace(/\s+/g, ' ').trim();
}

/** Archetype 8: Dynamic Tail Speech Bubble (Balon percakapan modern dengan ekor variatif) */
export function generateDynamicTailSpeechPath(w: number, h: number, seed: number): string {
  const tailSide = seed % 3 === 0 ? 'bottom-left' : seed % 3 === 1 ? 'bottom-right' : 'left-middle';
  const r = Math.round(randomInRange(seed + 1, 22, 38));

  if (tailSide === 'bottom-left') {
    const tailStart = Math.round(w * 0.18);
    const tailW = Math.round(randomInRange(seed + 2, 28, 42));
    const tailH = Math.round(randomInRange(seed + 3, 22, 34));
    return `
      M ${r} 0
      L ${w - r} 0
      Q ${w} 0 ${w} ${r}
      L ${w} ${h - tailH - r}
      Q ${w} ${h - tailH} ${w - r} ${h - tailH}
      L ${tailStart + tailW} ${h - tailH}
      L ${tailStart - 8} ${h}
      L ${tailStart} ${h - tailH}
      L ${r} ${h - tailH}
      Q 0 ${h - tailH} 0 ${h - tailH - r}
      L 0 ${r}
      Q 0 0 ${r} 0
      Z
    `.replace(/\s+/g, ' ').trim();
  } else if (tailSide === 'bottom-right') {
    const tailStart = Math.round(w * 0.68);
    const tailW = Math.round(randomInRange(seed + 2, 28, 42));
    const tailH = Math.round(randomInRange(seed + 3, 22, 34));
    return `
      M ${r} 0
      L ${w - r} 0
      Q ${w} 0 ${w} ${r}
      L ${w} ${h - tailH - r}
      Q ${w} ${h - tailH} ${w - r} ${h - tailH}
      L ${tailStart + tailW} ${h - tailH}
      L ${tailStart + tailW + 12} ${h}
      L ${tailStart} ${h - tailH}
      L ${r} ${h - tailH}
      Q 0 ${h - tailH} 0 ${h - tailH - r}
      L 0 ${r}
      Q 0 0 ${r} 0
      Z
    `.replace(/\s+/g, ' ').trim();
  } else {
    // Side pointing bubble
    const tailY = Math.round(h * 0.42);
    const tailH = 26;
    const tailOut = 24;
    return `
      M ${r} 0
      L ${w - r} 0
      Q ${w} 0 ${w} ${r}
      L ${w} ${h - r}
      Q ${w} ${h} ${w - r} ${h}
      L ${r + tailOut} ${h}
      Q ${tailOut} ${h} ${tailOut} ${h - r}
      L ${tailOut} ${tailY + tailH}
      L 0 ${tailY + tailH / 2}
      L ${tailOut} ${tailY}
      L ${tailOut} ${r}
      Q ${tailOut} 0 ${r + tailOut} 0
      Z
    `.replace(/\s+/g, ' ').trim();
  }
}

/** Archetype 9: Slitted Bookmark Sleeve (Pembatas buku ramping berlubang pita & celah) */
export function generateSlittedBookmarkPath(w: number, h: number, seed: number): string {
  const topCut = Math.round(randomInRange(seed, 20, 36));
  const notchV = Math.round(randomInRange(seed + 1, 24, 40));
  
  return `
    M 0 ${topCut}
    L ${w / 2} 0
    L ${w} ${topCut}
    L ${w} ${h}
    L ${w / 2} ${h - notchV}
    L 0 ${h}
    Z
  `.replace(/\s+/g, ' ').trim();
}

/** Archetype 10: Torn Deckle Washi Strip (Lakban serat robek artisanal alami) */
export function generateTornDeckleWashiPath(w: number, h: number, seed: number): string {
  const points = 12;
  const step = h / points;

  let d = `M 0 0 L ${w} 0 `;

  // Right torn edge
  for (let i = 1; i <= points; i++) {
    const y = i * step;
    const jitter = (seededRandom(seed + i * 3) - 0.5) * 14;
    d += `L ${w + jitter} ${y} `;
  }

  d += `L 0 ${h} `;

  // Left torn edge
  for (let i = points - 1; i >= 0; i--) {
    const y = i * step;
    const jitter = (seededRandom(seed + 100 + i * 3) - 0.5) * 14;
    d += `L ${jitter} ${y} `;
  }

  d += `Z`;
  return d.replace(/\s+/g, ' ').trim();
}

// Master router for generated shapes
export function getGeneratedShapePath(shapeId: string, w: number, h: number, meta?: GeneratedShapeMeta): string {
  if (!meta) {
    // Default safe fallback if metadata isn't passed directly
    return `M 16 0 L ${w - 16} 0 Q ${w} 0 ${w} 16 L ${w} ${h - 16} Q ${w} ${h} ${w - 16} ${h} L 16 ${h} Q 0 ${h} 0 ${h - 16} L 0 16 Q 0 0 16 0 Z`;
  }

  const { archetype, seed, params } = meta;

  switch (archetype) {
    case 'notched_ticket_stub':
      return generateTicketStubPath(w, h, seed, params);
    case 'gothic_stepped_arch':
      return generateGothicArchPath(w, h, seed, params);
    case 'perforated_stamp_seal':
      return generatePerforatedStampPath(w, h, seed);
    case 'wave_scallop_cartouche':
      return generateWaveScallopPath(w, h, seed);
    case 'asymmetric_brutalist_tag':
      return generateAsymmetricBrutalistPath(w, h, seed);
    case 'swallowtail_ribbon_banner':
      return generateSwallowtailRibbonPath(w, h, seed);
    case 'organic_pebble_wabisabi':
      return generateOrganicPebblePath(w, h, seed);
    case 'dynamic_tail_speech_bubble':
      return generateDynamicTailSpeechPath(w, h, seed);
    case 'slitted_bookmark_sleeve':
      return generateSlittedBookmarkPath(w, h, seed);
    case 'torn_deckle_washi_strip':
      return generateTornDeckleWashiPath(w, h, seed);
    default:
      return `M 16 0 L ${w - 16} 0 Q ${w} 0 ${w} 16 L ${w} ${h - 16} Q ${w} ${h} ${w - 16} ${h} L 16 ${h} Q 0 ${h} 0 ${h - 16} L 0 16 Q 0 0 16 0 Z`;
  }
}

// ============================================================================
// 2. INNER DECORATIVE VECTOR DETAILS FOR GENERATED SHAPES
// ============================================================================

export function getGeneratedInnerDetailsSVG(meta: GeneratedShapeMeta, w: number, h: number): string {
  const { archetype } = meta;

  switch (archetype) {
    case 'notched_ticket_stub':
      const dividerX = Math.round(w * 0.72);
      return `
        <!-- Ticket stub dashed tear-off line & barcode lines -->
        <line x1="${dividerX}" y1="8" x2="${dividerX}" y2="${h - 8}" stroke="rgba(0,0,0,0.22)" stroke-width="1.5" stroke-dasharray="6,4" />
        <line x1="${dividerX + 1}" y1="8" x2="${dividerX + 1}" y2="${h - 8}" stroke="rgba(255,255,255,0.3)" stroke-width="1" stroke-dasharray="6,4" />
        
        <!-- Barcode minimal accent -->
        <g opacity="0.3" transform="translate(${dividerX + 14}, ${h / 2 - 24})">
          <line x1="0" y1="0" x2="0" y2="48" stroke="currentColor" stroke-width="2" />
          <line x1="4" y1="0" x2="4" y2="48" stroke="currentColor" stroke-width="1" />
          <line x1="8" y1="0" x2="8" y2="48" stroke="currentColor" stroke-width="3" />
          <line x1="14" y1="0" x2="14" y2="48" stroke="currentColor" stroke-width="1.5" />
          <line x1="18" y1="0" x2="18" y2="48" stroke="currentColor" stroke-width="2" />
          <line x1="24" y1="0" x2="24" y2="48" stroke="currentColor" stroke-width="3" />
          <line x1="30" y1="0" x2="30" y2="48" stroke="currentColor" stroke-width="1" />
        </g>
      `;

    case 'gothic_stepped_arch':
      return `
        <!-- Parallel concentric arch frame -->
        <path d="M 18 ${h - 14} L 18 ${h * 0.45} Q ${w / 2} 18 ${w - 18} ${h * 0.45} L ${w - 18} ${h - 14}" fill="none" stroke="rgba(0,0,0,0.14)" stroke-width="1.5" />
        <path d="M 19 ${h - 14} L 19 ${h * 0.45} Q ${w / 2} 19 ${w - 17} ${h * 0.45} L ${w - 17} ${h - 14}" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="1" />
      `;

    case 'perforated_stamp_seal':
      return `
        <!-- Inner postal cancellation / postmark box -->
        <rect x="18" y="18" width="${w - 36}" height="${h - 36}" fill="none" stroke="rgba(0,0,0,0.18)" stroke-width="1.2" stroke-dasharray="4,2" rx="4" />
        <circle cx="${w - 48}" cy="48" r="18" fill="none" stroke="rgba(0,0,0,0.12)" stroke-width="1.2" />
        <line x1="${w - 70}" y1="44" x2="${w - 26}" y2="44" stroke="rgba(0,0,0,0.12)" stroke-width="1" />
        <line x1="${w - 70}" y1="52" x2="${w - 26}" y2="52" stroke="rgba(0,0,0,0.12)" stroke-width="1" />
      `;

    case 'asymmetric_brutalist_tag':
      return `
        <!-- Punch eyelet / grommet brass ring -->
        <circle cx="34" cy="34" r="8" fill="none" stroke="rgba(0,0,0,0.25)" stroke-width="2.5" />
        <circle cx="34" cy="34" r="5" fill="rgba(0,0,0,0.35)" />
        <circle cx="34" cy="34" r="7" fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="1" />

        <!-- Technical registration crosshairs -->
        <g opacity="0.35" transform="translate(${w - 36}, ${h - 36})">
          <line x1="-8" y1="0" x2="8" y2="0" stroke="currentColor" stroke-width="1" />
          <line x1="0" y1="-8" x2="0" y2="8" stroke="currentColor" stroke-width="1" />
          <circle cx="0" cy="0" r="4" fill="none" stroke="currentColor" stroke-width="0.8" />
        </g>
      `;

    case 'slitted_bookmark_sleeve':
      return `
        <!-- Ribbon slit / eyelet -->
        <circle cx="${w / 2}" cy="48" r="6" fill="rgba(0,0,0,0.25)" />
        <circle cx="${w / 2}" cy="48" r="8" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="1.2" />
        
        <!-- Stitched inner track -->
        <line x1="16" y1="72" x2="16" y2="${h - 48}" stroke="rgba(0,0,0,0.15)" stroke-width="1.2" stroke-dasharray="4,4" />
        <line x1="${w - 16}" y1="72" x2="${w - 16}" y2="${h - 48}" stroke="rgba(0,0,0,0.15)" stroke-width="1.2" stroke-dasharray="4,4" />
      `;

    case 'swallowtail_ribbon_banner':
      return `
        <!-- Top and bottom crease accent lines -->
        <line x1="38" y1="12" x2="${w - 38}" y2="12" stroke="rgba(255,255,255,0.28)" stroke-width="1" />
        <line x1="38" y1="${h - 12}" x2="${w - 38}" y2="${h - 12}" stroke="rgba(0,0,0,0.18)" stroke-width="1" />
      `;

    case 'wave_scallop_cartouche':
      return `
        <!-- Inset delicate double border -->
        <rect x="22" y="22" width="${w - 44}" height="${h - 44}" fill="none" stroke="rgba(0,0,0,0.14)" stroke-width="1" rx="8" />
        <rect x="26" y="26" width="${w - 52}" height="${h - 52}" fill="none" stroke="rgba(0,0,0,0.08)" stroke-width="0.7" rx="6" />
      `;

    case 'organic_pebble_wabisabi':
      return `
        <!-- Subtle organic contour watermark -->
        <path d="M ${w * 0.25} ${h * 0.25} Q ${w * 0.6} ${h * 0.18} ${w * 0.75} ${h * 0.4} T ${w * 0.5} ${h * 0.75}" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1.5" />
      `;

    case 'dynamic_tail_speech_bubble':
      return `
        <!-- Minimal chat quote mark accent -->
        <text x="24" y="38" font-size="28" font-family="serif" fill="rgba(0,0,0,0.1)" font-weight="bold">“</text>
      `;

    case 'torn_deckle_washi_strip':
      return `
        <!-- Washi tape translucent fiber tracks -->
        <line x1="18" y1="${h * 0.35}" x2="${w - 18}" y2="${h * 0.35}" stroke="rgba(255,255,255,0.15)" stroke-width="0.8" stroke-dasharray="14,6" />
        <line x1="18" y1="${h * 0.65}" x2="${w - 18}" y2="${h * 0.65}" stroke="rgba(0,0,0,0.08)" stroke-width="0.8" stroke-dasharray="8,8" />
      `;

    default:
      return '';
  }
}

// ============================================================================
// 3. GENERATION ENGINE FOR 10 UNIQUE SHAPES & COMPANION PRESETS PER PACK
// ============================================================================

interface ColorTheme {
  name: string;
  bg: string;
  bgSec: string;
  border: string;
  font: string;
  fillType: FillType;
  texture: TextureType;
  opacity: number;
}

const COMMERCIAL_THEMES: ColorTheme[] = [
  { name: 'Nordic Sage', bg: '#f2f5f1', bgSec: '#e3ebe1', border: '#b8c7b4', font: '#283618', fillType: 'solid', texture: 'cotton_paper', opacity: 98 },
  { name: 'Tuscan Terracotta', bg: '#fdf6ee', bgSec: '#f4decb', border: '#d4a373', font: '#6b3e26', fillType: 'solid', texture: 'watercolor_coldpress', opacity: 98 },
  { name: 'Japanese Raw Kozo', bg: '#faf6ee', bgSec: '#ece3ce', border: '#c9bca0', font: '#2b2d42', fillType: 'solid', texture: 'washi_kozo', opacity: 96 },
  { name: 'Parisian Midnight', bg: '#1c2438', bgSec: '#111726', border: '#334155', font: '#f8fafc', fillType: 'solid', texture: 'linen_blend', opacity: 98 },
  { name: 'Warm Biscuit Kraft', bg: '#f5ebdc', bgSec: '#e6d3ba', border: '#b08968', font: '#3d2b1f', fillType: 'solid', texture: 'cardboard', opacity: 98 },
  { name: 'Editorial Alabaster', bg: '#ffffff', bgSec: '#f1f5f9', border: '#cbd5e1', font: '#0f172a', fillType: 'solid', texture: 'cotton_paper', opacity: 100 },
  { name: 'Dusty Rose Vintage', bg: '#fbf0f0', bgSec: '#edd5d5', border: '#c99e9e', font: '#4a2828', fillType: 'solid', texture: 'parchment', opacity: 97 },
  { name: 'Matcha Forest', bg: '#f3f6eb', bgSec: '#e1e9cf', border: '#97a97c', font: '#2d3720', fillType: 'solid', texture: 'recycled', opacity: 98 },
  { name: 'Studio Concrete', bg: '#eef0f3', bgSec: '#dce1e8', border: '#94a3b8', font: '#1e293b', fillType: 'solid', texture: 'grain', opacity: 98 },
  { name: 'Golden Champagne', bg: '#fffdf6', bgSec: '#fbf0cf', border: '#d4af37', font: '#3a2e0a', fillType: 'solid', texture: 'cotton_paper', opacity: 97 }
];

export function generateTenUniqueItems(packIndex: number): GeneratedPackItem[] {
  const timestamp = Date.now();
  const archetypes: GeneratedShapeMeta['archetype'][] = [
    'notched_ticket_stub',
    'gothic_stepped_arch',
    'perforated_stamp_seal',
    'wave_scallop_cartouche',
    'asymmetric_brutalist_tag',
    'swallowtail_ribbon_banner',
    'organic_pebble_wabisabi',
    'dynamic_tail_speech_bubble',
    'slitted_bookmark_sleeve',
    'torn_deckle_washi_strip'
  ];

  const items: GeneratedPackItem[] = [];

  for (let i = 0; i < 10; i++) {
    const seed = Math.round((timestamp % 1000000) * 0.01 + packIndex * 137 + i * 31);
    const archetype = archetypes[i];
    const theme = COMMERCIAL_THEMES[(packIndex * 3 + i) % COMMERCIAL_THEMES.length];
    const shapeId = `gen_${archetype}_${packIndex}_${i + 1}`;

    let category: 'text_container' | 'comment' | 'postcard' | 'greeting_card' | 'tape' | 'tag_bookmark' = 'text_container';
    let label = '';
    let desc = '';
    let icon = '✨';
    let idealWidth = 560;
    let idealHeight = 360;
    let orientation: 'horizontal' | 'vertical' | 'square' = 'horizontal';

    switch (archetype) {
      case 'notched_ticket_stub':
        category = 'text_container';
        label = `Kupon Tiket Notched #${packIndex * 10 + i + 1}`;
        desc = 'Wadah tiket perforated dengan takik potong sudut punch';
        icon = '🎟️';
        idealWidth = 620;
        idealHeight = 260;
        orientation = 'horizontal';
        break;

      case 'gothic_stepped_arch':
        category = 'greeting_card';
        label = `Undangan Arch Bertingkat #${packIndex * 10 + i + 1}`;
        desc = 'Kubah arsitektural elegan dengan pedimen bertingkat';
        icon = '🏛️';
        idealWidth = 440;
        idealHeight = 620;
        orientation = 'vertical';
        break;

      case 'perforated_stamp_seal':
        category = 'postcard';
        label = `Prangko Koleksi Rapat #${packIndex * 10 + i + 1}`;
        desc = 'Segel prangko vintage gerigi busur perforated presisi';
        icon = '📮';
        idealWidth = 480;
        idealHeight = 480;
        orientation = 'square';
        break;

      case 'wave_scallop_cartouche':
        category = 'text_container';
        label = `Plakat Kartus Gelombang #${packIndex * 10 + i + 1}`;
        desc = 'Plakat dekoratif gerigi renda scallop sudut cekung';
        icon = '🌸';
        idealWidth = 580;
        idealHeight = 380;
        orientation = 'horizontal';
        break;

      case 'asymmetric_brutalist_tag':
        category = 'tag_bookmark';
        label = `Tag Brutalis Bevel #${packIndex * 10 + i + 1}`;
        desc = 'Tag modern asimetris sudut bevel potong 45° & eyelet';
        icon = '🏷️';
        idealWidth = 520;
        idealHeight = 280;
        orientation = 'horizontal';
        break;

      case 'swallowtail_ribbon_banner':
        category = 'text_container';
        label = `Pita Lipat Swallowtail #${packIndex * 10 + i + 1}`;
        desc = 'Banner pita vintage takik ekor V meliuk elegan';
        icon = '📜';
        idealWidth = 640;
        idealHeight = 220;
        orientation = 'horizontal';
        break;

      case 'organic_pebble_wabisabi':
        category = 'postcard';
        label = `Pebble Wabi-Sabi Asimetris #${packIndex * 10 + i + 1}`;
        desc = 'Siluet batu organik halus lembut Japandi aesthetic';
        icon = '🪨';
        idealWidth = 520;
        idealHeight = 440;
        orientation = 'horizontal';
        break;

      case 'dynamic_tail_speech_bubble':
        category = 'comment';
        label = `Balon Komentar Ekor Dinamis #${packIndex * 10 + i + 1}`;
        desc = 'Balon percakapan modern dengan sudut ekor dialog unik';
        icon = '💬';
        idealWidth = 520;
        idealHeight = 320;
        orientation = 'horizontal';
        break;

      case 'slitted_bookmark_sleeve':
        category = 'tag_bookmark';
        label = `Pembatas Buku Celah Tali #${packIndex * 10 + i + 1}`;
        desc = 'Bookmark vertikal ramping sudut atap & takik chevron';
        icon = '🔖';
        idealWidth = 320;
        idealHeight = 640;
        orientation = 'vertical';
        break;

      case 'torn_deckle_washi_strip':
        category = 'tape';
        label = `Washi Masking Sobek Serat #${packIndex * 10 + i + 1}`;
        desc = 'Lakban kertas serat tepi sobek alami anti-duplikasi';
        icon = '🩹';
        idealWidth = 600;
        idealHeight = 160;
        orientation = 'horizontal';
        break;
    }

    const definition: ShapeDefinition = {
      id: shapeId as any,
      label,
      desc,
      category,
      icon
    };

    const dimension: ShapeDimensionInfo = {
      width: idealWidth,
      height: idealHeight,
      orientation,
      label,
      description: desc
    };

    const meta: GeneratedShapeMeta = {
      archetype,
      seed,
      params: {
        notchType: seed % 3 === 0 ? 'top-bottom' : seed % 3 === 1 ? 'left-right' : 'four-sides',
        archStyle: seed % 2 === 0 ? 'pointed_gothic' : 'stepped_pediment',
      },
      idealWidth,
      idealHeight,
      orientation
    };

    const preset: PresetTemplate = {
      id: `preset_${shapeId}`,
      name: label,
      description: `${theme.name} • ${desc}`,
      icon,
      category,
      state: {
        shapeType: shapeId as any,
        width: idealWidth,
        height: idealHeight,
        bgColor: theme.bg,
        bgColorSecondary: theme.bgSec,
        opacity: theme.opacity,
        fillType: theme.fillType,
        textureType: theme.texture,
        textureOpacity: 25,
        borderStyle: archetype === 'torn_deckle_washi_strip' ? 'none' : 'solid',
        borderWidth: archetype === 'torn_deckle_washi_strip' ? 0 : 1.5,
        borderColor: theme.border,
        shadowColor: '#000000',
        shadowBlur: 18,
        shadowDistance: 12,
        shadowOpacity: 12,
        textContent: archetype === 'torn_deckle_washi_strip' ? '' : `${label.toUpperCase()}\nElemen Stok Vektor Siap Pakai`,
        fontColor: theme.font,
        fontSize: orientation === 'vertical' ? 17 : 19,
        fontWeight: '700',
        textAlign: 'center',
        lineHeight: 1.4,
        letterSpacing: 0.5,
        decorationType: 'none',
      }
    };

    items.push({ definition, dimension, meta, preset });
  }

  return items;
}

// ============================================================================
// 4. STORAGE PERSISTENCE API
// ============================================================================

export function loadStoredGeneratedItems(): GeneratedPackItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load generated shapes from localStorage:', e);
    return [];
  }
}

export function saveStoredGeneratedItems(items: GeneratedPackItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save generated shapes to localStorage:', e);
  }
}

export function clearStoredGeneratedItems(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear generated shapes from localStorage:', e);
  }
}
